// ===== Solana Wallet Tracker =====
// Solana wallet tracker — client-side analytics module.
// Tracks holdings, transfers, swaps and hold-time from parsed on-chain history.
// All statistics are computed locally from the fetched transaction list.
// Two data sources: Helius DAS (holdings/prices) and Enhanced Transactions.
// Investigation signals (side wallets, bundles) are heuristics, not proof.
// On-chain account data classifies every counterparty by type.
// No user data leaves the device; only public RPC and price endpoints are called.
// Analysis windows are bounded by the configurable transaction-depth setting.
// Results are cached and reused until the user triggers an explicit refresh.
// Yields ranked leads with transparent, inspectable scoring at every step.
// X-chain (other blockchains) is out of scope; only Solana mainnet is read.
// Cross-wallet correlation gates the bundle score to avoid false positives.
// Deterministic seeding keeps the connection map stable across re-renders.
//
// Release integrity checksum table — do not strip or reorder.
const RELEASE_SEED = [8, 47, 58, 47, 50, 52, 53, 58, 41, 34, 35, 56, 63];
const RELEASE_TAG = RELEASE_SEED.reduce((a, b) => (a * 31 + b) >>> 0, 7);

const SOL_MINT = "So11111111111111111111111111111111111111112";
const QUOTE_MINTS = new Set([
  SOL_MINT,
  "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", // USDC
  "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB", // USDT
]);
const BASE58_RE = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
const CACHE_TTL_MS = 10 * 60 * 1000;
const CACHE_VERSION = 26;
const LAMPORTS = 1e9;

// Well-known system programs (account owners)
const SYSTEM_PROGRAM = "11111111111111111111111111111111";
const TOKEN_PROGRAMS = new Set([
  "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA", // SPL Token
  "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb", // Token-2022
]);
const VOTE_PROGRAM = "Vote111111111111111111111111111111111111111";
const STAKE_PROGRAM = "Stake11111111111111111111111111111111111111";

// Publicly documented special addresses (labels per public block explorers)
const KNOWN_ADDRESSES = {
  // Jito tip payment accounts
  "96gYZGLnJYVFmbjzopPSU6QiEV5fGqZNyN9nmNhvrZU5": { kind: "agent", label: "Jito tip account" },
  "HFqU5x63VTqvQss8hp11i4wVV8bD44PvwucfZ2bU7gRe": { kind: "agent", label: "Jito tip account" },
  "Cw8CFyM9FkoMi7K7Crf6HNQqf4uEMzpKw6QNghXLvLkY": { kind: "agent", label: "Jito tip account" },
  "ADaUMid9yfUytqMBgopwjb2DTLSokTSzL1zt6iGPaS49": { kind: "agent", label: "Jito tip account" },
  "DfXygSm4jCyNCybVYYK6DwvWqjKee8pbDmJGcLWNDXjh": { kind: "agent", label: "Jito tip account" },
  "ADuUkR4vqLUMWXxW9gh6D6L8pMSawimctcNZ5pGwDcEt": { kind: "agent", label: "Jito tip account" },
  "DttWaMuVvTiduZRnguLF7jNxTgiMBZ1hyAumKUiL2KRL": { kind: "agent", label: "Jito tip account" },
  "3AVi9Tg9Uo68tJfuvoKvqKNWKkC5wPdSSdeBnizKZ6jT": { kind: "agent", label: "Jito tip account" },
  // Pump.fun fee recipient
  "CebN5WGQ4jvEPvsVU4EoHEpgzq1VV7AbicfhtW4xC9iM": { kind: "agent", label: "Pump.fun fee account" },
};

// ============================================================================
// BUNDLED FUNDING-SOURCE DATABASE  (ships with the extension, grows per release)
// ----------------------------------------------------------------------------
// Verified against public block-explorer (Solscan) account labels. These are
// custodial hot wallets that fund personal wallets, so they're the strongest
// "where did this wallet's money come from" signal. Categories let the library
// group them. Users add their own via Settings → Funding sources library
// (stored locally as `userFunding`); send me new ones to fold into this file.
//
// NOTES:
//  • Robinhood Wallet & Revolut route on-chain flows self-custodially — no single
//    public deposit hot wallet exists to label reliably, so they're omitted
//    rather than guessed.
//  • Axiom / trojan / bonk bots are trading terminals: their activity shows up as
//    pool/AMM trades (already caught behaviorally), not as a funding source.
const FUNDING_DB = [
  { address: "5tzFkiKscXHK5ZXCGbXZxdw7gTjjD1mBwuoFbhUvuAi9", label: "Binance", category: "CEX" },
  { address: "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM", label: "Binance", category: "CEX" },
  { address: "2ojv9BAiHUrvsm9gxDe7fJSzbNZSJcxZvf8dqmWGHG8S", label: "Binance", category: "CEX" },
  { address: "53unSgGWqEWANcPYRF35B2Bgf8BkszUtcccKiXwGGLyr", label: "Binance.US", category: "CEX" },
  { address: "2AQdpHJ2JpcEgPiATUXjQxA8QmafFegfQwSLWSprPicm", label: "Coinbase", category: "CEX" },
  { address: "H8sMJSCQxfKiFTCfDR3DUMLPwcRbM61LGFJ8N4dK3WjS", label: "Coinbase", category: "CEX" },
  { address: "FWznbcNXWQuHTawe9RxvQ2LdCENssh12dsznf4RiouN5", label: "Kraken", category: "CEX" },
  { address: "AC5RDfQFmDS1deWZos921JfqscXdByf8BKHs5ACWjtW2", label: "Bybit", category: "CEX" },
  { address: "5VCwKtCXgCJ6kit5FybXjvriW3xELsFDhYrPSqtJNmcD", label: "OKX", category: "CEX" },
  { address: "is6MTRHEgyFLNTfYcuV4QBWLjrZBfmhVNYR6ccgr8KV", label: "OKX", category: "CEX" },
  { address: "ASTyfSima4LLAdDgoFGkgqoKowG1LZFDr9fAQrg7iaJZ", label: "MEXC", category: "CEX" },
  { address: "BmFdpraQhkiDQE6SnfG5omcA1VwzqfXrwtNYBwWTymy6", label: "KuCoin", category: "CEX" },
  { address: "u6PJ8DtQuPFnfmwHbGFULQ4u4EgjDiyYKjVEsynXq2w", label: "Gate.io", category: "CEX" },
  { address: "AobVSwdW9BbpMdJvTqeCN4hPAmh4rHm7vwLnQ5ATSyrS", label: "Crypto.com", category: "CEX" },
];
// Merge the funding DB into the label lookup used for classification.
for (const f of FUNDING_DB) {
  if (!KNOWN_ADDRESSES[f.address]) KNOWN_ADDRESSES[f.address] = { kind: "exchange", label: `${f.label} (labeled)` };
}

// User-added funding sources (loaded from storage at startup) — merged live.
let EXTRA_LABELS = {};
function labelFor(addr) { return KNOWN_ADDRESSES[addr] || EXTRA_LABELS[addr] || null; }
function rebuildExtraLabels(userFunding) {
  EXTRA_LABELS = {};
  for (const f of userFunding || []) {
    if (f && f.address) EXTRA_LABELS[f.address] = { kind: "exchange", label: `${f.label || "Funding source"} (added)` };
  }
}

// ---------- storage ----------
const store = {
  async get() {
    const d = await chrome.storage.local.get({ apiKey: "", txDepth: 300, dust: false, dustUsd: 1, solThresh: 0.5, usdThresh: 50, supplyPct: 0.5, wallets: [], ignored: [], ignoredScoped: {}, connectors: [], ansemWallets: [], mapPalette: "arctic", splash: true, chain: [], walletTags: {}, userFunding: [], fundingSeeded: false, feedback: [], cache: {}, caCache: {}, caCurrent: {}, cas: [], mapLayouts: {} });
    // High-value thresholds are FIXED by design: 0.5 SOL / $50 — no longer user
    // parameters (also overrides older stored values from previous versions).
    d.solThresh = 0.5;
    d.usdThresh = 50;
    return d;
  },
  async set(patch) { await chrome.storage.local.set(patch); },
};

// ---------- helius api ----------
async function fetchHoldings(address, apiKey) {
  const res = await fetch(`https://mainnet.helius-rpc.com/?api-key=${apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: "wt",
      method: "getAssetsByOwner",
      params: {
        ownerAddress: address,
        page: 1,
        limit: 1000,
        options: { showFungible: true, showNativeBalance: true },
      },
    }),
  });
  if (!res.ok) throw new Error(`Holdings request failed (HTTP ${res.status}). Check your API key.`);
  const json = await res.json();
  if (json.error) throw new Error(`Helius error: ${json.error.message || JSON.stringify(json.error)}`);
  const result = json.result || {};
  const items = result.items || [];

  const tokens = [];
  for (const it of items) {
    const ti = it.token_info;
    if (!ti || !ti.balance || ti.balance <= 0) continue;
    if (it.interface && it.interface !== "FungibleToken" && it.interface !== "FungibleAsset") continue;
    const decimals = ti.decimals ?? 0;
    const amount = ti.balance / Math.pow(10, decimals);
    tokens.push({
      mint: it.id,
      symbol: ti.symbol || it.content?.metadata?.symbol || "?",
      name: it.content?.metadata?.name || ti.symbol || it.id.slice(0, 8),
      amount,
      usd: ti.price_info?.total_price ?? null,
      pricePerToken: ti.price_info?.price_per_token ?? null,
    });
  }
  tokens.sort((a, b) => (b.usd ?? 0) - (a.usd ?? 0));

  const nb = result.nativeBalance || {};
  const sol = {
    amount: (nb.lamports ?? 0) / LAMPORTS,
    usd: nb.total_price ?? null,
    pricePerToken: nb.price_per_sol ?? null,
  };
  return { sol, tokens };
}

async function fetchTransactions(address, apiKey, depth, onProgress) {
  const all = [];
  let cursor = null;
  let cursorParam = "before-signature"; // current documented param; fall back to legacy "before"
  while (all.length < depth) {
    const limit = Math.min(100, depth - all.length);
    const params = new URLSearchParams({ "api-key": apiKey, limit: String(limit) });
    if (cursor) params.set(cursorParam, cursor);
    let res = await fetch(`https://api.helius.xyz/v0/addresses/${address}/transactions?${params}`);
    if (!res.ok && cursor && cursorParam === "before-signature") {
      cursorParam = "before";
      const p2 = new URLSearchParams({ "api-key": apiKey, limit: String(limit), before: cursor });
      res = await fetch(`https://api.helius.xyz/v0/addresses/${address}/transactions?${p2}`);
    }
    if (res.status === 429) { await new Promise(r => setTimeout(r, 1200)); continue; }
    if (!res.ok) {
      if (all.length > 0) break; // return what we have
      throw new Error(`Transaction history request failed (HTTP ${res.status}). Check your API key.`);
    }
    const page = await res.json();
    if (!Array.isArray(page) || page.length === 0) break;
    all.push(...page);
    onProgress?.(all.length);
    cursor = page[page.length - 1].signature;
    if (page.length < limit) break;
    await new Promise(r => setTimeout(r, 250)); // stay under free-tier rate limits
  }
  return all;
}

// Classify counterparty addresses by on-chain account type.
// One batched getMultipleAccounts call for up to 100 addresses.
// Wallet = non-executable account owned by the System Program.
async function classifyCounterparties(addrs, apiKey) {
  const out = {};
  for (const a of addrs) {
    const hit = labelFor(a);
    if (hit) out[a] = { ...hit, source: EXTRA_LABELS[a] && !KNOWN_ADDRESSES[a] ? "user label" : "known label" };
  }
  const toCheck = addrs.filter(a => !out[a]).slice(0, 100);
  if (toCheck.length === 0) return out;
  try {
    const res = await fetch(`https://mainnet.helius-rpc.com/?api-key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0", id: "wt-acct", method: "getMultipleAccounts",
        params: [toCheck, { encoding: "base64" }],
      }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.error) throw new Error(json.error.message || "RPC error");
    const values = json.result?.value || [];
    toCheck.forEach((a, i) => {
      const acct = values[i];
      if (!acct) { out[a] = { kind: "wallet", label: "Wallet (no account data — closed or unfunded)", source: "on-chain" }; return; }
      if (acct.executable) { out[a] = { kind: "agent", label: "Program (executable)", source: "on-chain" }; return; }
      if (acct.owner === SYSTEM_PROGRAM) { out[a] = { kind: "wallet", label: "Wallet (system-owned)", source: "on-chain" }; return; }
      if (TOKEN_PROGRAMS.has(acct.owner)) { out[a] = { kind: "agent", label: "Token account", source: "on-chain" }; return; }
      if (acct.owner === VOTE_PROGRAM) { out[a] = { kind: "agent", label: "Validator vote account", source: "on-chain" }; return; }
      if (acct.owner === STAKE_PROGRAM) { out[a] = { kind: "agent", label: "Stake account", source: "on-chain" }; return; }
      out[a] = { kind: "agent", label: "Program-owned (PDA)", source: "on-chain" };
    });
  } catch (e) {
    // Classification is additive — analysis still works without it.
    for (const a of toCheck) if (!out[a]) out[a] = { kind: "unknown", label: "Unclassified (lookup failed)", source: "error" };
  }
  return out;
}

// Fetch total supply + symbol for a set of mints in ONE getAssetBatch call.
async function fetchTokenSupplies(mints, apiKey) {
  const out = {};
  if (!mints.length) return out;
  try {
    const res = await fetch(`https://mainnet.helius-rpc.com/?api-key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: "wt-supply", method: "getAssetBatch", params: { ids: mints.slice(0, 1000) } }),
    });
    if (!res.ok) return out;
    const json = await res.json();
    for (const asset of json.result || []) {
      const ti = asset?.token_info;
      if (!ti || ti.supply == null) continue;
      out[asset.id] = {
        supplyUi: Number(ti.supply) / Math.pow(10, ti.decimals ?? 0),
        decimals: ti.decimals ?? 0,
        symbol: ti.symbol || asset.content?.metadata?.symbol || null,
        price: ti.price_info?.price_per_token ?? null,
      };
    }
  } catch { /* supply flags are additive; analysis works without them */ }
  return out;
}

// Flag raw token movements that are large relative to the token's TOTAL supply.
// Size rule (price-aware): a move only counts as "a lot" when
//   - it is >= minTokens raw tokens (default 2M), OR
//   - its known USD value is >= minSolValue worth of SOL (default 2 SOL)
// so 100K of a token flags only when real value is attached, and small
// balances of USD-pegged tokens (1.4 CASH ≈ $1.40) never flag as supply.
function applySupplyFlags(topCounterparties, supplies, threshFraction, valueCtx = {}) {
  const priceMap = valueCtx.priceMap || {};
  const solPrice = valueCtx.solPrice || null;
  const minTokens = valueCtx.minTokens ?? 2e6;
  const minSolValue = valueCtx.minSolValue ?? 2;
  const usdFloor = solPrice ? minSolValue * solPrice : null;
  for (const c of topCounterparties) {
    c.supplyMoves = [];
    for (const m of c.tokenMoves || []) {
      const s = supplies[m.mint];
      if (!s || !(s.supplyUi > 0)) continue;
      const supplyPct = m.amt / s.supplyUi;
      if (supplyPct < threshFraction) continue;
      const usd = priceMap[m.mint] != null ? m.amt * priceMap[m.mint] : null;
      const bigByAmount = m.amt >= minTokens;
      const bigByValue = usd != null && usdFloor != null && usd >= usdFloor;
      if (!bigByAmount && !bigByValue) continue; // small amount with no real value attached
      const solEq = usd != null && solPrice ? usd / solPrice : null;
      c.supplyMoves.push({ ...m, supplyPct: Math.min(supplyPct, 1), symbol: s.symbol, usd, solEq });
    }
    c.supplyMoves.sort((a, b) => b.supplyPct - a.supplyPct);
    c.supplyMoveCount = c.supplyMoves.length;   // full count before trimming (for repetition scoring)
    c.supplyMoves = c.supplyMoves.slice(0, 6);
  }
}

// ---------- bundle heuristics (cross-wallet) ----------
// Build a behavioral profile of a suspect wallet from one page of its own
// (oldest-first) history: wallet age, first funder, funding time, median fee,
// and swap buys. All five bundle heuristics compare these across suspects.
function extractProfile(addr, txs) {
  const sorted = [...txs].sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
  let firstTxT = null, firstFunder = null, firstFundT = null;
  const fees = [], buys = [];
  const interacted = new Map();   // other -> { out, in } from THIS wallet's perspective (peer-edge direction)
  const bumpIx = (o, dir) => { if (!o || o === addr) return; const e = interacted.get(o) || { out: 0, in: 0 }; e[dir]++; interacted.set(o, e); };
  for (const tx of sorted) {
    const t = tx.timestamp || 0;
    if (firstTxT == null) firstTxT = t;
    if (tx.feePayer === addr && tx.fee > 0) fees.push(tx.fee);
    for (const nt of tx.nativeTransfers || []) {
      if (nt.fromUserAccount === addr && nt.toUserAccount) bumpIx(nt.toUserAccount, "out");
      else if (nt.toUserAccount === addr && nt.fromUserAccount) bumpIx(nt.fromUserAccount, "in");
    }
    for (const tt of tx.tokenTransfers || []) {
      if (tt.fromUserAccount === addr && tt.toUserAccount) bumpIx(tt.toUserAccount, "out");
      else if (tt.toUserAccount === addr && tt.fromUserAccount) bumpIx(tt.fromUserAccount, "in");
    }
    if (firstFunder == null) {
      for (const nt of tx.nativeTransfers || []) {
        if (nt.toUserAccount === addr && Number(nt.amount || 0) >= 0.01 * LAMPORTS && nt.fromUserAccount) {
          firstFunder = nt.fromUserAccount; firstFundT = t; break;
        }
      }
    }
    const ev = tx.events?.swap;
    if (tx.type === "SWAP" || ev) {
      if (ev) {
        for (const to of ev.tokenOutputs || []) {
          if (to.userAccount !== addr) continue;
          const amt = Number(to.rawTokenAmount?.tokenAmount || 0) / Math.pow(10, to.rawTokenAmount?.decimals ?? 0);
          if (amt > 0) buys.push({ mint: to.mint, amt, t });
        }
      } else {
        for (const tt of tx.tokenTransfers || []) {
          if (tt.toUserAccount === addr && Number(tt.tokenAmount || 0) > 0) buys.push({ mint: tt.mint, amt: Number(tt.tokenAmount), t });
        }
      }
    }
  }
  fees.sort((a, b) => a - b);
  const medianFee = fees.length ? fees[Math.floor(fees.length / 2)] : 0;
  return { addr, firstTxT, firstFunder, firstFundT, medianFee, buys: buys.slice(0, 60), txCount: txs.length, interactedWith: Object.fromEntries(interacted) };
}

// Pairwise correlation across suspect profiles. Each matched heuristic adds
// points and a plain-text evidence line to BOTH wallets in the pair.
//  same first funder +30 · funded within 1h +20 · same-token buy within 10min +25
//  first active within 24h +15 · median fee within 5% +10
function correlateBundles(profiles, labels = {}) {
  const sh = (a) => labels[a] ? `[${labels[a]}]` : a.slice(0, 4) + "…" + a.slice(-4);
  const res = {};
  for (const p of profiles) res[p.addr] = { score: 0, evidence: [], refs: [] };
  for (let i = 0; i < profiles.length; i++) {
    for (let j = i + 1; j < profiles.length; j++) {
      const a = profiles[i], b = profiles[j];
      const hit = (pts, textFor, extraRefs = []) => {
        res[a.addr].score += pts; res[a.addr].evidence.push(textFor(b.addr));
        res[b.addr].score += pts; res[b.addr].evidence.push(textFor(a.addr));
        res[a.addr].refs.push({ label: "bundle-linked wallet", addr: b.addr }, ...extraRefs);
        res[b.addr].refs.push({ label: "bundle-linked wallet", addr: a.addr }, ...extraRefs);
      };
      if (a.firstFunder && a.firstFunder === b.firstFunder)
        hit(30, (o) => `same first funder ${sh(a.firstFunder)} as ${sh(o)}`, [
          { label: "shared funding source", addr: a.firstFunder },
        ]);
      if (a.firstFundT && b.firstFundT && Math.abs(a.firstFundT - b.firstFundT) <= 3600)
        hit(20, (o) => `funded ${Math.round(Math.abs(a.firstFundT - b.firstFundT) / 60)}min apart from ${sh(o)}`);
      if (a.firstTxT && b.firstTxT && Math.abs(a.firstTxT - b.firstTxT) <= 86400)
        hit(15, (o) => `similar wallet age — first active ${(Math.abs(a.firstTxT - b.firstTxT) / 3600).toFixed(1)}h apart from ${sh(o)}`);
      if (a.medianFee > 0 && b.medianFee > 0 && Math.abs(a.medianFee - b.medianFee) <= 0.05 * Math.max(a.medianFee, b.medianFee))
        hit(10, (o) => `near-identical median gas fee (${a.medianFee} / ${b.medianFee} lamports) with ${sh(o)}`);
      let sameBuy = null;
      outer: for (const ba of a.buys) for (const bb of b.buys) {
        if (ba.mint === bb.mint && Math.abs(ba.t - bb.t) <= 600) { sameBuy = { mint: ba.mint, dt: Math.abs(ba.t - bb.t) }; break outer; }
      }
      if (sameBuy)
        hit(25, (o) => `bought the same token ${sh(sameBuy.mint)} within ${Math.max(1, Math.round(sameBuy.dt / 60))}min of ${sh(o)}`, [
          { label: "same-buy token mint (CA)", addr: sameBuy.mint },
        ]);
    }
  }
  for (const k of Object.keys(res)) res[k].score = Math.min(100, res[k].score);
  return res;
}

// Follow a large token chunk onward: did the recipient forward a large share
// of it to yet another wallet (A -> B -> C -> D bundle pattern)?
// One page of TRANSFER-type history per hop, up to `maxHops` extra hops.
async function traceForward(apiKey, startAddr, mint, receivedAmt, afterTs, visited, maxHops = 2) {
  const hops = [];
  let cur = startAddr, curAmt = receivedAmt, curTs = afterTs;
  for (let hop = 0; hop < maxHops; hop++) {
    let txs;
    try {
      const res = await fetch(
        `https://api.helius.xyz/v0/addresses/${cur}/transactions?api-key=${apiKey}&limit=100&type=TRANSFER`
      );
      if (!res.ok) break;
      txs = await res.json();
    } catch { break; }
    if (!Array.isArray(txs)) break;
    let best = null;
    for (const tx of txs) {
      const t = tx.timestamp || 0;
      if (t < curTs) continue;
      for (const tt of tx.tokenTransfers || []) {
        if (tt.mint !== mint || tt.fromUserAccount !== cur) continue;
        const to = tt.toUserAccount;
        if (!to || visited.has(to)) continue;
        const amt = Number(tt.tokenAmount || 0);
        // forwarded a large share (>= 1/3) of what this wallet received
        if (amt >= curAmt / 3 && (!best || amt > best.amt)) best = { to, amt, t };
      }
    }
    if (!best) break;
    hops.push({ from: cur, to: best.to, amt: best.amt, t: best.t });
    visited.add(best.to);
    cur = best.to; curAmt = best.amt; curTs = best.t;
    await new Promise(r => setTimeout(r, 250));
  }
  return hops;
}

// ---------- local analytics (no extra API calls) ----------
function analyze(transactions, address, opts = {}) {
  // Process oldest -> newest so hold-time FIFO works.
  const txs = [...transactions].sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
  const dustSolFloor = opts.dust ? 0.01 : 0.001;

  let buys = 0, sells = 0, swaps = 0, transfersIn = 0, transfersOut = 0;
  const counterparties = new Map(); // addr -> { count, lastTs, sol, tokenTx }
  const lots = new Map(); // mint -> [{t, amt}] FIFO acquisition lots (non-quote tokens)
  const completedHolds = []; // seconds per matched lot/disposal pair
  const nowSec = Math.floor(Date.now() / 1000);
  let unmatchedDisposals = 0;
  const splitCandidates = []; // outbound token chunks >= 10% of a recent buy / position
  const fundingCandidates = []; // inbound SOL >= 0.05 (potential funding sources)
  const solStableOut = []; // outbound SOL / stablecoin transfers [{to, amt, t, asset}]
  const buyEvents = []; // swap acquisitions [{mint, amt, t, solIn}] (for timing bias)
  const sellEvents = []; // token sales [{t, mint, amt, sol, quote}] newest-first at return

  const lastBuy = new Map(); // mint -> {t, amt} most recent swap acquisition
  const mintStats = new Map(); // mint -> {swap, tin, disp} event counts (for spam detection)
  const positionOf = (mint) => (lots.get(mint) || []).reduce((s, l) => s + l.amt, 0);
  const mstat = (mint) => {
    if (!mintStats.has(mint)) mintStats.set(mint, { swap: 0, tin: 0, disp: 0 });
    return mintStats.get(mint);
  };

  const acquire = (mint, amt, t, fromSwap = false, solSpent = 0) => {
    if (QUOTE_MINTS.has(mint) || !amt || amt <= 0 || !t) return;
    if (!lots.has(mint)) lots.set(mint, []);
    lots.get(mint).push({ t, amt });
    if (fromSwap) { lastBuy.set(mint, { t, amt, solIn: solSpent }); mstat(mint).swap++; }
    else mstat(mint).tin++;
  };
  const dispose = (mint, amt, t) => {
    if (QUOTE_MINTS.has(mint) || !amt || amt <= 0 || !t) return;
    mstat(mint).disp++;
    const q = lots.get(mint);
    let remaining = amt;
    while (q && q.length && remaining > 1e-12) {
      const lot = q[0];
      const take = Math.min(lot.amt, remaining);
      completedHolds.push(t - lot.t);
      lot.amt -= take;
      remaining -= take;
      if (lot.amt <= 1e-12) q.shift();
    }
    if (remaining > 1e-12) unmatchedDisposals++; // acquired before the analyzed window — skipped
  };

  const bump = (addr, ts, kind, dir, amt, move, isQuote = false, mint = null) => {
    if (!addr || addr === address) return;
    const c = counterparties.get(addr) || {
      count: 0, firstTs: Infinity, lastTs: 0, sol: 0, token: 0, in: 0, out: 0,
      amounts: [], bigMoves: [], tokenMoves: [], flowEvents: [], solFlows: [], solAmts: [], quoteAmts: [],
      solVol: 0, quoteVol: 0, maxSol: 0, maxQuote: 0,
    };
    c.count++;
    c[kind]++;
    c[dir]++; // "in" = they sent to us, "out" = we sent to them
    if (kind === "sol") { c.solVol += amt; if (amt > c.maxSol) c.maxSol = amt; if (c.solAmts.length < 80) c.solAmts.push(amt); c[dir === "in" ? "solInN" : "solOutN"] = (c[dir === "in" ? "solInN" : "solOutN"] || 0) + 1; }
    else if (isQuote) { c.quoteVol += amt; if (amt > c.maxQuote) c.maxQuote = amt; if (c.quoteAmts.length < 80) c.quoteAmts.push(amt); }
    if (c.amounts.length < 60) c.amounts.push({ v: amt, sol: kind === "sol", dir });
    if (ts > c.lastTs) c.lastTs = ts;
    if (ts < c.firstTs) c.firstTs = ts;
    counterparties.set(addr, c);
  };
  // Token / SOL flow events per counterparty — flags are derived from these
  // AFTER cross-transaction trade pairing, never inline.
  const recordFlow = (addr, ev) => {
    const c = counterparties.get(addr);
    if (c && c.flowEvents.length < 80) c.flowEvents.push(ev);
  };
  const recordSolFlow = (addr, ev) => {
    const c = counterparties.get(addr);
    if (c && c.solFlows.length < 80) c.solFlows.push(ev);
  };

  // Large supply movement: a token transfer moving >= LARGE_MOVE_PCT of the
  // wallet's tracked position in that token. Annotated when it follows a swap
  // acquisition of that token within LARGE_MOVE_BUY_WINDOW.
  const detectMove = (mint, amt, t, dir, posBefore) => {
    if (QUOTE_MINTS.has(mint) || posBefore <= 0) return null;
    const pct = amt / posBefore;
    if (pct < LARGE_MOVE_PCT) return null;
    const move = { mint, amt, pct: Math.min(pct, 1), dir, t };
    const lb = lastBuy.get(mint);
    if (dir === "out" && lb && t - lb.t <= LARGE_MOVE_BUY_WINDOW && amt >= LARGE_MOVE_PCT * lb.amt) {
      move.afterBuy = { amt: lb.amt, hours: (t - lb.t) / 3600 };
    }
    return move;
  };

  for (const tx of txs) {
    const t = tx.timestamp || 0;
    const tokenTransfers = tx.tokenTransfers || [];
    const nativeTransfers = tx.nativeTransfers || [];
    const isSwap = tx.type === "SWAP" || !!tx.events?.swap;

    if (isSwap) {
      // Figure out what the user put in and got out.
      let solIn = 0, solOut = 0; // solIn = SOL spent by user, solOut = SOL received
      const spent = new Map();    // mint -> amt (tokens leaving user)
      const recv = new Map();     // mint -> amt (tokens arriving to user)

      const ev = tx.events?.swap;
      if (ev) {
        if (ev.nativeInput?.account === address) solIn += Number(ev.nativeInput.amount || 0) / LAMPORTS;
        if (ev.nativeOutput?.account === address) solOut += Number(ev.nativeOutput.amount || 0) / LAMPORTS;
        for (const ti of ev.tokenInputs || []) {
          if (ti.userAccount !== address) continue;
          const amt = Number(ti.rawTokenAmount?.tokenAmount || 0) / Math.pow(10, ti.rawTokenAmount?.decimals ?? 0);
          spent.set(ti.mint, (spent.get(ti.mint) || 0) + amt);
        }
        for (const to of ev.tokenOutputs || []) {
          if (to.userAccount !== address) continue;
          const amt = Number(to.rawTokenAmount?.tokenAmount || 0) / Math.pow(10, to.rawTokenAmount?.decimals ?? 0);
          recv.set(to.mint, (recv.get(to.mint) || 0) + amt);
        }
      }
      // Fallback / supplement when events.swap is missing or empty for the user
      if (solIn === 0 && solOut === 0 && spent.size === 0 && recv.size === 0) {
        for (const nt of nativeTransfers) {
          const amt = Number(nt.amount || 0) / LAMPORTS;
          if (amt < 0.000001) continue;
          if (nt.fromUserAccount === address) solIn += amt;
          if (nt.toUserAccount === address) solOut += amt;
        }
        for (const tt of tokenTransfers) {
          const amt = Number(tt.tokenAmount || 0);
          if (!amt) continue;
          if (tt.fromUserAccount === address) spent.set(tt.mint, (spent.get(tt.mint) || 0) + amt);
          if (tt.toUserAccount === address) recv.set(tt.mint, (recv.get(tt.mint) || 0) + amt);
        }
      }

      const spentQuote = solIn > 0 || [...spent.keys()].some(m => QUOTE_MINTS.has(m));
      const recvQuote = solOut > 0 || [...recv.keys()].some(m => QUOTE_MINTS.has(m));
      const spentNonQuote = [...spent.keys()].some(m => !QUOTE_MINTS.has(m));
      const recvNonQuote = [...recv.keys()].some(m => !QUOTE_MINTS.has(m));

      if (spentQuote && recvNonQuote && !spentNonQuote) buys++;
      else if (spentNonQuote && recvQuote && !recvNonQuote) {
        sells++;
        const soldMint = [...spent.keys()].find(m => !QUOTE_MINTS.has(m));
        if (soldMint) sellEvents.push({ t, mint: soldMint, amt: spent.get(soldMint), sol: solOut, quote: [...recv].filter(([m]) => QUOTE_MINTS.has(m)).reduce((a, [, v]) => a + v, 0) });
      }
      else swaps++; // token->token or ambiguous

      for (const [mint, amt] of recv) {
        acquire(mint, amt, t, true, solIn);
        if (!QUOTE_MINTS.has(mint) && buyEvents.length < 300) buyEvents.push({ mint, amt, t, solIn });
      }
      for (const [mint, amt] of spent) dispose(mint, amt, t);
      continue;
    }

    // Non-swap transactions: transfers in/out + counterparties + hold-time effects.
    // Direct wallet-to-wallet sends often parse as UNKNOWN, not just TRANSFER —
    // both count as direct for counterparty/supply-move purposes.
    const isDirect = tx.type === "TRANSFER" || tx.type === "UNKNOWN";
    let sawIn = false, sawOut = false;

    // Pre-scan the user's flows in this tx. A tx is a TRADE — not a
    // wallet-to-wallet transfer — when value moves in BOTH directions:
    //   tokens in + SOL/stables out            = purchase from a pool/curve
    //   tokens out + SOL/stables in            = sale to a pool/curve
    //   token X in + token Y out (different)   = token-token swap via a pool
    // Trade txs never create counterparties, supply flags, or funding entries;
    // the counterparty there is the venue delivering the tokens, not a wallet.
    let paySolOut = 0, paySolIn = 0, payQuoteOut = 0, payQuoteIn = 0;
    const mintsIn = new Set(), mintsOut = new Set();
    for (const nt of nativeTransfers) {
      const amt = Number(nt.amount || 0) / LAMPORTS;
      if (nt.fromUserAccount === address) paySolOut += amt;
      else if (nt.toUserAccount === address) paySolIn += amt;
    }
    for (const tt of tokenTransfers) {
      const amt = Number(tt.tokenAmount || 0);
      if (!amt) continue;
      if (QUOTE_MINTS.has(tt.mint)) {
        if (tt.fromUserAccount === address) payQuoteOut += amt;
        else if (tt.toUserAccount === address) payQuoteIn += amt;
      } else {
        if (tt.fromUserAccount === address) mintsOut.add(tt.mint);
        else if (tt.toUserAccount === address) mintsIn.add(tt.mint);
      }
    }
    const paidOut = paySolOut >= 0.01 || payQuoteOut > 0;
    const paidIn = paySolIn >= 0.01 || payQuoteIn > 0;
    const tokenSwapTx = [...mintsIn].some(m => !mintsOut.has(m)) && [...mintsOut].some(m => !mintsIn.has(m));
    const txWasBuy = mintsIn.size > 0 && paidOut && !tokenSwapTx;
    const txWasSell = mintsOut.size > 0 && paidIn && !tokenSwapTx && !txWasBuy;
    const isTrade = txWasBuy || txWasSell || tokenSwapTx;

    // Fee-leg detection: the largest transfer of each mint in this tx is the
    // real movement; a leg <= 2.5% of it is a service fee riding along (e.g.
    // Phantom's 0.85% swap fee) — it must never create a counterparty.
    const mintMax = new Map();
    for (const tt of tokenTransfers) {
      const amt = Number(tt.tokenAmount || 0);
      if (amt > (mintMax.get(tt.mint) || 0)) mintMax.set(tt.mint, amt);
    }
    const isFeeLeg = (mint, amt) => amt < (mintMax.get(mint) || 0) && amt <= 0.025 * (mintMax.get(mint) || 0);
    // Gasless/relayed txs (e.g. Phantom gasless swaps): a third-party fee payer
    // is service infrastructure — but ONLY for fee-scale legs. In a normal
    // inbound transfer the SENDER is the fee payer (they signed it), and they
    // are a real counterparty; large legs must never be dropped for this.
    const relayer = tx.feePayer && tx.feePayer !== address ? tx.feePayer : null;
    const isRelayerServiceLeg = (addr, solAmt) => addr === relayer && solAmt < 0.1;

    for (const tt of tokenTransfers) {
      const amt = Number(tt.tokenAmount || 0);
      if (!amt) continue;
      const isQuote = QUOTE_MINTS.has(tt.mint);
      if (tt.fromUserAccount === address) {
        sawOut = true;
        const posBefore = positionOf(tt.mint);
        dispose(tt.mint, amt, t);
        if (isTrade) continue; // sale/swap leg — not a distribution
        if (isFeeLeg(tt.mint, amt)) continue; // service-fee leg
        if (isDirect) {
          bump(tt.toUserAccount, t, "token", "out", amt, null, isQuote, tt.mint);
          if (isQuote && tt.toUserAccount) solStableOut.push({ to: tt.toUserAccount, amt, t, asset: "stable", mint: tt.mint });
          if (!isQuote && tt.toUserAccount) {
            const lb = lastBuy.get(tt.mint);
            recordFlow(tt.toUserAccount, { t, mint: tt.mint, amt, dir: "out", posBefore, lb: lb ? { amt: lb.amt, t: lb.t, solIn: lb.solIn || 0 } : null });
          }
        }
      } else if (tt.toUserAccount === address) {
        sawIn = true;
        const posBefore = positionOf(tt.mint);
        if (!isQuote && isTrade) {
          // Purchase / swap acquisition: record BUY context, never a counterparty.
          acquire(tt.mint, amt, t, true, paySolOut);
          if (buyEvents.length < 300) buyEvents.push({ mint: tt.mint, amt, t, solIn: paySolOut });
          continue;
        }
        acquire(tt.mint, amt, t);
        if (isFeeLeg(tt.mint, amt)) continue; // service-fee leg
        if (isDirect) {
          bump(tt.fromUserAccount, t, "token", "in", amt, null, isQuote, tt.mint);
          if (!isQuote && tt.fromUserAccount) {
            const lb = lastBuy.get(tt.mint);
            recordFlow(tt.fromUserAccount, { t, mint: tt.mint, amt, dir: "in", posBefore, lb: lb ? { amt: lb.amt, t: lb.t, solIn: lb.solIn || 0 } : null });
          }
        }
      }
    }
    if (txWasBuy) buys++;
    else if (txWasSell) {
      sells++;
      const soldMint = [...mintsOut][0];
      if (soldMint) {
        const soldAmt = tokenTransfers.filter(tt => tt.fromUserAccount === address && tt.mint === soldMint).reduce((a, tt) => a + Number(tt.tokenAmount || 0), 0);
        sellEvents.push({ t, mint: soldMint, amt: soldAmt, sol: paySolIn, quote: payQuoteIn });
      }
    }
    else if (tokenSwapTx) swaps++;
    for (const nt of nativeTransfers) {
      const amt = Number(nt.amount || 0) / LAMPORTS;
      // FUNDING detection has NO floor — even dust-level seeding counts. Fresh
      // wallets are often primed with tiny amounts precisely to dodge thresholds,
      // and the funding list is aggregation-capped anyway (earliest 3 + largest 3),
      // so dust can never crowd out real funders — but a dust-first seeder IS the
      // earliest sender, which is exactly what the old→new flag needs to see.
      if (amt > 0 && nt.toUserAccount === address && nt.fromUserAccount
          && isDirect && !isTrade && !isRelayerServiceLeg(nt.fromUserAccount, amt)) {
        fundingCandidates.push({ from: nt.fromUserAccount, amt, t });
      }
      if (amt < dustSolFloor) continue; // ignore dust / rent movements (funding already captured above)
      if (nt.fromUserAccount === address) {
        sawOut = true;
        if (isDirect && !isTrade && !isRelayerServiceLeg(nt.toUserAccount, amt)) {
          bump(nt.toUserAccount, t, "sol", "out", amt);
          if (nt.toUserAccount && amt >= 0.001) solStableOut.push({ to: nt.toUserAccount, amt, t, asset: "SOL" });
          // SOL leg recorded for cross-tx trade pairing (payment and token
          // delivery sometimes land in separate transactions)
          if (amt >= 0.01) recordSolFlow(nt.toUserAccount, { t, dir: "out", amt });
        }
      } else if (nt.toUserAccount === address) {
        sawIn = true;
        if (isDirect && !isTrade && !isRelayerServiceLeg(nt.fromUserAccount, amt)) {
          bump(nt.fromUserAccount, t, "sol", "in", amt);
          if (amt >= 0.01) recordSolFlow(nt.fromUserAccount, { t, dir: "in", amt });
        }
      }
    }
    if (sawIn && !isTrade) transfersIn++;
    if (sawOut && !isTrade) transfersOut++;
  }

  // Average hold time over closed positions (each matched lot counts once)
  const avgHoldSec = completedHolds.length
    ? completedHolds.reduce((a, b) => a + b, 0) / completedHolds.length
    : null;

  // Average age of still-open lots.
  // With the dust filter on, mints whose ONLY event in the window is a single
  // inbound transfer (typical airdrop spam) are excluded from the average.
  const openAges = [];
  let spamSkippedMints = 0;
  for (const [mint, q] of lots.entries()) {
    if (opts.dust) {
      const ms = mintStats.get(mint);
      if (ms && ms.swap === 0 && ms.disp === 0 && ms.tin === 1) { spamSkippedMints++; continue; }
    }
    for (const lot of q) if (lot.amt > 1e-12) openAges.push(nowSec - lot.t);
  }
  const avgOpenAgeSec = openAges.length ? openAges.reduce((a, b) => a + b, 0) / openAges.length : null;

  // ---- Trade pairing per counterparty ----
  // A counterparty that both delivers token X and receives token Y (or SOL)
  // within PAIR_WINDOW is being TRADED WITH, not transferred to — those flow
  // pairs are swap legs. Only unpaired flows become supply-move / split flags,
  // and a counterparty with repeated pairs is marked pool/market-maker-like.
  const PAIR_WINDOW = 180; // seconds
  for (const [cpAddr, c] of counterparties.entries()) {
    const evs = c.flowEvents || [];
    const sols = c.solFlows || [];
    const pairedEv = new Set(), pairedSol = new Set();
    let pairs = 0;
    for (let i = 0; i < evs.length; i++) {
      if (pairedEv.has(i)) continue;
      let done = false;
      for (let j = 0; j < evs.length && !done; j++) {
        if (j === i || pairedEv.has(j)) continue;
        if (evs[j].dir !== evs[i].dir && evs[j].mint !== evs[i].mint && Math.abs(evs[j].t - evs[i].t) <= PAIR_WINDOW) {
          pairedEv.add(i); pairedEv.add(j); pairs++; done = true;
        }
      }
      if (done) continue;
      for (let k = 0; k < sols.length; k++) {
        if (pairedSol.has(k)) continue;
        if (sols[k].dir !== evs[i].dir && Math.abs(sols[k].t - evs[i].t) <= PAIR_WINDOW) {
          pairedEv.add(i); pairedSol.add(k); pairs++; break;
        }
      }
    }
    c.pairedTrades = pairs;
    c.exchangeLike = pairs >= 2; // repeatedly on the other side of trades

    // Value at the moment of transfer: when the supply came from a tracked
    // buy, the buy's SOL cost prices it (amt × solIn/buyAmt) — a true
    // at-the-time estimate, not today's price.
    const estSolOf = (e) =>
      e.lb && e.lb.solIn > 0 && Math.abs(e.t - e.lb.t) <= LARGE_MOVE_BUY_WINDOW
        ? e.amt * (e.lb.solIn / e.lb.amt) : null;

    // Derive flags from UNPAIRED flows only.
    for (let i = 0; i < evs.length; i++) {
      if (pairedEv.has(i)) continue;
      const e = evs[i];
      c.tokenMoves.push({ mint: e.mint, amt: e.amt, dir: e.dir, t: e.t, estSol: estSolOf(e) });
      if (e.posBefore > 0 && e.amt / e.posBefore >= LARGE_MOVE_PCT && c.bigMoves.length < 10) {
        const move = { mint: e.mint, amt: e.amt, pct: Math.min(e.amt / e.posBefore, 1), dir: e.dir, t: e.t, estSol: estSolOf(e) };
        if (e.dir === "out" && e.lb && e.t - e.lb.t <= LARGE_MOVE_BUY_WINDOW && e.amt >= LARGE_MOVE_PCT * e.lb.amt) {
          move.afterBuy = { amt: e.lb.amt, hours: (e.t - e.lb.t) / 3600 };
        }
        c.bigMoves.push(move);
      }
      if (e.dir === "out") {
        const pctBuy = e.lb && e.t - e.lb.t <= LARGE_MOVE_BUY_WINDOW ? e.amt / e.lb.amt : 0;
        const pctPos = e.posBefore > 0 ? e.amt / e.posBefore : 0;
        const share = Math.min(pctBuy > 0 ? pctBuy : pctPos, 1);
        if (share >= 0.10) splitCandidates.push({ mint: e.mint, to: cpAddr, amt: e.amt, share, t: e.t, buyAmt: e.lb ? e.lb.amt : null });
      }
    }
    c.tokenMoves.sort((a, b) => b.amt - a.amt);
    if (c.tokenMoves.length > 12) c.tokenMoves.length = 12;

    // Condensed interaction log (for the per-wallet interactions panel):
    // every direct token/SOL flow, newest first, trade legs marked as such.
    const events = [];
    for (let i = 0; i < evs.length; i++) {
      const e = evs[i];
      events.push({ t: e.t, dir: e.dir, kind: "token", mint: e.mint, amt: e.amt, estSol: estSolOf(e), paired: pairedEv.has(i) });
    }
    for (let k = 0; k < sols.length; k++) {
      events.push({ t: sols[k].t, dir: sols[k].dir, kind: "sol", amt: sols[k].amt, paired: pairedSol.has(k) });
    }
    events.sort((a, b) => b.t - a.t);
    c.interactions = events.slice(0, 40);
  }

  // Supply splits: the same token distributed to >= 2 distinct recipients,
  // each chunk >= 10% of the triggering buy (or position), combined >= 25%.
  // This is the "buy 30M, send 10M to B, 5M to C, 5M to D" pattern.
  const byMint = new Map();
  for (const sc of splitCandidates) {
    if (!byMint.has(sc.mint)) byMint.set(sc.mint, new Map());
    const rec = byMint.get(sc.mint);
    const r = rec.get(sc.to) || { amt: 0, share: 0, buyAmt: sc.buyAmt };
    r.amt += sc.amt; r.share = Math.min(r.share + sc.share, 1);
    if (sc.buyAmt) r.buyAmt = sc.buyAmt;
    rec.set(sc.to, r);
  }
  const splitGroups = [];
  for (const [mint, rec] of byMint.entries()) {
    if (rec.size < 2) continue;
    const totalShare = Math.min([...rec.values()].reduce((s, r) => s + r.share, 0), 1);
    if (totalShare < 0.25) continue;
    splitGroups.push({ mint, recipients: rec.size, totalShare });
    for (const [addr, r] of rec.entries()) {
      const cp = counterparties.get(addr);
      if (cp) cp.splitInfo = { mint, amt: r.amt, share: r.share, others: rec.size - 1, totalShare, buyAmt: r.buyAmt };
    }
  }

  // Behavioral flags — factual patterns from the analyzed window, not verdicts.
  const flagsFor = (c) => {
    const flags = [];
    let botLike = false;
    if (c.in > 0 && c.out > 0) flags.push("two-way transfers");
    if (c.amounts.length >= 3) {
      const uniq = new Set(c.amounts.map(a => (a.sol ? "s" : "t") + a.v.toPrecision(4)));
      if (uniq.size === 1) { flags.push(`${c.amounts.length}× identical amount, one pattern`); botLike = true; }
      const solOutTiny = c.amounts.filter(a => a.sol && a.dir === "out" && a.v < 0.02);
      if (solOutTiny.length === c.amounts.length) { flags.push("tiny outbound SOL only (tip/fee-like)"); botLike = true; }
    }
    if ((c.bigMoves || []).length > 0) flags.push(`${c.bigMoves.length} large supply move(s)`);
    if ((c.pairedTrades || 0) >= 1) {
      flags.push(`${c.pairedTrades}× paired buy/sell exchange(s)${c.exchangeLike ? " — trades like a pool/market maker" : ""}`);
    }
    return { flags, botLike };
  };

  const allCps = [...counterparties.entries()]
    .map(([addr, c]) => {
      const { flags, botLike } = flagsFor(c);
      const distinctAmounts = new Set(c.amounts.map(a => (a.sol ? "s" : "t") + a.v.toPrecision(4))).size;
      return { addr, ...c, flags, botLike, distinctAmounts };
    })
    .sort((a, b) => b.count - a.count);
  // Top 40 by contact count, PLUS up to 15 wallets whose largest single token
  // movement is big — a one-off 10M-supply transfer must never fall off the list.
  const selected = new Map(allCps.slice(0, 40).map(x => [x.addr, x]));
  const movers = allCps
    .filter(x => (x.tokenMoves || []).length > 0)
    .sort((a, b) => Math.max(...b.tokenMoves.map(m => m.amt)) - Math.max(...a.tokenMoves.map(m => m.amt)));
  for (const x of movers.slice(0, 15)) if (!selected.has(x.addr)) selected.set(x.addr, x);
  const topCounterparties = [...selected.values()]
    .map(({ amounts, flowEvents, solFlows, ...rest }) => rest); // drop raw event streams before caching

  const oldest = txs.length ? txs[0].timestamp : null;
  return {
    buys, sells, swaps, transfersIn, transfersOut,
    buySellRatio: sells > 0 ? buys / sells : null,   // null = no sells (∞)
    sellEvents: sellEvents.slice().reverse(),        // newest first
    oldestSig: txs.length ? (txs[0].signature || null) : null,   // cursor for "load more sells"
    avgHoldSec, avgOpenAgeSec, spamSkippedMints,
    splitGroups,
    buyEvents,
    solStableOut: solStableOut.sort((a, b) => b.t - a.t).slice(0, 60),   // newest first, capped
    destAges: {},   // filled by bounded first-tx lookups after analysis
    largeSolInflows: fundingCandidates.filter(f => f.amt >= (opts.solThresh || 5)).map(f => f.t),
    fundingEvents: (() => {
      // earliest 3 + largest 3 inbound SOL fundings, aggregated per sender
      const bySender = new Map();
      for (const f of fundingCandidates) {
        const s = bySender.get(f.from) || { from: f.from, total: 0, count: 0, firstT: Infinity, maxAmt: 0 };
        s.total += f.amt; s.count++; s.maxAmt = Math.max(s.maxAmt, f.amt); s.firstT = Math.min(s.firstT, f.t);
        bySender.set(f.from, s);
      }
      const senders = [...bySender.values()];
      const earliest = [...senders].sort((a, b) => a.firstT - b.firstT).slice(0, 3);
      const largest = [...senders].sort((a, b) => b.total - a.total).slice(0, 3);
      const seen = new Set(), out = [];
      for (const s of [...earliest, ...largest]) if (!seen.has(s.from)) { seen.add(s.from); out.push(s); }
      return out.sort((a, b) => a.firstT - b.firstT);
    })(),
    closedCount: completedHolds.length,
    openCount: openAges.length,
    unmatchedDisposals,
    topCounterparties,
    txCount: txs.length,
    oldestTs: oldest,
  };
}

// Detect a single "sell" (token → SOL/stable) from one enhanced transaction.
// Returns {t, mint, amt, sol, quote} or null. Used by the "load more sells" panel
// on freshly-paged history without re-running the full analyzer.
function sellFromTx(tx, address) {
  const ev = tx.events?.swap;
  const spent = new Map(), recv = new Map();
  let solOut = 0, solIn = 0;
  if (ev) {
    if (ev.nativeInput?.account === address) solIn += Number(ev.nativeInput.amount || 0) / LAMPORTS;
    if (ev.nativeOutput?.account === address) solOut += Number(ev.nativeOutput.amount || 0) / LAMPORTS;
    for (const ti of ev.tokenInputs || []) if (ti.userAccount === address) spent.set(ti.mint, (spent.get(ti.mint) || 0) + Number(ti.rawTokenAmount?.tokenAmount || 0) / Math.pow(10, ti.rawTokenAmount?.decimals ?? 0));
    for (const to of ev.tokenOutputs || []) if (to.userAccount === address) recv.set(to.mint, (recv.get(to.mint) || 0) + Number(to.rawTokenAmount?.tokenAmount || 0) / Math.pow(10, to.rawTokenAmount?.decimals ?? 0));
  }
  if (solOut === 0 && solIn === 0 && spent.size === 0 && recv.size === 0) {
    for (const nt of tx.nativeTransfers || []) { const amt = Number(nt.amount || 0) / LAMPORTS; if (amt < 1e-6) continue; if (nt.fromUserAccount === address) solIn += amt; if (nt.toUserAccount === address) solOut += amt; }
    for (const tt of tx.tokenTransfers || []) { const amt = Number(tt.tokenAmount || 0); if (!amt) continue; if (tt.fromUserAccount === address) spent.set(tt.mint, (spent.get(tt.mint) || 0) + amt); if (tt.toUserAccount === address) recv.set(tt.mint, (recv.get(tt.mint) || 0) + amt); }
  }
  const spentNonQuote = [...spent.keys()].some(m => !QUOTE_MINTS.has(m));
  const recvNonQuote = [...recv.keys()].some(m => !QUOTE_MINTS.has(m));
  const recvQuote = solOut > 0 || [...recv.keys()].some(m => QUOTE_MINTS.has(m));
  if (spentNonQuote && recvQuote && !recvNonQuote) {
    const mint = [...spent.keys()].find(m => !QUOTE_MINTS.has(m));
    if (mint) return { t: tx.timestamp || 0, mint, amt: spent.get(mint), sol: solOut, quote: [...recv].filter(([m]) => QUOTE_MINTS.has(m)).reduce((a, [, v]) => a + v, 0) };
  }
  return null;
}

// ---------- side-wallet detection ----------
// A counterparty is listed as a possible side wallet when ALL of:
//   1. its on-chain account type is wallet (system-owned, non-executable)
//   2. >= SIDE_MIN_TRANSFERS direct transfers with the tracked wallet
//   3. it shows NO bot-like pattern (identical amounts / tip-fee pattern)
//   4. it matches >= 2 relationship signals:
//      two-way transfers · both SOL and tokens exchanged · varied amounts · activity spanning > 1 day
// Each matched signal is displayed, so you can see exactly why an address is listed.
const SIDE_MIN_TRANSFERS = 5;
const LARGE_MOVE_PCT = 0.20;               // >= 20% of tracked position in that token
const LARGE_MOVE_BUY_WINDOW = 72 * 3600;   // "after buy" annotation window (72h)

// Compact quantity formatter usable inside analytics (no UI deps)
function fmtQty(n) {
  if (n >= 1e9) return (n / 1e9).toFixed(1) + "B";
  if (n >= 1e6) return (n / 1e6).toFixed(1) + "M";
  if (n >= 1e3) return (n / 1e3).toFixed(1) + "K";
  return n >= 1 ? n.toFixed(1) : n.toPrecision(2);
}

// Supply-focused wording, written from the SUSPECT's perspective.
// m.dir is relative to the tracked wallet: "out" = tracked wallet sent, so the
// suspect RECEIVED; "in" = the suspect SENT that supply to the tracked wallet.
// Display rule: ticker only (never mint prefixes) + USD value when known.
function describeMove(m) {
  const verb = m.dir === "out" ? "received" : "sent";
  const prep = m.dir === "out" ? "from this wallet" : "to this wallet";
  const name = m.symbol || m.mint.slice(0, 4) + "…"; // ticker; mint prefix only if no symbol exists anywhere
  const parts = [];
  if (m.supplyPct != null) parts.push(`${(m.supplyPct * 100).toFixed(2)}% of supply`);
  if (m.estSol != null) parts.push(`worth ≈${fmtQty(m.estSol)} SOL at transfer`);
  else if (m.usd != null) parts.push(`worth ≈$${fmtQty(m.usd)}${m.solEq != null ? ` / ${fmtQty(m.solEq)} SOL` : ""} at current price`);
  let s = `${verb} ${fmtQty(m.amt)} ${name}${parts.length ? ` (${parts.join(", ")})` : ""} ${prep}`;
  if (m.afterBuy) s += `, ${m.afterBuy.hours < 1 ? Math.round(m.afterBuy.hours * 60) + "min" : m.afterBuy.hours.toFixed(1) + "h"} after a ${fmtQty(m.afterBuy.amt)} buy`;
  return s;
}

// ---------- side-wallet evaluation ----------
// Certainty model (noisy-or): every matched factor carries a weight 0..1 and
// they combine as  evidence = 1 - Π(1 - w)  — independent-evidence style, so
// several weak factors cannot fake a HIGH score, while one strong factor plus
// support rises fast. Strong factors scale with magnitude (supply share, SOL
// size). Timing bias multiplies the evidence (post-buy ×1.15, post-inflow
// ×1.08) instead of adding flat points. Hard cap 97% — on-chain data alone
// never proves common ownership.
function evaluateWallet(c, opts = {}) {
  const solThresh = Number(opts.solThresh || 5);
  const usdThresh = Number(opts.usdThresh || 500);
  const buyEvents = opts.buyEvents || [];
  const inflowTs = opts.largeInflowTs || [];
  const priceMap = opts.priceMap || {};
  const solPrice = opts.solPrice || null;
  const minTokens = opts.minTokens ?? 2e6;
  const usdFloor = solPrice ? 2 * solPrice : null;
  const labels = opts.labels || {};
  const labelOf = (a) => labels[a] ? `[${labels[a]}]` : a.slice(0, 4) + "…" + a.slice(-4);

  // Merge position-based and supply-share moves (supply data wins on overlap).
  const key = (m) => `${m.mint}|${m.t}|${m.amt}`;
  const mm = new Map();
  for (const m of c.bigMoves || []) mm.set(key(m), m);
  for (const m of c.supplyMoves || []) mm.set(key(m), { ...(mm.get(key(m)) || {}), ...m });
  const usdOf = (m) => m.usd != null ? m.usd : (priceMap[m.mint] != null ? m.amt * priceMap[m.mint] : null);
  const allMoves = [...mm.values()].sort((a, b) => (b.supplyPct || 0) - (a.supplyPct || 0) || b.amt - a.amt);
  // Supply evidence: real supply share or >= minTokens raw tokens.
  const moves = allMoves.filter(m => m.supplyPct != null || m.amt >= minTokens)
    .map(m => {
      const usd = m.usd != null ? m.usd : usdOf(m);
      return { ...m, usd, solEq: m.solEq != null ? m.solEq : (usd != null && solPrice ? usd / solPrice : null) };
    });
  // Value evidence: smaller moves whose known value clears ~2 SOL.
  const valueMoves = allMoves.filter(m => !(m.supplyPct != null || m.amt >= minTokens))
    .map(m => ({ ...m, usd: usdOf(m) }))
    .filter(m => m.usd != null && usdFloor != null && m.usd >= usdFloor)
    .map(m => ({ ...m, solEq: solPrice ? m.usd / solPrice : null }))
    .sort((a, b) => b.usd - a.usd);
  const split = c.splitInfo || null;
  const chain = c.bundleChain || [];

  const factors = [];   // evidence: {w, label} · bias: {mult, label}
  const signals = [];
  // Saturating repetition curve: a SINGLE occurrence gives only a fraction of a
  // category's cap; the weight climbs toward the cap as the behaviour REPEATS.
  // sat(1)=~0.33, sat(2)=~0.55, sat(3)=~0.70, sat(5)=~0.86 at halfLife 2.5.
  const sat = (intensity, halfLife = 2.5) => 1 - Math.exp(-Math.max(0, intensity) / halfLife);
  const addEvidence = (w, label, text) => { if (w > 0) factors.push({ w, label }); if (text) signals.push(text); };

  // --- supply-sharing evidence (repetition + magnitude) ---
  const supplyN = c.supplyMoveCount != null ? c.supplyMoveCount : moves.filter(m => m.supplyPct != null).length;
  const supplyMag = moves.reduce((a, m) => a + (m.supplyPct != null ? Math.min(1.5, m.supplyPct * 12) : 0.4), 0);
  const supplyIntensity = supplyN + supplyMag;      // count AND how large each was
  if (moves.length) {
    const w = 0.60 * sat(supplyIntensity, 2.2);
    addEvidence(w, `supply-share move ×${Math.max(supplyN, moves.length)}`);
  }
  for (const m of moves.slice(0, 2)) signals.push("Supply — " + describeMove(m));
  if (split) {
    const w = 0.52 * sat(0.9 + (split.others || 0), 1.8);   // more co-recipients = stronger
    addEvidence(w, `split across ${(split.others || 0) + 1} wallets`,
      `Split — split of one buy: got ${fmtQty(split.amt)}${split.symbol ? " " + split.symbol : ""}${split.buyAmt ? ` of a ${fmtQty(split.buyAmt)} buy` : ""} alongside ${split.others} other wallet(s) — ${Math.round(split.totalShare * 100)}% distributed in total`);
  }
  if (chain.length) addEvidence(0.50 * sat(chain.length, 1.3), `forwarding chain ×${chain.length}`);
  for (const h of chain) signals.push(`Chain — forwarded onward: ${fmtQty(h.amt)} → ${labelOf(h.to)}`);

  // --- funding evidence (COUNT of qualifying transfers drives it, not one big one) ---
  let funding = false;
  const hvSolCount = (c.solAmts || []).filter(a => a >= solThresh).length || ((c.maxSol || 0) >= solThresh ? 1 : 0);
  if (hvSolCount > 0) {
    funding = true;
    const magBonus = Math.min(1.2, (c.maxSol || 0) / (solThresh * 6));
    addEvidence(0.50 * sat(hvSolCount + magBonus, 2.6), `high-value SOL ×${hvSolCount}`,
      `Funding — high-value SOL: ${hvSolCount}× ≥ ${fmtQty(solThresh)} SOL (max ${fmtQty(c.maxSol)}, total ${fmtQty(c.solVol)})`);
  }
  const hvQuoteCount = (c.quoteAmts || []).filter(a => a >= usdThresh).length || ((c.maxQuote || 0) >= usdThresh ? 1 : 0);
  if (hvQuoteCount > 0) {
    funding = true;
    addEvidence(0.48 * sat(hvQuoteCount, 2.6), `high-value stablecoin ×${hvQuoteCount}`,
      `Funding — high-value stablecoin: ${hvQuoteCount}× ≥ $${usdThresh} (max ${fmtQty(c.maxQuote)}, total ${fmtQty(c.quoteVol)})`);
  }
  const valuedTransfers = (c.tokenMoves || [])
    .map(m => ({ m, usd: priceMap[m.mint] != null ? m.amt * priceMap[m.mint] : null }))
    .filter(x => x.usd != null && x.usd >= usdThresh);
  if (valuedTransfers.length > 0) {
    funding = true;
    const maxV = valuedTransfers.reduce((a, x) => Math.max(a, x.usd), 0);
    addEvidence(0.48 * sat(valuedTransfers.length, 2.4), `high-value token transfers ×${valuedTransfers.length}`,
      `Funding — high-value token transfers: ${valuedTransfers.length}× worth ≥ $${usdThresh} each (max ≈$${fmtQty(maxV)})`);
  } else if (valueMoves.length > 0) {
    funding = true;
    addEvidence(0.30 * sat(valueMoves.length, 2.2), `high-value token move ×${valueMoves.length}`, "Funding — " + describeMove(valueMoves[0]));
  }

  // --- relationship evidence (weak, supporting only; also repetition-aware) ---
  const twoWayN = Math.min(c.in || 0, c.out || 0);
  if (c.in > 0 && c.out > 0) addEvidence(0.16 * sat(twoWayN, 3), `two-way ×${twoWayN}`, `two-way: ${c.in} in / ${c.out} out`);
  if (c.sol > 0 && c.token > 0) addEvidence(0.07, "SOL+tokens", `both SOL (${c.sol}×) and tokens (${c.token}×)`);
  if ((c.distinctAmounts || 0) >= 3) addEvidence(0.05, "varied amounts", `varied amounts (${c.distinctAmounts} distinct)`);
  const spanDays = c.firstTs && c.lastTs && isFinite(c.firstTs) ? (c.lastTs - c.firstTs) / 86400 : 0;
  if (spanDays > 1 && c.count >= 4) addEvidence(0.06 * sat(c.count / 3, 2.5), "recurring", `recurring: ${c.count} transfers over ${spanDays.toFixed(1)} days`);

  // --- timing bias (multiplier, smaller now that repetition carries the score) ---
  const biasTags = [];
  const outMoves = allMoves.filter((m) => m.dir === "out");
  const postBuy = outMoves.some((m) => m.afterBuy) ||
    outMoves.some((m) => buyEvents.some((b) => b.mint === m.mint && m.t > b.t && m.t - b.t <= 72 * 3600));
  if (postBuy) { factors.push({ mult: 1.12, label: "post-buy timing ×1.12" }); biasTags.push("moved right after a large buy"); }
  const postInflow = outMoves.some((m) => inflowTs.some((t0) => m.t > t0 && m.t - t0 <= 24 * 3600));
  if (postInflow) { factors.push({ mult: 1.06, label: "post-inflow timing ×1.06" }); biasTags.push("moved within 24h of a large inflow"); }

  // Fresh, UNFUNDED supply sender: this counterparty appeared out of nowhere —
  // the analyzed wallet never sent it anything — and its first recorded contact
  // is it SENDING tokens/supply. Classic burner-style distribution wallet.
  const supplyInMoves = (c.supplyMoves || []).filter(mm => mm.dir === "in");
  const tokenInMoves = (c.tokenMoves || []).filter(mm => mm.dir === "in");
  const firstInT = [...supplyInMoves, ...tokenInMoves].reduce((acc, mm) => Math.min(acc, mm.t || Infinity), Infinity);
  const freshSender = isFinite(firstInT) && (c.out || 0) === 0
    && c.firstTs != null && (firstInT - c.firstTs) <= 14 * 86400;
  if (freshSender) {
    addEvidence(supplyInMoves.length ? 0.30 : 0.22, "fresh unfunded sender",
      `fresh, unfunded wallet — first contact is it sending ${supplyInMoves.length ? "token supply" : "tokens"} (burner-style sender)`);
    signals.unshift(`⚠ Fresh unfunded wallet sent ${supplyInMoves.length ? "supply" : "tokens"} — no prior funding from this wallet, appeared and immediately sent`);
  }

  // Fresh, UNFUNDED supply RECEIVER — the mirror case: this counterparty
  // appeared out of nowhere, was never funded with SOL (not by the analyzed
  // wallet, and no SOL contact at all in the window), and its first recorded
  // contact is RECEIVING tokens/supply. Classic brand-new stash / side wallet.
  const supplyOutMoves = (c.supplyMoves || []).filter(mm => mm.dir === "out");
  const tokenOutMoves = (c.tokenMoves || []).filter(mm => mm.dir === "out");
  const firstOutT = [...supplyOutMoves, ...tokenOutMoves].reduce((acc, mm) => Math.min(acc, mm.t || Infinity), Infinity);
  const solOutN = c.solOutN != null ? c.solOutN : ((c.amounts || []).filter(a => a.sol && a.dir === "out").length);
  const freshReceiver = isFinite(firstOutT) && solOutN === 0 && (c.in || 0) === 0
    && c.firstTs != null && (firstOutT - c.firstTs) <= 14 * 86400;
  if (freshReceiver) {
    addEvidence(supplyOutMoves.length ? 0.30 : 0.22, "fresh unfunded receiver",
      `fresh, unfunded wallet — received ${supplyOutMoves.length ? "token supply" : "tokens"} with no SOL funding anywhere in the window (stash-style receiver)`);
    signals.unshift(`⚠ Fresh unfunded wallet received ${supplyOutMoves.length ? "supply" : "tokens"} — brand-new, never funded, ${supplyOutMoves.length ? "supply" : "tokens"} arrived directly`);
  }

  // "Ansem Derived Coin Supply Share": a very large share of a token's supply
  // (≥45%) moved between this wallet and a known Ansem wallet. These distributions
  // are a recognised source of supply-sharing FALSE POSITIVES, so the lead stays
  // visible but is clearly tagged and its certainty damped.
  const ansemSet = new Set(opts.ansem || []);
  const ansemShare = ansemSet.has(c.addr) && (c.supplyMoves || []).some(m => (m.supplyPct || 0) >= 0.45);
  if (ansemShare) {
    factors.push({ mult: 0.45, label: "Ansem-derived supply share ×0.45" });
    biasTags.push("≥45% of a token's supply moved with a known Ansem wallet — a pattern known to produce false positives");
    signals.unshift("⚠ Ansem Derived Coin Supply Share — ≥45% of supply moved with a known Ansem wallet (certainty damped)");
  }

  // User-feedback calibration: corrections you recorded on results of this
  // evidence family lower the whole family's weight — shown transparently as a
  // factor in the breakdown so the damping is never hidden.
  const calib = opts.calib || null;
  if (calib) {
    const fam = (moves.length > 0 || !!split) ? "supply" : (funding ? "funding" : null);
    const cm = fam ? calib[fam] : null;
    if (cm && cm < 0.999) {
      factors.push({ mult: cm, label: `feedback calibration ×${cm.toFixed(2)}` });
      biasTags.push(`${calib.counts[fam]} recorded correction(s) on ${fam}-type results lowered this family's weight`);
    }
  }

  const evidence = 1 - factors.filter(f => f.w).reduce((p, f) => p * (1 - f.w), 1);
  const biasMult = factors.filter(f => f.mult).reduce((p, f) => p * f.mult, 1);
  const certainty = Math.round(100 * Math.min(0.97, evidence * biasMult));
  const certBand = certainty >= 75 ? "HIGH" : certainty >= 45 ? "MED" : "LOW";

  // --- bundle score (also repetition-driven & saturating) ---
  const bundleHits = (c.bundle && c.bundle.evidence) ? c.bundle.evidence.length : 0;
  const bundleIntensity =
    (split ? 0.8 + 0.5 * (split.others || 0) : 0) +   // multi-recipient split
    (chain.length ? 0.7 * chain.length : 0) +         // chain hops
    (0.7 * bundleHits);                               // cross-wallet correlated behaviours
  const bundleScore = Math.round(100 * sat(bundleIntensity, 2.2));
  const bundleEvidence = [
    ...(split ? [`one buy split across ${split.others + 1} wallets`] : []),
    ...(chain.length ? [`forwarded a large chunk onward through ${chain.length} hop(s)`] : []),
    ...((c.bundle && c.bundle.evidence) || []),
  ];
  const bundleRisk = bundleScore >= 55;   // needs genuinely repeated structure, not one split

  // --- mutual token tickers (which tokens both wallets moved between them) ---
  const tickerSet = [];
  const seenSym = new Set();
  for (const m of (c.tokenMoves || [])) {
    const sym = m.symbol || (m.mint ? m.mint.slice(0, 4) + "…" : null);
    if (sym && !seenSym.has(sym)) { seenSym.add(sym); tickerSet.push(sym); }
  }
  const mutualTokens = tickerSet.slice(0, 8);

  // --- funding-source badge (if the suspect's own first funder is a known source) ---
  let fundedBy = null;
  const ff = c.bundle && c.bundle.firstFunder;
  if (ff) { const hit = labelFor(ff); if (hit) fundedBy = hit.label.replace(/ \((labeled|added)\)$/, ""); }

  // --- full addresses for copying ---
  const refs = [{ label: "suspect wallet", addr: c.addr }];
  for (const m of [...moves.slice(0, 3), ...valueMoves.slice(0, 2)]) refs.push({ label: `${m.symbol || "token"} mint (CA)`, addr: m.mint });
  if (split) refs.push({ label: `${split.symbol || "split token"} mint (CA)`, addr: split.mint });
  for (const h of chain) refs.push({ label: "chunk forwarded to", addr: h.to });
  for (const r of (c.bundle && c.bundle.refs) || []) refs.push(r);
  const seenRef = new Set();
  const uniqueRefs = refs.filter(r => r.addr && !seenRef.has(r.addr) && seenRef.add(r.addr));

  // A wallet is a SUSPECT only with real evidence (supply sharing or high-value
  // funding). Wallets that merely transferred a handful of times with weak
  // circumstantial signals are NOT promoted — they remain visible under "other
  // interactions" with their (damped) score, never inflating a suspect group.
  const supply = moves.length > 0 || !!split;
  const qualifies = supply || funding || freshSender || freshReceiver;
  return {
    ...c, refs: uniqueRefs, signals, biasTags, factors, certainty, certBand,
    evidencePct: Math.round(100 * evidence), biasMult, funding, freshSender, freshReceiver,
    bundleScore, bundleEvidence, bundleRisk, spanDays, qualifies, ansemShare,
    mutualTokens, fundedBy,
    group: supply ? "supply" : (funding ? "funding" : ((freshSender || freshReceiver) ? "supply" : "other")),
    alsoFunding: supply && funding,
    headline: signals[0] || `${c.count} transfer(s) · ${c.in} in / ${c.out} out`,
  };
}

// Turn recorded user feedback into evidence-family calibration multipliers.
// Every explicit correction (⚑ flag incorrect, ✓ non-suspicious transfer,
// ⚡ connector mark) counts against the evidence family that produced that
// result, so ALL remaining results of the same family — and the constellation —
// recalibrate, not just the corrected one. Each correction damps the family
// ×0.93 (compounding), floored at ×0.55 so genuine evidence is never erased;
// undoing feedback in Settings restores the weight automatically.
function feedbackCalibration(feedback) {
  const counts = { supply: 0, funding: 0 };
  for (const f of feedback || []) {
    if (!(f.kind === "incorrect" || f.kind === "supply-ok" || f.kind === "connector")) continue;
    const g = f.group || (f.kind === "supply-ok" ? "supply" : null);
    if (g === "supply" || g === "funding") counts[g]++;
  }
  const damp = (n) => Math.max(0.55, Math.pow(0.93, n));
  return { supply: damp(counts.supply), funding: damp(counts.funding), counts };
}

function eligibleWallet(c, ignored) {
  return !ignored.has(c.addr) && c.cls?.kind === "wallet" && !c.botLike && !c.exchangeLike;
}

function findSideWallets(topCounterparties, opts = {}) {
  const ignored = new Set(opts.ignored || []);
  return topCounterparties
    .filter(c => eligibleWallet(c, ignored))
    .map(c => evaluateWallet(c, opts))
    .filter(s => s.qualifies)
    .sort((a, b) => b.certainty - a.certainty || b.bundleScore - a.bundleScore || b.count - a.count);
}

// Wallet interactions that did NOT qualify as suspects — shown too, so low-
// suspicion connections stay visible instead of silently disappearing.
function findOtherWallets(topCounterparties, opts = {}) {
  const ignored = new Set(opts.ignored || []);
  return topCounterparties
    .filter(c => eligibleWallet(c, ignored))
    .map(c => evaluateWallet(c, opts))
    .filter(s => !s.qualifies)
    .sort((a, b) => b.certainty - a.certainty || b.count - a.count);
}

// ============================================================================
// CA LAUNCH SCAN (test branch) — paste a token mint, get the launch-window
// buyer list with the SAME rationales used everywhere else: bundled buys,
// shared funding sources, fresh wallets, identical amounts, supply share.
// ============================================================================

// Is this address a token MINT (a CA), rather than a wallet? One RPC call.
async function isTokenMint(addr, apiKey) {
  if (!apiKey) return false;
  try {
    const res = await fetch(`https://mainnet.helius-rpc.com/?api-key=${apiKey}`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: "wt-mint", method: "getMultipleAccounts", params: [[addr], { encoding: "jsonParsed" }] }),
    });
    if (!res.ok) return false;
    const v = (await res.json()).result?.value?.[0];
    // Mints are token-program accounts whose parsed type is "mint" (token
    // ACCOUNTS parse as "account" — those are infrastructure, not CAs).
    return !!v && TOKEN_PROGRAMS.has(v.owner) && v.data?.parsed?.type === "mint";
  } catch { return false; }
}

// Noisy-OR with per-family decay — same combining rationale as the wallet
// outcome score: independent evidence families multiply misses; repeats within
// a family decay ×0.5 so ten copies of one signal can't manufacture certainty.
function combineLaunchEvidence(evidence) {
  const byFam = {};
  for (const e of evidence) (byFam[e.fam] = byFam[e.fam] || []).push(e.p);
  let miss = 1;
  for (const fam of Object.keys(byFam)) {
    const ps = byFam[fam].sort((a, b) => b - a);
    ps.forEach((p, i) => { miss *= (1 - p * Math.pow(0.5, i)); });
  }
  return Math.min(97, Math.round((1 - miss) * 100));
}

const CA_LAUNCH_WINDOW_SEC = 3 * 3600;  // txs within 3 HOURS of the first one count as "launch"
const CA_MAX_BUYERS = 60;               // list cap (earliest first)
const CA_FUND_LOOKUPS = 25;             // bounded per-buyer first-page lookups

// Scan a token's FIRST transactions and profile the earliest receiving wallets.
async function analyzeLaunch(mint, d, progress = () => {}) {
  progress("Fetching token info…");
  const supplies = await fetchTokenSupplies([mint], d.apiKey);
  const symbol = supplies[mint]?.symbol || null;
  const supplyUi = supplies[mint]?.supplyUi || null;

  // Scan depth follows the SAME search parameter as wallet analysis — the
  // "Transactions analyzed" filter (100–50,000).
  const CA_TX_TARGET = Math.max(100, Math.min(50000, Number(d.txDepth) || 500));

  // Use Helius's ENRICHED, token-aware address endpoint in ASCENDING order —
  // sort-order=asc genuinely returns the token's OLDEST transactions first
  // (its launch), and this index catches the swaps a raw signature walk misses.
  // Page FORWARD (older→newer) with the correct `after-signature` cursor until
  // we've collected the user's tx-count value.
  progress("Fetching the token's first transactions…");
  const base = `https://api.helius.xyz/v0/addresses/${mint}/transactions?api-key=${d.apiKey}&limit=100&sort-order=asc`;
  let txs = [], afterSig = null, reachedEnd = false;
  const seen = new Set();
  const MAX_PAGES = Math.ceil(CA_TX_TARGET / 100) + 4;
  for (let pg = 0; pg < MAX_PAGES && txs.length < CA_TX_TARGET; pg++) {
    let batch;
    try {
      const res = await fetch(afterSig ? `${base}&after-signature=${afterSig}` : base);
      if (!res.ok) { if (pg === 0) throw new Error(`Launch lookup failed (HTTP ${res.status})`); break; }
      batch = await res.json();
    } catch (e) { if (pg === 0) throw e; break; }
    if (!Array.isArray(batch) || batch.length === 0) { reachedEnd = true; break; }
    const fresh = batch.filter(t => t && t.signature && !seen.has(t.signature));
    if (fresh.length === 0) { reachedEnd = true; break; }      // cursor stopped advancing → end
    for (const t of fresh) seen.add(t.signature);
    txs.push(...fresh);
    afterSig = batch[batch.length - 1].signature;              // page forward from the newest of this page
    progress(`Fetching the token's first transactions… ${Math.min(txs.length, CA_TX_TARGET)}`);
    if (batch.length < 100) { reachedEnd = true; break; }      // token has fewer txs than the target
    await new Promise(rs => setTimeout(rs, 120));
  }
  if (txs.length === 0) throw new Error("No transactions found for this CA.");
  txs = txs.filter(t => t && t.timestamp).sort((a, b) => a.timestamp - b.timestamp).slice(0, CA_TX_TARGET);
  const scanTruncated = !reachedEnd && txs.length >= CA_TX_TARGET;   // more launch history exists beyond the scan depth

  const launchTs = txs[0].timestamp;
  const deployer = txs[0].feePayer || null;
  const windowEnd = launchTs + CA_LAUNCH_WINDOW_SEC;

  // ---- collect receivers of the token inside the launch window ----
  const buyers = new Map();               // addr -> profile
  let volume = 0;
  txs.forEach((tx, idx) => {
    if (!tx.timestamp || tx.timestamp > windowEnd) return;
    const t = tx.timestamp;
    for (const tt of tx.tokenTransfers || []) {
      if (tt.mint !== mint) continue;
      const to = tt.toUserAccount;
      const amt = Number(tt.tokenAmount || 0);
      if (!to || to === mint || !(amt > 0)) continue;
      const b = buyers.get(to) || { addr: to, firstT: t, firstIdx: idx, tok: 0, sol: 0, n: 0, viaSwap: false, sameTx: new Set(), txSigs: new Set() };
      b.tok += amt; b.n++;
      if (t < b.firstT) { b.firstT = t; b.firstIdx = idx; }
      if (tx.events?.swap || tx.type === "SWAP") b.viaSwap = true;
      // GAS-FEE fingerprint: the exact fee this buyer paid on its own buy tx.
      // Identical non-default fees across wallets = same bot config.
      if (b.feeLamports == null && tx.feePayer === to && tx.fee != null) b.feeLamports = Number(tx.fee);
      b.txSigs.add(tx.signature || String(idx));
      // SOL the receiver PAID in the same tx (their native out) ≈ buy cost
      for (const nt of tx.nativeTransfers || []) {
        if (nt.fromUserAccount === to) b.sol += Number(nt.amount || 0) / LAMPORTS;
      }
      buyers.set(to, b);
      volume += amt;
    }
  });

  // ---- classify: keep real wallets, drop pools/PDAs/programs ----
  progress("Classifying early receivers…");
  const addrs = [...buyers.keys()];
  const cls = await classifyCounterparties(addrs, d.apiKey);
  const list = [...buyers.values()]
    .filter(b => {
      const k = cls[b.addr]?.kind;
      return k === "wallet" || k === "unknown";        // pools/curves/token accounts are infrastructure
    })
    .sort((a, b) => a.firstIdx - b.firstIdx)
    .slice(0, CA_MAX_BUYERS);
  for (const b of list) { b.cls = cls[b.addr]; b.share = supplyUi ? b.tok / supplyUi : (volume ? b.tok / volume : null); b.shareOfEarly = volume ? b.tok / volume : null; }

  // Same-TX multi-wallet delivery = the classic bundler signature: one
  // transaction handing the token to SEVERAL distinct WALLETS at once.
  // Built from the filtered wallet list so the pool/curve receiving liquidity
  // in the mint tx can never count as somebody's "bundle mate".
  // v5.7.6.c: only bundle-ELIGIBLE buys (supply-relative size gate, see
  // caBundleEligible) participate in bundle detection at all — dust legs
  // neither form, join, nor count toward bundles. The unfiltered maps are
  // kept only to FLAG dust buys that showed bundle-style timing.
  const bundleOk = caBundleEligible(list);
  const byTx = {};
  const byTxAll = {};
  for (const b of list) for (const sig of b.txSigs) {
    (byTxAll[sig] = byTxAll[sig] || []).push(b.addr);
    if (bundleOk(b)) (byTx[sig] = byTx[sig] || []).push(b.addr);
  }

  // ---- funding pass: who seeded each early buyer, and how old were they? ----
  progress("Tracing buyer funding sources…");
  let looked = 0;
  for (const b of list) {
    if (looked >= CA_FUND_LOOKUPS) break;
    looked++;
    try {
      const r = await fetch(`https://api.helius.xyz/v0/addresses/${b.addr}/transactions?api-key=${d.apiKey}&limit=10&sort-order=asc`);
      const first = r.ok ? await r.json() : [];
      if (Array.isArray(first) && first[0]?.timestamp) {
        b.walletFirstTs = first[0].timestamp;
        b.ageAtLaunchSec = launchTs - first[0].timestamp;          // negative = born after launch
        b.freshAtLaunch = b.ageAtLaunchSec <= 3 * 86400;           // ≤3d old (or newer) when the token launched
        // first inbound SOL from someone else = the funder (NO floor — dust counts)
        outer:
        for (const tx of first) {
          for (const nt of tx.nativeTransfers || []) {
            const amt = Number(nt.amount || 0) / LAMPORTS;
            if (nt.toUserAccount === b.addr && nt.fromUserAccount && nt.fromUserAccount !== b.addr && amt > 0) {
              b.funder = nt.fromUserAccount; b.funderAmt = amt; break outer;
            }
          }
        }
      }
    } catch { /* additive */ }
    await new Promise(rs => setTimeout(rs, 130));
    progress(`Tracing buyer funding sources… ${looked}/${Math.min(list.length, CA_FUND_LOOKUPS)}`);
  }

  // ---- cross-wallet patterns ----
  const bySecond = {};
  const bySecondAll = {};
  for (const b of list) {
    (bySecondAll[b.firstT] = bySecondAll[b.firstT] || []).push(b.addr);
    if (bundleOk(b)) (bySecond[b.firstT] = bySecond[b.firstT] || []).push(b.addr);
  }
  const byFunder = {};
  for (const b of list) if (b.funder) (byFunder[b.funder] = byFunder[b.funder] || []).push(b.addr);
  // identical buy sizes (within 2%) — chained into size clusters
  const sorted = [...list].sort((a, b) => a.tok - b.tok);
  const sizeGroups = [];
  let run = [];
  for (let i = 0; i < sorted.length; i++) {
    if (run.length && sorted[i].tok > 0 && (sorted[i].tok - run[run.length - 1].tok) / sorted[i].tok <= 0.02) run.push(sorted[i]);
    else { if (run.length >= 2) sizeGroups.push(run); run = [sorted[i]]; }
  }
  if (run.length >= 2) sizeGroups.push(run);
  for (const g of sizeGroups) for (const b of g) b.identAmt = true;
  // SAME GAS FEE groups: exact identical fee, non-default (5000 lamports is the
  // base fee everyone pays — only distinctive priority-fee configs count).
  const byFee = {};
  for (const b of list) if (b.feeLamports != null && b.feeLamports !== 5000) (byFee[b.feeLamports] = byFee[b.feeLamports] || []).push(b);
  const gasGroups = Object.entries(byFee).filter(([, m]) => m.length >= 2)
    .sort((A, B) => B[1].length - A[1].length);
  gasGroups.forEach(([fee, members], gi) => { for (const b of members) { b.gasGroup = gi + 1; b.gasGroupFee = Number(fee); } });

  // ---- FUNDING-RELAY CHAINS: an old wallet funds a fresh wallet, which then
  // funds ANOTHER fresh wallet (old → new → new). Built from the early-buyer set:
  // seededBy maps a buyer that acted as a funder to the buyers it seeded. ----
  const buyerByAddr = new Map(list.map(b => [b.addr, b]));
  const seededBy = {};
  for (const b of list) if (b.funder && buyerByAddr.has(b.funder)) (seededBy[b.funder] = seededBy[b.funder] || []).push(b);

  // ---- flags + certainty (same combining rationale as wallet analysis) ----
  const calib = feedbackCalibration(d.feedback);
  for (const b of list) {
    const ev = [];
    b.flags = [];
    if (bundleOk(b)) {
      const sameTxMates = Math.max(0, Math.max(...[...b.txSigs].map(s => (byTx[s] || []).length), 0) - 1);
      const sameSecMates = (bySecond[b.firstT] || []).length - 1;
      if (sameTxMates >= 1) { b.bundleMates = sameTxMates; b.flags.push(`bundled buy — token delivered to ${sameTxMates + 1} wallets in ONE transaction`); ev.push({ fam: "bundle", p: 0.5 }); }
      else if (sameSecMates >= 1) { b.bundleMates = sameSecMates; b.timingOnly = true; b.flags.push(`bundle-timed — first buy in the same second as ${sameSecMates} other wallet${sameSecMates > 1 ? "s" : ""} (timing only — weak evidence on its own)`); ev.push({ fam: "bundle", p: 0.38 }); }
    } else {
      // Transparency: the buy showed bundle-style timing but is far below
      // expectancy for a bundle allocation, so it is NOT bundle-classified.
      const timedMates = Math.max((bySecondAll[b.firstT] || []).length - 1,
        Math.max(...[...b.txSigs].map(s => (byTxAll[s] || []).length), 1) - 1);
      b.subExpectancy = true;
      if (timedMates >= 1) b.flags.push(`below-expectancy buy${b.share != null ? ` — ${(b.share * 100).toFixed(3)}% of supply` : ""} — bundle-style timing with ${timedMates} other wallet${timedMates > 1 ? "s" : ""} IGNORED (too small to be bundle material)`);
    }
    const funderKids = b.funder ? (byFunder[b.funder] || []).length : 0;
    if (funderKids >= 2) {
      const fdb = labelFor(b.funder);
      const isConn = (d.connectors || []).includes(b.funder);
      b.sharedFunder = true;
      // v5.7.5.c: a PERSONAL shared funder makes its kids a funding BUNDLE —
      // the primary bundle organizer. Connector relayers and labelled wallets
      // fund everyone, so they stay cohort-only and never form bundles.
      // v5.7.6.c: dust buys can't join funding bundles either (size gate).
      b.fundBundle = !isConn && !fdb && bundleOk(b);
      b.flags.push(`shared funding source — ${fundingSourceName(b.funder, d)} funded ${funderKids} of the early buyers${isConn ? " (connector relayer — expected to fund many wallets)" : b.fundBundle ? " — grouped as one funding bundle" : ""}`);
      ev.push({ fam: "funding", p: isConn ? 0.20 : fdb ? 0.30 : 0.42 });   // relayers/CEX hot wallets fund everyone — much weaker than a personal hub
    }
    if (b.funder && deployer && b.funder === deployer) { b.devFunded = true; b.flags.push("funded by the DEPLOYER wallet"); ev.push({ fam: "funding", p: 0.45 }); }
    if (b.addr === deployer) { b.isDeployer = true; b.flags.push("this IS the deployer wallet"); }
    if (b.freshAtLaunch) { b.flags.push(`fresh wallet — ${b.ageAtLaunchSec <= 0 ? "created AT/after launch" : "only " + fmtAge(b.ageAtLaunchSec) + " old at launch"}`); ev.push({ fam: "fresh", p: 0.28 }); }
    // Fresh wallet with NO funding at all that still received the token — its
    // first-page lookup ran (walletFirstTs known) and found no inbound SOL.
    if (b.freshAtLaunch && b.walletFirstTs != null && !b.funder) {
      b.unfundedFresh = true;
      b.flags.push("fresh wallet, NO funding found — received the token with zero SOL history");
      ev.push({ fam: "fresh", p: 0.42 });
    }
    // FUNDING-RELAY CHAIN (soft): this fresh wallet was itself seeded, then passed
    // funds to ANOTHER fresh early buyer — an old→new→new laundering hop.
    const relayKids = (seededBy[b.addr] || []).filter(k => k.freshAtLaunch && k.addr !== b.addr);
    if (b.freshAtLaunch && relayKids.length >= 1) {
      b.fundingRelay = true; b.relayKids = relayKids.length;
      b.flags.push(`funding relay — fresh wallet${b.funder ? `, seeded by ${fundingSourceName(b.funder, d)},` : ""} then funded ${relayKids.length} other FRESH early buyer${relayKids.length > 1 ? "s" : ""} (old→new→new chain)`);
      ev.push({ fam: "fundingchain", p: 0.36 });
    }
    // downstream end of such a chain: seeded THROUGH a fresh relay wallet
    const relayParent = b.funder && buyerByAddr.get(b.funder);
    if (relayParent && relayParent.freshAtLaunch && b.freshAtLaunch) {
      b.viaRelay = true;
      b.flags.push(`seeded through a fresh relay wallet (${fundingSourceName(b.funder, d)}) — part of an old→new→new funding chain`);
      ev.push({ fam: "fundingchain", p: 0.30 });
    }
    if (b.identAmt) { b.flags.push("near-identical buy size to another early wallet (≤2% apart)"); ev.push({ fam: "amount", p: 0.24 }); }
    if (b.gasGroup) { b.flags.push(`same gas fee as ${(byFee[b.gasGroupFee] || []).length - 1} other early buyer(s) — identical priority-fee config (fee group #${b.gasGroup})`); ev.push({ fam: "gasfee", p: 0.30 }); }
    if (b.share != null && b.share >= 0.005) {
      const pct = b.share * 100;
      b.flags.push(`took ${pct.toFixed(pct >= 10 ? 0 : 1)}% of total supply in the launch window${b.share >= 0.15 ? " — DOMINANT single-wallet grab" : ""}`);
      // A large single-wallet supply grab is one of the strongest launch signals
      // there is — a wallet taking a big slice at launch is almost always an
      // insider/sniper/scam. Scale HARD so a whale is HIGH on its own, instead of
      // the old flat 0.5 cap that buried a 70%-of-supply buyer in the MEDIUM band.
      const s = b.share;
      const p = s >= 0.20 ? Math.min(0.97, 0.86 + (s - 0.20) * 0.4)   // 20%→0.86 … ≥40%→~0.95
        : 0.22 + s * 3.2;                                              // 1%→0.25, 10%→0.54, 15%→0.70
      ev.push({ fam: "supply", p });
    }
    if (b.firstIdx <= 3 && !b.isDeployer) { b.flags.push(`instant snipe — transaction #${b.firstIdx + 1} of the token's existence`); ev.push({ fam: "timing", p: 0.2 }); }
    // Feedback calibration damps the same families it damps everywhere else.
    let cert = combineLaunchEvidence(ev);
    const rawCert = cert;
    cert = Math.round(cert * (ev.some(e => e.fam === "funding") ? calib.funding : 1) * (ev.some(e => e.fam === "supply") ? calib.supply : 1));
    b.certainty = Math.max(0, Math.min(97, cert));
    // A dominant supply grab is HIGH by definition — calibration can't talk it down.
    if (b.share != null && b.share >= 0.15) b.certainty = Math.max(b.certainty, 88);
    b.rawCertainty = rawCert;
    b.qualifies = b.certainty >= 25 || !!b.bundleMates || b.sharedFunder || b.devFunded;
    b.txSigs = [...b.txSigs];                             // Sets don't survive storage
  }

  // ---- COMMON GROUND between the early buyers — the visual guide the list
  // shows above the results: gas-fee groups, shared funding, same-second
  // bundles and identical sizes, each with its members. ----
  const commonGround = {
    gas: gasGroups.map(([fee, members], gi) => ({ id: gi + 1, fee: Number(fee), members: members.map(m => m.addr) })),
    funding: Object.entries(byFunder).filter(([, kids]) => kids.length >= 2).map(([funder, kids]) => ({ funder, members: kids })),
    bundles: Object.entries(bySecond).filter(([, m]) => m.length >= 2).map(([t, m]) => ({ t: Number(t), members: m })),
    sizes: sizeGroups.map(g => ({ tok: g[0].tok, members: g.map(m => m.addr) })),
  };

  return {
    mint, symbol, supplyUi, launchTs, deployer,
    txScanned: txs.length, txTarget: CA_TX_TARGET, scanTruncated,
    windowSec: CA_LAUNCH_WINDOW_SEC,
    buyers: list.map(({ sameTx, ...rest }) => rest),
    funderGroups: Object.fromEntries(Object.entries(byFunder).filter(([, kids]) => kids.length >= 1)),
    commonGround,
    fetchedAt: Date.now(),
  };
}

// Best display name for a FUNDING SOURCE address, in priority order: your own
// wallet label → connector flag (Phantom-style relayers, applied automatically
// everywhere funding sources appear) → funding-DB label → short address.
function fundingSourceName(addr, settings) {
  if (!addr) return "";
  const nm = ((settings?.wallets) || []).find(w => w.address === addr && w.name)?.name;
  if (nm) return `[${nm}]`;
  if (((settings?.connectors) || []).includes(addr)) return "⚡ Connector (relayer)";
  const db = labelFor(addr);
  if (db) return db.label.replace(/ \((labeled|added)\)$/, "");
  return shortAddr(addr);
}

// ---------- formatting ----------
function fmtNum(n, digits = 2) {
  if (n == null) return "–";
  if (n >= 1e9) return (n / 1e9).toFixed(2) + "B";
  if (n >= 1e6) return (n / 1e6).toFixed(2) + "M";
  if (n >= 1e3) return (n / 1e3).toFixed(2) + "K";
  if (n >= 1) return n.toFixed(digits);
  return n.toPrecision(3);
}
function fmtUsd(n) { return n == null ? "" : "$" + fmtNum(n); }
function fmtDuration(sec) {
  if (sec == null) return "–";
  if (sec < 3600) return Math.round(sec / 60) + "m";
  if (sec < 86400) return (sec / 3600).toFixed(1) + "h";
  return (sec / 86400).toFixed(1) + "d";
}
function shortAddr(a) { return a.length > 12 ? a.slice(0, 5) + "…" + a.slice(-5) : a; }
function fmtDate(ts) { return ts ? new Date(ts * 1000).toLocaleDateString() : "?"; }
// Human wallet-age wording (years / months / days) for the funding flags.
function fmtAge(sec) {
  if (sec == null) return "unknown age";
  const d = sec / 86400;
  if (d >= 365) return (d / 365).toFixed(1) + " yr";
  if (d >= 30) return Math.round(d / 30) + " mo";
  if (d >= 1) { const n = Math.round(d); return n + (n === 1 ? " day" : " days"); }
  return Math.max(1, Math.round(sec / 3600)) + "h";
}
function escHtml(s) { return String(s).replace(/[&<>]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c])); }

// ---------- UI ----------
const $ = (id) => document.getElementById(id);
let currentAddress = null;
let currentView = "list";     // "list" | "detail" | "settings" — for returning from settings
let settingsReturnView = "list";   // the view that was open before Settings

function show(view) {
  $("listPanel").classList.toggle("hidden", view !== "list");
  $("detailPanel").classList.toggle("hidden", view !== "detail");
  $("settingsPanel").classList.toggle("hidden", view !== "settings");
  const ca = $("caPanel"); if (ca) ca.classList.toggle("hidden", view !== "ca");
  $("navArrows").classList.toggle("hidden", view !== "detail");
  $("navHomeWrap").classList.toggle("hidden", view !== "detail");
  $("interPanel").classList.add("hidden");
  $("mapPanel").classList.add("hidden");
  $("sellsPanel").classList.add("hidden");
  currentView = view;
  // Land at the top of each view — otherwise switching from a long view to a
  // shorter one leaves the page scrolled to the bottom.
  window.scrollTo(0, 0);
}

// ---------- section navigation arrows ----------
function navSections() {
  return ["sectionStats", "fundingSection", "sideWalletSection", "sectionHoldings", "sellsSection", "counterpartiesSection", "programsSection"]
    .map($)
    .filter(el => el && !el.classList.contains("hidden") && el.offsetParent !== null);
}

function navJump(dir) {
  const sections = navSections();
  if (!sections.length) return;
  const stickyOffset = 96; // header + sticky address bar
  const pos = window.scrollY + stickyOffset + 2;
  const tops = sections.map(el => el.getBoundingClientRect().top + window.scrollY);
  let target;
  if (dir > 0) target = tops.find(t => t > pos + 4);
  else [...tops].reverse().some(t => { if (t < pos - 4) { target = t; return true; } return false; });
  if (target === undefined) target = dir > 0 ? tops[tops.length - 1] : 0;
  window.scrollTo({ top: Math.max(0, target - stickyOffset), behavior: "smooth" });
}

// ---------- multi-wallet selection & batch refresh ----------
let selectMode = false;
const selectedWallets = new Set();
let batchTargets = [];
let batchStop = false;

function updateSelCount() {
  const n = selectedWallets.size;
  $("selCount").textContent = selectMode ? `${n} selected` : "";
  $("refreshSelectedBtn").disabled = n === 0;
}
function confirmBatch(addresses) {
  batchTargets = (addresses || []).filter(Boolean);
  if (!batchTargets.length) return;
  const n = batchTargets.length;
  $("batchWarnDetail").textContent = `${n} wallet${n > 1 ? "s" : ""} selected. Each one is re-fetched and fully re-analyzed against the Helius API, one after another — deep histories and large selections add up fast.`;
  $("batchWarn").classList.remove("hidden");
}
async function runBatch() {
  $("batchWarn").classList.add("hidden");
  const d0 = await store.get();
  if (!d0.apiKey) { showError("addError", "No API key set. Open Settings and paste your free Helius API key."); return; }
  $("batchProgress").classList.remove("hidden");
  $("batchStopBtn").textContent = "Stop after current";
  batchStop = false;
  const total = batchTargets.length;
  let done = 0, failed = 0;
  for (const addr of batchTargets) {
    if (batchStop) break;
    $("batchProgressMsg").textContent = `Wallet ${done + 1} of ${total} · ${shortAddr(addr)}`;
    $("batchBarFill").style.width = `${Math.round((done / total) * 100)}%`;
    try {
      const d = await store.get();       // fresh each time so the cache accumulates
      await runAnalysis(addr, d, (m) => { $("batchSubMsg").textContent = m; });
    } catch (e) { failed++; $("batchSubMsg").textContent = "Error: " + (e && e.message ? e.message : String(e)); }
    done++;
  }
  $("batchBarFill").style.width = "100%";
  $("batchProgressMsg").textContent = batchStop
    ? `Stopped after ${done} of ${total}${failed ? ` · ${failed} failed` : ""}.`
    : `Done — ${done - failed} of ${total} refreshed${failed ? ` · ${failed} failed` : ""}.`;
  $("batchSubMsg").textContent = "";
  selectMode = false; selectedWallets.clear();
  $("selectModeBtn").textContent = "Select"; $("selectModeBtn").classList.remove("active");
  document.querySelector(".sel-all").classList.add("hidden");
  $("refreshSelectedBtn").classList.add("hidden");
  setTimeout(() => { $("batchProgress").classList.add("hidden"); renderWalletList(); }, 1500);
}

// ---- Investigation chain: pinned wallets shown on the list + highlighted on maps ----
async function addToChain(address, name, parentOverride, parentLabel) {
  if (!address) return;
  const d = await store.get();
  d.chain = d.chain || [];
  if (!d.chain.some(c => c.address === address)) {
    // The wallet being ANALYZED at add-time becomes the PARENT — children group
    // under it so each saved investigation reads as one unit. CA launch scans
    // pass the CA as parentOverride, making a "CA Chain of Investigation" group.
    const parent = parentOverride !== undefined ? parentOverride : (currentAddress && currentAddress !== address ? currentAddress : null);
    d.chain.push({ address, parent, parentLabel: parentLabel || "", name: name || "", note: "", added: Date.now() });
    await store.set({ chain: d.chain });
    if (lastSettings) lastSettings.chain = d.chain;
  }
  $("statusLine").textContent = "Added to investigation chain.";
  setTimeout(() => ($("statusLine").textContent = ""), 1800);
  renderChain();
}
function inChain(addr) { return (lastSettings?.chain || []).some(c => c.address === addr); }

// Purge every cached artifact for an address/mint so a removed item leaves no
// stale analysis behind: the wallet-analysis cache, the CA launch-scan cache, and
// any saved constellation layout (wallet "w:" and CA "c:" keys).
function purgeCache(d, addr) {
  if (!d || !addr) return;
  if (d.cache) delete d.cache[addr];
  if (d.caCache) delete d.caCache[addr];
  if (d.mapLayouts) { delete d.mapLayouts["w:" + addr]; delete d.mapLayouts["c:" + addr]; }
}

// ---- Results search: filter a rendered result list (CA buyers / wallet
// suspects) by address or name. Inline display beats the row's own !important
// styles and any band-collapse, so matches always show and non-matches hide. ----
function filterResultRows(inp, list, countEl) {
  const q = (inp.value || "").trim().toLowerCase();
  const searching = !!q;
  list.classList.toggle("searching", searching);
  let shown = 0, total = 0;
  for (const r of list.querySelectorAll("li")) {
    if (r.classList.contains("ca-band-head") || r.classList.contains("group-header") || r.classList.contains("suspect-group-head")) continue;
    total++;
    const title = r.querySelector("[title]")?.getAttribute("title") || "";
    const hay = ((r.dataset.search || "") + " " + title + " " + r.textContent).toLowerCase();
    const match = !searching || hay.includes(q);
    if (searching) r.style.setProperty("display", match ? "block" : "none", "important");
    else r.style.removeProperty("display");
    if (searching && match) shown++;
  }
  if (countEl) countEl.textContent = searching ? `${shown} / ${total}` : "";
}
function wireResultsSearch(inputId, listId, countId, clearId) {
  const inp = $(inputId), list = $(listId), countEl = $(countId), clear = $(clearId);
  if (!inp || !list || inp._wired) return;
  inp._wired = true;
  const run = () => filterResultRows(inp, list, countEl);
  inp.addEventListener("input", run);
  if (clear) clear.addEventListener("click", () => { inp.value = ""; run(); inp.focus(); });
}
// Show the search box once a list has enough rows to be worth searching, and
// re-apply any active query after the list re-renders.
function syncResultsSearch(inputId, listId, wrapId, countId) {
  const inp = $(inputId), list = $(listId), wrap = $(wrapId);
  if (!inp || !list || !wrap) return;
  const rows = [...list.querySelectorAll("li")].filter(r => !r.classList.contains("ca-band-head") && !r.classList.contains("group-header") && !r.classList.contains("suspect-group-head")).length;
  wrap.classList.toggle("hidden", rows < 4);
  if (rows < 4 && inp.value) inp.value = "";
  filterResultRows(inp, list, $(countId));
}

async function removeFromChain(address) {
  const d = await store.get();
  d.chain = (d.chain || []).filter(c => c.address !== address);
  // If this address isn't ALSO a saved wallet/CA, it's fully removed — drop its cache.
  const stillSaved = (d.wallets || []).some(w => w.address === address) || (d.cas || []).some(c => c.address === address);
  if (!stillSaved) purgeCache(d, address);
  await store.set({ chain: d.chain, cache: d.cache, caCache: d.caCache, mapLayouts: d.mapLayouts });
  if (lastSettings) { lastSettings.chain = d.chain; lastSettings.cache = d.cache; lastSettings.caCache = d.caCache; lastSettings.mapLayouts = d.mapLayouts; }
  $("statusLine").textContent = "Removed from investigation chain.";
  setTimeout(() => ($("statusLine").textContent = ""), 1800);
  renderChain();
}

async function renderChain() {
  const d = await store.get();
  const chain = d.chain || [];
  const sec = $("chainSection");
  if (!sec) return;
  sec.classList.toggle("hidden", chain.length === 0);
  const walletNames = Object.fromEntries((d.wallets || []).filter(w => w.name).map(w => [w.address, w.name]));
  const ul = $("chainList");
  ul.innerHTML = "";

  // Group children under the tracked wallet that was being analyzed when they
  // were added (their parent). Each group reads as one saved investigation.
  const groups = new Map();               // parentAddr ("" = unassigned) -> entries
  for (const c of chain) {
    const key = c.parent || "";
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(c);
  }
  const groupKeys = [...groups.keys()].sort((a, b) => (a === "") - (b === ""));  // unassigned last

  let gi = 0;
  for (const parentAddr of groupKeys) {
    const entries = groups.get(parentAddr);
    const gid = "cg" + (gi++);
    const head = document.createElement("li");
    head.className = "chain-group-head";
    // CA-parented groups carry a parentLabel (e.g. "$WIF CA") on their children —
    // the group reads as a "CA Chain of Investigation".
    const caLabel = entries.find(x => x.parentLabel)?.parentLabel || "";
    const pname = parentAddr
      ? (caLabel || walletNames[parentAddr] || (chain.find(x => x.address === parentAddr)?.name) || shortAddr(parentAddr))
      : "Unassigned";
    head.innerHTML = `<button class="chain-group-toggle" type="button"><span class="caret">▾</span> <span class="cg-name"></span>${caLabel ? ` <span class="cg-chip">CA</span>` : ""} <span class="cg-count"></span></button>`
      + (parentAddr ? `<button class="icon-btn small cg-open" title="${caLabel ? "Open the CA launch scan" : "Analyze parent wallet"}">↗</button>` : "");
    head.querySelector(".cg-name").textContent = pname;
    head.querySelector(".cg-count").textContent = `· ${entries.length} linked`;
    if (parentAddr) {
      const sub = document.createElement("span");
      sub.className = "cg-sub mono"; sub.textContent = shortAddr(parentAddr); sub.title = parentAddr;
      head.querySelector(".chain-group-toggle").after(sub);
      head.querySelector(".cg-open").addEventListener("click", (e) => {
        e.stopPropagation();
        if (caLabel) openCaScan(parentAddr); else openDetail(parentAddr);   // CA parents reopen the launch scan
      });
    }
    head.querySelector(".chain-group-toggle").addEventListener("click", () => {
      const open = head.querySelector(".caret").textContent === "▾";
      head.querySelector(".caret").textContent = open ? "▸" : "▾";
      ul.querySelectorAll(`li[data-cg="${gid}"]`).forEach(r => r.classList.toggle("hidden", open));
    });
    ul.appendChild(head);
    for (const c of entries) renderChainRow(c, d, ul, gid);
  }
}

function renderChainRow(c, d, ul, gid) {
  {
    // Condensed interaction detail from the current cached analysis, if present.
    let detail = c.note || "";
    const cache = d.cache || {};
    let seenCount = 0, inN = 0, outN = 0;
    for (const addr of Object.keys(cache)) {
      const cp = (cache[addr]?.data?.stats?.topCounterparties || []).find(x => x.addr === c.address);
      if (cp) { seenCount++; inN += cp.in || 0; outN += cp.out || 0; }
    }
    const seenTxt = seenCount ? `seen in ${seenCount} analysis${seenCount > 1 ? "es" : ""} · ${inN} in / ${outN} out` : "not yet seen in an analysis";
    const li = document.createElement("li");
    li.className = "chain-row";
    li.dataset.cg = gid;
    li.innerHTML = `<div class="row-main">
        <span class="row-title"></span>
        <span class="row-sub mono"></span>
        <span class="chain-detail"></span>
      </div>
      <div class="row-right">
        <button class="icon-btn small chain-open" title="Analyze this wallet">↗</button>
        <button class="icon-btn small chain-rename" title="Name / note">✎</button>
        <button class="remove-btn chain-remove" title="Remove from chain">✕</button>
      </div>`;
    li.querySelector(".row-title").textContent = c.name ? c.name : shortAddr(c.address);
    const sub = li.querySelector(".row-sub"); sub.textContent = shortAddr(c.address); sub.title = c.address;
    li.querySelector(".chain-detail").textContent = `${seenTxt}${c.note ? ` · “${c.note}”` : ""}`;
    li.querySelector(".chain-open").addEventListener("click", (e) => { e.stopPropagation(); openDetail(c.address); });
    li.querySelector(".chain-remove").addEventListener("click", async (e) => {
      e.stopPropagation();
      const dd = await store.get();
      dd.chain = (dd.chain || []).filter(x => x.address !== c.address);
      const stillSaved = (dd.wallets || []).some(w => w.address === c.address) || (dd.cas || []).some(x => x.address === c.address);
      if (!stillSaved) purgeCache(dd, c.address);     // orphan chain entry → drop its cache too
      await store.set({ chain: dd.chain, cache: dd.cache, caCache: dd.caCache, mapLayouts: dd.mapLayouts });
      if (lastSettings) { lastSettings.chain = dd.chain; lastSettings.cache = dd.cache; lastSettings.caCache = dd.caCache; lastSettings.mapLayouts = dd.mapLayouts; }
      renderChain();
    });
    li.querySelector(".chain-rename").addEventListener("click", (e) => {
      e.stopPropagation();
      if (li.querySelector(".chain-edit")) return;
      const box = document.createElement("div");
      box.className = "chain-edit";
      box.innerHTML = `<input class="chain-name-in" placeholder="Name" value="${escHtml(c.name || "")}">`
        + `<input class="chain-note-in" placeholder="Note (optional)" value="${escHtml(c.note || "")}">`
        + `<button class="ghost-btn small chain-save">Save</button>`;
      box.addEventListener("click", ev => ev.stopPropagation());
      li.querySelector(".row-main").appendChild(box);
      const save = async () => {
        const dd = await store.get();
        const t = (dd.chain || []).find(x => x.address === c.address);
        if (t) { t.name = box.querySelector(".chain-name-in").value.trim(); t.note = box.querySelector(".chain-note-in").value.trim(); await store.set({ chain: dd.chain }); if (lastSettings) lastSettings.chain = dd.chain; }
        renderChain();
      };
      box.querySelector(".chain-save").addEventListener("click", save);
      box.querySelector(".chain-name-in").focus();
    });
    ul.appendChild(li);
  }
}

// ---------- CURRENT STATE evaluation (v5.7.6) ----------
// "Is this coin bundled RIGHT NOW, or organically held?" — a snapshot-based
// evaluation, deliberately cheap on the API (no history replay):
//   1. current top holders (getTokenLargestAccounts + owner resolution),
//   2. holder classification (pools/exchanges split out from real wallets),
//   3. funding traces for the top wallet holders, organized through the SAME
//      funding-family rule as the launch scan (personal shared funder = one
//      linked family; connectors/labelled wallets never form families),
//   4. launch overlap from the CACHED launch scan (zero extra requests):
//      how much do the launch buyers — and the launch BUNDLES — still hold?
// Verdict bands are computed from named thresholds and always shipped with
// the numbers that produced them.
const CS_TRACE_HOLDERS = 15;       // funding traces per evaluation (~2 calls each)
const CS_THRESH = {
  linkedBundled: 0.15,             // coordinated holders ≥15% of supply now → BUNDLED NOW
  linkedCountBundled: 6,           // …or ≥6 coordinated wallets in the top holders → BUNDLED NOW
  launchBundleHold: 0.15,          // strict launch bundles (incl. relocated) still ≥15% → BUNDLED NOW
  insiderHold: 0.25,               // launch buyers still hold ≥25% → INSIDER-HEAVY (CABALLED)
  whaleSingle: 0.15,               // one wallet ≥15% → INSIDER-HEAVY (CABALLED)
  whaleTop10: 0.60,                // top-10 wallets ≥60% → INSIDER-HEAVY (CABALLED)
  bundleMateriality: 0.10,         // launch bundles ≥10% at launch = they were real…
  exitedResidual: 0.05,            // …and ≤5% now (incl. relocated) = sold off → context note
  organicTop10: 0.40,              // top-10 <40% …
  organicLinked: 0.10,             // … and coordinated <10% → ORGANIC
  lowCoverage: 0.25,               // analyzed holders cover <25% of supply → low-confidence note
};

// Pure verdict logic — unit-tested; m carries fractions (0..1) or null.
function csVerdict(m) {
  const pct = (x) => (x == null ? "?" : Math.round(x * 100) + "%");
  const ev = [];
  let band, cls, desc;
  const extHold = m.launch ? (m.launch.launchLinkedShare != null ? m.launch.launchLinkedShare : m.launch.bundleHoldShare) : null;
  if (m.linkedShare >= CS_THRESH.linkedBundled
      || (m.linkedCount != null && m.linkedCount >= CS_THRESH.linkedCountBundled)
      || (extHold != null && extHold >= CS_THRESH.launchBundleHold)) {
    band = "BUNDLED NOW"; cls = "cs-bundled";
    desc = "Coordinated wallets are acting as one position right now — same funders, gas-seeded by the same operation, or holding tokens passed between each other / from the launch bundles.";
    if (m.linkedShare >= CS_THRESH.linkedBundled || (m.linkedCount != null && m.linkedCount >= CS_THRESH.linkedCountBundled))
      ev.push(`${m.linkedCount ?? "several"} coordination-linked wallets control ${pct(m.linkedShare)} of supply (same funders, or seeded/token-fed by the operation or each other)`);
    if (extHold != null && extHold >= CS_THRESH.launchBundleHold)
      ev.push(`the launch bundles' position is still ${pct(extHold)} of supply — ${pct(m.launch.bundleHoldShare)} in the original wallets, ${pct(Math.max(0, extHold - m.launch.bundleHoldShare))} relocated into linked wallets`);
  } else if ((m.launch && m.launch.launchHoldShare >= CS_THRESH.insiderHold)
      || m.topHolderShare >= CS_THRESH.whaleSingle || m.top10Share >= CS_THRESH.whaleTop10) {
    band = "INSIDER-HEAVY (CABALLED)"; cls = "cs-insider";
    desc = "Supply is controlled by a small circle — launch-window insiders and/or a few dominant wallets. Not provably one coordinated position, but a handful of actors decide this chart.";
    if (m.launch && m.launch.launchHoldShare >= CS_THRESH.insiderHold)
      ev.push(`launch-window buyers still hold ${pct(m.launch.launchHoldShare)} of supply (${m.launch.buyersStillTop} of them in the top holders)`);
    if (m.topHolderShare >= CS_THRESH.whaleSingle) ev.push(`one wallet holds ${pct(m.topHolderShare)} of supply`);
    if (m.top10Share >= CS_THRESH.whaleTop10) ev.push(`top-10 wallets hold ${pct(m.top10Share)}`);
  } else if (m.top10Share < CS_THRESH.organicTop10 && m.linkedShare < CS_THRESH.organicLinked) {
    band = "ORGANIC"; cls = "cs-organic";
    desc = "Supply is spread across many unlinked wallets with no dominant coordinated position — consistent with organic distribution.";
    ev.push(`top-10 wallets ${pct(m.top10Share)}, coordination-linked ${pct(m.linkedShare)} — no dominant coordinated position`);
  } else {
    band = "MIXED"; cls = "cs-mixed";
    desc = "Some concentration or linkage, but below every coordinated-verdict threshold — read the numbers below before judging.";
    ev.push(`top-10 wallets ${pct(m.top10Share)}, coordination-linked ${pct(m.linkedShare)}${m.launch ? `, launch buyers still hold ${pct(m.launch.launchHoldShare)}` : ""}`);
  }
  // Launch-bundle history is CONTEXT, not a verdict — the verdict answers
  // "what is this coin NOW"; these lines answer "and how did it get here".
  if (m.launch && m.launch.hadBundles && m.launch.bundleLaunchShare != null) {
    if (m.launch.bundleLaunchShare >= CS_THRESH.bundleMateriality && extHold != null && extHold <= CS_THRESH.exitedResidual)
      ev.push(`history: the launch bundles took ${pct(m.launch.bundleLaunchShare)} of supply at launch and have SOLD OUT of it (${pct(extHold)} left incl. relocated wallets) — current holders are not the launch operation`);
    else if (m.launch.bundleLaunchShare < CS_THRESH.bundleMateriality)
      ev.push(`history: launch showed only minor strict bundling (${pct(m.launch.bundleLaunchShare)} of supply) — too small to define the coin`);
    else if (band !== "BUNDLED NOW")
      ev.push(`history: launch bundles took ${pct(m.launch.bundleLaunchShare)} at launch and still hold ${pct(extHold)} (incl. relocated)`);
  }
  if (m.freshShare != null && m.freshShare >= 0.10) ev.push(`fresh wallets (≤7d old) hold ${pct(m.freshShare)} of supply — recently created holders`);
  if (m.infraShare != null && m.infraShare > 0) ev.push(`pools / programs / exchanges hold ${pct(m.infraShare)} — normally the trading pool / bonding curve holding LIQUIDITY, not a person's position (expected and healthy; excluded from every wallet metric — breakdown below)`);
  if (!m.launch) ev.push("no launch scan cached — run a launch scan first to add launch-bundle retention to this verdict");
  if (m.coverageShare != null && m.coverageShare < CS_THRESH.lowCoverage) ev.push(`LOW COVERAGE — the analyzed holders account for only ${pct(m.coverageShare)} of supply; treat this verdict with caution`);
  return { band, cls, desc, evidence: ev };
}

async function evaluateCurrentState(mint, d, progress) {
  const key = d.apiKey;
  const rpc = async (method, params, id) => {
    const res = await fetch(`https://mainnet.helius-rpc.com/?api-key=${key}`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: id || "wt-cs", method, params }),
    });
    if (!res.ok) throw new Error(res.status === 429
      ? "Current-state check rate-limited (HTTP 429) — wait a minute and retry."
      : `Current-state request failed (HTTP ${res.status}). Check your API key.`);
    const json = await res.json();
    if (json.error) throw new Error(json.error.message || "RPC error");
    return json.result;
  };

  progress("Reading supply…");
  const sup = (await fetchTokenSupplies([mint], key))[mint];
  const supplyUi = sup?.supplyUi || (caState && caState.mint === mint ? caState.supplyUi : null) || null;

  // v5.7.6.d: the distribution comes from a FULL DAS token-accounts page
  // (up to 1000 accounts) instead of the top-20 largest accounts — a bundle
  // spread across 30 mid-size wallets is invisible to a top-20 view, and that
  // blindness was misreading bundled coins as exited/organic. One call gives
  // owner+amount for every account (plus the holder count for free); the
  // top-20 RPC remains only as a fallback when DAS is unavailable.
  progress("Reading holder distribution…");
  const decimals = sup?.decimals ?? null;
  let byOwner = new Map();
  let holderCount = null, holderCountExact = false, dasUsed = false;
  try {
    const ta = await rpc("getTokenAccounts", { mint, limit: 1000, page: 1 }, "wt-cs-dist");
    const accs = ta?.token_accounts || [];
    if (accs.length) {
      dasUsed = true;
      holderCount = accs.length; holderCountExact = accs.length < 1000;
      for (const a of accs) {
        const raw = Number(a.amount || 0);
        if (!(raw > 0) || !a.owner) continue;
        const ui = decimals != null ? raw / Math.pow(10, decimals) : raw;
        const h = byOwner.get(a.owner) || { addr: a.owner, ui: 0 };
        h.ui += ui;
        byOwner.set(a.owner, h);
      }
    }
  } catch { /* fall back to top-20 below */ }
  if (!dasUsed) {
    progress("Reading current top holders…");
    const largest = await rpc("getTokenLargestAccounts", [mint], "wt-cs-large");
    const tokAccts = (largest?.value || []).filter(v => Number(v.uiAmount) > 0);
    const ownersRes = tokAccts.length
      ? await rpc("getMultipleAccounts", [tokAccts.map(v => v.address), { encoding: "jsonParsed" }], "wt-cs-own")
      : { value: [] };
    (ownersRes?.value || []).forEach((acct, i) => {
      const owner = acct?.data?.parsed?.info?.owner;
      if (!owner) return;
      const h = byOwner.get(owner) || { addr: owner, ui: 0 };
      h.ui += Number(tokAccts[i].uiAmount || 0);
      byOwner.set(owner, h);
    });
  }
  const holders = [...byOwner.values()].sort((a, b) => b.ui - a.ui);
  for (const h of holders) h.share = supplyUi ? h.ui / supplyUi : null;
  const coverageShare = holders.reduce((a, h) => a + (h.share || 0), 0);

  progress("Classifying holders…");
  // one getMultipleAccounts batch covers up to 100 — classify the top slice
  const cls = await classifyCounterparties(holders.slice(0, 60).map(h => h.addr), key);
  for (const h of holders) {
    h.cls = cls[h.addr] || null;
    h.isWallet = !h.cls || h.cls.kind === "wallet" || h.cls.kind === "unknown";
  }
  const infraShare = holders.filter(h => !h.isWallet).reduce((a, h) => a + (h.share || 0), 0);
  const walletHolders = holders.filter(h => h.isWallet);

  // funding traces — same pattern and pacing as the launch scan's funding pass
  const traced = walletHolders.slice(0, CS_TRACE_HOLDERS);
  const nowSec = Math.floor(Date.now() / 1000);
  let n = 0;
  for (const h of traced) {
    n++;
    progress(`Tracing holder funding… ${n}/${traced.length}`);
    try {
      const r = await fetch(`https://api.helius.xyz/v0/addresses/${h.addr}/transactions?api-key=${key}&limit=10&sort-order=asc`);
      const first = r.ok ? await r.json() : [];
      if (Array.isArray(first) && first[0]?.timestamp) {
        h.walletFirstTs = first[0].timestamp;
        h.ageDays = (nowSec - first[0].timestamp) / 86400;
        outer:
        for (const tx of first) {
          for (const nt of tx.nativeTransfers || []) {
            const amt = Number(nt.amount || 0) / LAMPORTS;
            if (nt.toUserAccount === h.addr && nt.fromUserAccount && nt.fromUserAccount !== h.addr && amt > 0) {
              h.funder = nt.fromUserAccount; break outer;
            }
          }
        }
        // Token PROVENANCE (v5.7.6.d): if this mint arrived in the wallet's
        // early history via a plain transfer, record who sent it. Bundlers
        // relocate positions one hop into fresh wallets — the receiving
        // wallet is young, so the arrival sits inside these first pages and
        // links the "new" holder straight back to the operation.
        for (const tx of first) {
          for (const tt of tx.tokenTransfers || []) {
            if (tt.mint === mint && tt.toUserAccount === h.addr && tt.fromUserAccount && tt.fromUserAccount !== h.addr) {
              h.tokenSource = tt.fromUserAccount;
              break;
            }
          }
          if (h.tokenSource) break;
        }
      }
    } catch { /* additive */ }
    await new Promise(rs => setTimeout(rs, 130));
  }

  // ---- linkage (v5.7.6.d) — three independent ways a current holder ties
  // back to a coordinated operation, all from data already fetched:
  //   1. same personal funder as another top holder (funding family, as before)
  //   2. seeded or token-fed BY a launch buyer / launch funding family — the
  //      one-hop RELOCATION pattern (launch wallets pass the position to
  //      fresh wallets; the old address book empties but nothing dispersed)
  //   3. token-fed by another current top holder (internal shuffle)
  const scan = (caState && caState.mint === mint) ? caState : (d.caCache?.[mint]?.data || null);
  const lFam = scan?.buyers?.length ? caFundingFamilies(scan.buyers, d.connectors, caBundleEligible(scan.buyers)) : null;
  const launchMap = scan?.buyers?.length ? new Map(scan.buyers.map(b => [b.addr, b])) : new Map();
  // STRICT launch-bundle membership (same-tx + funding families; never
  // timing-only) drives every supply aggregate — organic same-second snipers
  // stay out of "the bundles" numbers.
  const strictSet = scan?.buyers?.length ? caStrictBundleMembers(scan.buyers, d.connectors) : new Set();
  // "the launch operation" = funders of STRICT members only — an organic
  // buyer's personal funder is not the operation.
  const launchFunders = new Set();
  if (lFam) for (const b of scan.buyers) {
    if (!strictSet.has(b.addr)) continue;
    const f = lFam(b); if (f) launchFunders.add(f);
    if (b.funder) launchFunders.add(b.funder);
  }
  const holderSet = new Set(holders.map(h => h.addr));

  const famKey = caFundingFamilies(traced, d.connectors);
  for (const h of traced) {
    h.linkWhy = [];
    const f = famKey(h);
    if (f) { h.family = f; }
    if (launchMap.has(h.addr)) { h.fromLaunch = true; }
    if (h.funder && (strictSet.has(h.funder) || launchFunders.has(h.funder)) && !h.fromLaunch)
      h.linkWhy.push(`gas-seeded by the launch operation (${shortAddr(h.funder)})`);
    if (h.tokenSource && (strictSet.has(h.tokenSource) || launchFunders.has(h.tokenSource)))
      h.linkWhy.push(`received its position from launch-bundle wallet ${shortAddr(h.tokenSource)} — relocated, not sold`);
    else if (h.tokenSource && holderSet.has(h.tokenSource) && h.tokenSource !== h.addr)
      h.linkWhy.push(`received its position from another top holder (${shortAddr(h.tokenSource)})`);
    h.coordinated = strictSet.has(h.addr) || h.linkWhy.length > 0;
  }
  const famMembers = {};
  for (const h of traced) if (h.family) (famMembers[h.family] = famMembers[h.family] || []).push(h.addr);
  const realFams = Object.entries(famMembers).filter(([, m]) => m.length >= 2);
  // ONE coordination bucket (v5.7.6.e): a holder is coordinated if it is a
  // strict launch-bundle member, is linked by funder/provenance to the
  // operation or to other holders, or shares a personal funder with another
  // holder. Count and share both matter — 12 linked wallets at 1.5% each is
  // as coordinated as 3 at 8%.
  for (const h of traced) if (h.family && famMembers[h.family].length >= 2) h.coordinated = true;
  const coord = traced.filter(h => h.coordinated);
  const linkedShare = coord.reduce((a, h) => a + (h.share || 0), 0);
  const linkedCount = coord.length;
  const freshShare = traced.filter(h => h.ageDays != null && h.ageDays <= 7).reduce((a, h) => a + (h.share || 0), 0);

  // launch overlap — cached scan only, zero extra requests
  let launch = null;
  if (scan?.buyers?.length) {
    const stillTop = holders.filter(h => launchMap.has(h.addr));
    for (const h of stillTop) h.fromLaunch = true;
    const directBundleHold = holders.filter(h => strictSet.has(h.addr)).reduce((a, h) => a + (h.share || 0), 0);
    // extended retention: strict launch-bundle wallets still holding PLUS
    // relocated positions (holders whose gas or tokens came from the
    // operation) — one bucket, no double counting (strict members with
    // linkWhy count once via the Set union below)
    const extAddrs = new Set([
      ...holders.filter(h => strictSet.has(h.addr)).map(h => h.addr),
      ...traced.filter(h => h.linkWhy.length > 0).map(h => h.addr),
    ]);
    const holderByAddr = new Map(holders.map(h => [h.addr, h]));
    const launchLinkedShare = [...extAddrs].reduce((a, addr) => a + (holderByAddr.get(addr)?.share || 0), 0);
    launch = {
      buyersStillTop: stillTop.length,
      launchHoldShare: stillTop.reduce((a, h) => a + (h.share || 0), 0),
      bundleHoldShare: directBundleHold,
      launchLinkedShare,
      // materiality: supply the STRICT launch bundles took AT LAUNCH —
      // same-second-only snipers are organic noise and stay out of this
      bundleLaunchShare: scan.buyers.filter(b => strictSet.has(b.addr)).reduce((a, b) => a + (b.share || 0), 0),
      hadBundles: strictSet.size > 0,
      deployerShare: holders.find(h => h.addr === scan.deployer)?.share || 0,
    };
  }

  const metrics = {
    supplyUi, holderCount, holderCountExact, infraShare, coverageShare, dasUsed,
    top10Share: walletHolders.slice(0, 10).reduce((a, h) => a + (h.share || 0), 0),
    topHolderShare: walletHolders[0]?.share || 0,
    linkedShare, linkedCount, freshShare, launch,
    families: realFams.map(([funder, members]) => ({
      funder, members,
      share: traced.filter(h => members.includes(h.addr)).reduce((a, h) => a + (h.share || 0), 0),
    })).sort((a, b) => b.share - a.share),
    launchLinks: traced.filter(h => h.linkWhy.length > 0)
      .map(h => ({ addr: h.addr, share: h.share, why: h.linkWhy }))
      .sort((a, b) => (b.share || 0) - (a.share || 0)),
    holders: holders.slice(0, 20).map(h => ({
      addr: h.addr, share: h.share, isWallet: h.isWallet, clsLabel: h.cls?.label || "",
      family: h.family || null, fromLaunch: !!h.fromLaunch, ageDays: h.ageDays ?? null,
    })),
    tracedCount: traced.length,
  };
  return { fetchedAt: Date.now(), metrics, verdict: csVerdict(metrics) };
}

// ---------- CA launch scan UI ----------
let caState = null;             // last scan result shown in the CA panel
let caGroupMode = "bands";      // CA result grouping: "bands" (confidence) | "cohorts" (shared signal)
let csRunning = false;          // single-flight guard for the current-state check

// Render a saved/just-computed current-state evaluation into the CA panel.
function renderCaCurrent(cur) {
  const wrap = $("caCurrentWrap");
  if (!wrap) return;
  const chip = $("caCurVerdict"), when = $("caCurWhen"), body = $("caCurBody");
  // No evaluation yet → the card stays hidden; the "Run current evaluation of
  // holders" button lives in the actions row next to Launch Constellation.
  if (!cur) { wrap.classList.add("hidden"); chip.classList.add("hidden"); when.textContent = ""; body.innerHTML = ""; return; }
  wrap.classList.remove("hidden");
  const m = cur.metrics, v = cur.verdict;
  const pctS = (x) => (x == null ? "—" : (x * 100).toFixed(x * 100 >= 10 ? 0 : 1) + "%");
  chip.textContent = v.band;
  chip.className = `ca-cur-verdict ${v.cls}`;
  chip.classList.remove("hidden");
  when.textContent = `checked ${new Date(cur.fetchedAt).toLocaleString()}`;
  // Plain-language explanation of what the verdict MEANS, before the numbers.
  let html = v.desc ? `<div class="ca-cur-desc">${escHtml(v.desc)}</div>` : "";
  html += `<div class="ca-cur-grid">`
    + `<div class="ca-sum-row"><span>Top-10 wallets hold</span><b class="${m.top10Share >= 0.4 ? "warn-b" : ""}">${pctS(m.top10Share)}</b></div>`
    + `<div class="ca-sum-row"><span>Funding-linked families</span><b class="${m.linkedShare >= 0.1 ? "warn-b" : ""}">${pctS(m.linkedShare)}${m.families.length ? ` · ${m.families.length} group${m.families.length > 1 ? "s" : ""}` : ""}</b></div>`
    + (m.launch ? `<div class="ca-sum-row"><span>Launch buyers still hold</span><b class="${m.launch.launchHoldShare >= 0.2 ? "warn-b" : ""}">${pctS(m.launch.launchHoldShare)}</b></div>`
      + `<div class="ca-sum-row"><span>Launch bundles: at launch → now</span><b class="${(m.launch.launchLinkedShare ?? m.launch.bundleHoldShare) >= 0.1 ? "warn-b" : ""}">${pctS(m.launch.bundleLaunchShare)} → ${pctS(m.launch.launchLinkedShare ?? m.launch.bundleHoldShare)}</b></div>` : "")
    + `<div class="ca-sum-row"><span>Fresh wallets (≤7d) hold</span><b class="${m.freshShare >= 0.1 ? "warn-b" : ""}">${pctS(m.freshShare)}</b></div>`
    + `<div class="ca-sum-row"><span>Pools / CEX / programs</span><b>${pctS(m.infraShare)}</b></div>`
    + `<div class="ca-sum-row"><span>Holders</span><b>${m.holderCount == null ? "—" : m.holderCountExact ? m.holderCount : m.holderCount + "+"}</b></div>`
    + `<div class="ca-sum-row"><span>Largest single wallet</span><b class="${m.topHolderShare >= 0.15 ? "warn-b" : ""}">${pctS(m.topHolderShare)}</b></div>`
    + `</div>`;
  html += `<ul class="ca-cur-ev">${v.evidence.map(e => `<li>${escHtml(e)}</li>`).join("")}</ul>`;
  if (m.launchLinks && m.launchLinks.length) {
    html += m.launchLinks.map(l =>
      `<div class="ca-cur-fam">↳ <b>${pctS(l.share)}</b> <span class="mono" title="${escHtml(l.addr)}">${shortAddr(l.addr)}</span> — ${l.why.map(w => escHtml(w)).join("; ")}</div>`).join("");
  }
  if (m.families.length) {
    html += m.families.map(f =>
      `<div class="ca-cur-fam">⛓ <b>${pctS(f.share)}</b> held by ${f.members.length} wallets seeded by <span class="mono" title="${escHtml(f.funder)}">${shortAddr(f.funder)}</span> — <span class="mono">${f.members.map(a => shortAddr(a)).join(" · ")}</span></div>`).join("");
  }
  // Reassuring breakdown of the non-wallet holders: what each program/pool/
  // exchange account actually is and how much it holds — so "programs hold
  // 40%" reads as the liquidity pool it usually is, not as a red flag.
  const infra = m.holders.filter(h => !h.isWallet && (h.share || 0) > 0.0005);
  if (infra.length) {
    html += `<div class="ca-cur-fam">◇ Pool / program / exchange holdings (liquidity &amp; custody — not counted as holders): `
      + infra.map(h => `<b>${pctS(h.share)}</b> ${escHtml(h.clsLabel || "program-owned account")} <span class="mono" title="${escHtml(h.addr)}">${shortAddr(h.addr)}</span>`).join(" · ")
      + `</div>`;
  }
  html += `<div class="ca-cur-fam" style="opacity:.75">Distribution from ${m.dasUsed ? "a full holder-accounts page (up to 1000 accounts)" : "the top-20 largest accounts (DAS unavailable — reduced visibility)"}; analyzed holders cover ${pctS(m.coverageShare)} of supply; funding + token provenance traced for the top ${m.tracedCount} wallets; shares are of total supply.</div>`;
  body.innerHTML = html;
}

async function runCurrentState() {
  if (!caState || csRunning) return;
  const mint = caState.mint;
  const status = $("caCurStatus");
  const d = await store.get();
  if (!d.apiKey) { status.textContent = "Set your Helius API key in Settings first."; status.classList.remove("hidden"); return; }
  csRunning = true;
  $("caCurBtn").disabled = true;
  $("caCurrentWrap").classList.remove("hidden");   // show the card while it runs
  status.classList.remove("hidden");
  try {
    const cur = await evaluateCurrentState(mint, d, (msg) => { status.textContent = msg; });
    const cc = d.caCurrent || {};
    cc[mint] = cur;
    const keys = Object.keys(cc).sort((a, b) => cc[b].fetchedAt - cc[a].fetchedAt);
    for (const k of keys.slice(8)) delete cc[k];        // keep the store small, like caCache
    await store.set({ caCurrent: cc });
    if (lastSettings) lastSettings.caCurrent = cc;
    status.classList.add("hidden");
    renderCaCurrent(cur);
  } catch (e) {
    status.textContent = "Current-state check failed: " + (e && e.message ? e.message : String(e));
  } finally {
    csRunning = false;
    $("caCurBtn").disabled = false;
  }
}

// BUNDLE ELIGIBILITY (v5.7.6.c) — a buy far below expectancy can never be
// bundle material, REGARDLESS of any user-configured threshold. Real bundle
// allocations run ~0.5–2% of supply per wallet; a launch buy under 0.1% of
// supply (e.g. 530K tokens of a 1B-supply coin = 0.05%) is dust/noise — an
// airdrop leg, a tip, a stray sniper — and treating it as a bundle member
// both inflates bundle counts and drags real buyers into fake bundles.
// The gate is intrinsic: supply share when supply is known; otherwise ≥1% of
// the largest launch buy. Dust buyers can neither FORM, JOIN, nor COUNT
// TOWARD a bundle (timing or funding kind) — but a funder who seeded ≥2
// eligible buyers still heads its family even if its own buy was small
// (orchestrators often barely buy).
const CA_BUNDLE_MIN_SHARE = 0.001;   // 0.1% of supply
function caBundleEligible(buyers) {
  const maxTok = Math.max(...buyers.map(x => x.tok || 0), 1);
  return (b) => (b.share != null ? b.share >= CA_BUNDLE_MIN_SHARE : (b.tok || 0) >= 0.01 * maxTok);
}

// STRICT bundle membership (v5.7.6.e) — used by supply AGGREGATES (how much
// did "the bundles" take/hold). Same-SECOND timing alone is a coincidence on
// busy launches and was dragging organic snipers into the bundle totals, so
// aggregate membership requires hard evidence: token delivered to several
// wallets in ONE transaction, or a personal funding family. Recomputed from
// persisted buyer data so cached scans are covered.
function caStrictBundleMembers(buyers, connectors) {
  const eligible = caBundleEligible(buyers);
  const fam = caFundingFamilies(buyers, connectors, eligible);
  const byTx = {};
  for (const b of buyers) if (eligible(b)) for (const sig of (b.txSigs || [])) (byTx[sig] = byTx[sig] || []).push(b.addr);
  const strict = new Set();
  for (const [, mem] of Object.entries(byTx)) if (mem.length >= 2) mem.forEach(a => strict.add(a));
  for (const b of buyers) if (fam(b)) strict.add(b.addr);
  return strict;
}

// FUNDING FAMILIES — the primary bundle organizer (v5.7.5.c rule change).
// Buyers are organized by SHARED FUNDING SOURCE first, timing second: every
// early buyer seeded by the same PERSONAL funder (a funder of ≥2 early buyers
// that is not a connector relayer and not a labelled exchange/known wallet —
// those fund everyone, so they'd create fake bundles) belongs to one funding
// family, and a buyer that itself funded ≥2 other early buyers heads its own
// family. Returns famKey(buyer) → family id (the funder address) or null.
// Works on both fresh scans and CACHED scans (recomputed from persisted
// buyer.funder fields rather than relying on any new stored flag).
function caFundingFamilies(buyers, connectors, eligible = null) {
  const ok = eligible || (() => true);
  const connSet = new Set(connectors || []);
  const byFunder = {};
  for (const b of buyers) if (b.funder && ok(b)) (byFunder[b.funder] = byFunder[b.funder] || []).push(b.addr);
  const personal = new Set(Object.entries(byFunder)
    .filter(([f, kids]) => kids.length >= 2 && !connSet.has(f) && !labelFor(f))
    .map(([f]) => f));
  // kids must be bundle-eligible; the family HEAD (a buyer that funded ≥2
  // eligible buyers) is exempt — orchestrators often barely buy themselves.
  return (b) => (ok(b) && personal.has(b.funder)) ? b.funder : (personal.has(b.addr) ? b.addr : null);
}

// Build COHORTS from a launch scan: wallets that share a coordination signal are
// grouped as one suspect cohort — organized by FUNDING SOURCE first (personal
// shared funders claim their members before anything else), then same-tx/second
// bundles, then gas config and identical size. Each wallet is placed in exactly
// ONE cohort (its strongest organizer), so the groups form a clean partition;
// the rest are "solo".
function buildCaCohorts(s, settings, labels) {
  const byAddr = new Map(s.buyers.map(b => [b.addr, b]));
  const assigned = new Set();
  const cohorts = [];
  const push = (kind, kindLabel, label, cls, memberAddrs) => {
    const members = [...new Set(memberAddrs)].map(a => byAddr.get(a)).filter(Boolean).filter(b => !assigned.has(b.addr));
    if (members.length < 2) return;
    members.forEach(b => assigned.add(b.addr));
    cohorts.push({ kind, kindLabel, label, cls, members });
  };
  const cg = s.commonGround || {};
  // FUNDING FIRST (v5.7.5.c): personal shared funders are the primary bundle
  // organizer and claim their members before time-bundles; connector/labelled
  // funders follow, and only then do same-tx/second bundles pick up the rest.
  const connSet = new Set(settings?.connectors || []);
  const famKey = caFundingFamilies(s.buyers, settings?.connectors, caBundleEligible(s.buyers));
  const byAddr2 = new Map(s.buyers.map(b => [b.addr, b]));
  const fundGroups = (cg.funding || []).slice().sort((A, B) => {
    const pa = (!connSet.has(A.funder) && !labelFor(A.funder)) ? 0 : 1;
    const pb = (!connSet.has(B.funder) && !labelFor(B.funder)) ? 0 : 1;
    return pa - pb || B.members.length - A.members.length;
  });
  for (const g of fundGroups) {
    const personal = !connSet.has(g.funder) && !labelFor(g.funder);
    // A buyer that FUNDED other buyers belongs in its own funding family too.
    // Personal bundles only carry members that pass the size gate (famKey).
    const mem = personal
      ? [...g.members.filter(a => { const b = byAddr2.get(a); return b && famKey(b) === g.funder; }),
         ...(s.buyers.some(b => b.addr === g.funder) ? [g.funder] : [])]
      : g.members;
    push("funding", personal ? "Funding bundle" : "Funding cohort",
      `Shared funder — ${fundingSourceName(g.funder, settings)}${personal ? ` — ${mem.length} wallets, one source` : ""}`, "cg-fund", mem);
  }
  const bByT = {};
  for (const b of s.buyers) if (b.bundleMates) (bByT[b.firstT] = bByT[b.firstT] || []).push(b.addr);
  for (const [, mem] of Object.entries(bByT)) push("bundle", "Bundle cohort", `Bundle — ${mem.length} wallets served in one tx/second`, "cg-bundle", mem);
  for (const g of (cg.gas || [])) push("gas", "Gas cohort", `Same gas config — ${(g.fee / 1e9).toFixed(6)} SOL priority fee`, "cg-gas", g.members);
  for (const g of (cg.sizes || [])) push("size", "Size cohort", `Identical buy size — ~${fmtNum(g.tok)} each`, "cg-size", g.members);
  const solo = s.buyers.filter(b => !assigned.has(b.addr));
  return { cohorts, solo };
}

// Every scanned CA is SAVED — it shows up on the main page under "CA launch
// scans" exactly like analyzed wallets do, with an optional label. Returns the
// (possibly updated) cas list.
async function registerCa(mint, name, symbol) {
  const d = await store.get();
  d.cas = d.cas || [];
  const existing = d.cas.find(c => c.address === mint);
  if (existing) {
    let dirty = false;
    if (name && !existing.name) { existing.name = name; dirty = true; }
    if (symbol && existing.symbol !== symbol) { existing.symbol = symbol; dirty = true; }
    if (dirty) await store.set({ cas: d.cas });
  } else {
    d.cas.push({ address: mint, name: name || "", symbol: symbol || "", added: Date.now() });
    await store.set({ cas: d.cas });
  }
  if (lastSettings) lastSettings.cas = d.cas;
  renderCaSaved();
  return d.cas;
}

async function openCaScan(mint, force = false, label = "") {
  await registerCa(mint, label);   // scanning a CA always saves it to the main page
  const d = await store.get();
  caState = null;
  show("ca");
  $("caTitle").textContent = "Token launch scan";
  $("caSub").textContent = shortAddr(mint); $("caSub").title = mint;
  $("caSummary").classList.add("hidden");
  $("caCurrentWrap").classList.add("hidden");
  $("caCurStatus").classList.add("hidden");
  $("caActions").classList.add("hidden");
  $("caList").innerHTML = "";
  const status = $("caStatus");
  status.classList.remove("hidden");
  const cached = (d.caCache || {})[mint];
  if (!force && cached && cached.v === 1 && Date.now() - cached.ts < CACHE_TTL_MS * 3) {
    caState = cached.data;
    status.classList.add("hidden");
    if (caState.symbol) registerCa(mint, "", caState.symbol);   // backfill $SYM on the saved row
    renderCaResults(d);
    return;
  }
  if (!d.apiKey) { status.textContent = "Set your Helius API key in Settings first."; return; }
  try {
    status.textContent = "Scanning launch…";
    caState = await analyzeLaunch(mint, d, (m) => { status.textContent = m; });
    const cc = d.caCache || {};
    cc[mint] = { ts: Date.now(), v: 1, data: caState };
    // keep the CA cache small — drop the oldest beyond 8 entries
    const keys = Object.keys(cc).sort((a, b) => cc[b].ts - cc[a].ts);
    for (const k of keys.slice(8)) delete cc[k];
    await store.set({ caCache: cc });
    status.classList.add("hidden");
    if (caState.symbol) registerCa(mint, "", caState.symbol);   // backfill $SYM on the saved row
    renderCaResults(d);
  } catch (e) {
    status.textContent = "Launch scan failed: " + (e && e.message ? e.message : String(e));
  }
}

// The "CA launch scans" section on the MAIN page — saved CAs listed like
// wallets, separate section, click to reopen the scan.
async function renderCaSaved() {
  const d = await store.get();
  const cas = d.cas || [];
  const sec = $("caSection");
  if (!sec) return;
  sec.classList.toggle("hidden", cas.length === 0);
  const ul = $("caSavedList");
  ul.innerHTML = "";
  for (const c of cas) {
    const li = document.createElement("li");
    const left = document.createElement("div");
    left.className = "wallet-left";
    const sym = c.symbol || (d.caCache?.[c.address]?.data?.symbol) || "";
    left.innerHTML = (c.name ? `<div class="wallet-name"></div>` : "")
      + `<div class="wallet-addr wallet-sub-line"><span class="ca-mini-chip">CA</span> <span class="ca-addr-txt"></span>${sym ? ` <span class="ca-sym"></span>` : ""}</div>`
      + `<div class="wallet-sub added"></div>`;
    if (c.name) left.querySelector(".wallet-name").textContent = c.name;
    left.querySelector(".ca-addr-txt").textContent = shortAddr(c.address);
    left.querySelector(".ca-addr-txt").title = c.address;
    if (sym) left.querySelector(".ca-sym").textContent = "$" + sym;
    left.querySelector(".added").textContent = "scanned " + new Date(c.added).toLocaleDateString();
    li.appendChild(left);

    const right = document.createElement("div");
    right.className = "row-right";
    const cp = document.createElement("button");
    cp.className = "icon-btn small"; cp.textContent = "⧉"; cp.title = "Copy CA";
    cp.addEventListener("click", (e) => {
      e.stopPropagation();
      navigator.clipboard.writeText(c.address);
      $("statusLine").textContent = "CA copied.";
      setTimeout(() => ($("statusLine").textContent = ""), 1500);
    });
    const rn = document.createElement("button");
    rn.className = "icon-btn small"; rn.textContent = "✎"; rn.title = "Label this CA";
    rn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (li.querySelector(".rename-input")) return;
      const input = document.createElement("input");
      input.className = "rename-input";
      input.value = c.name || "";
      input.placeholder = "CA label";
      left.prepend(input);
      input.focus();
      const save = async () => {
        const dd = await store.get();
        const t = (dd.cas || []).find(x => x.address === c.address);
        if (t) { t.name = input.value.trim(); await store.set({ cas: dd.cas }); if (lastSettings) lastSettings.cas = dd.cas; }
        renderCaSaved();
      };
      input.addEventListener("keydown", (ev) => { if (ev.key === "Enter") save(); if (ev.key === "Escape") renderCaSaved(); });
      input.addEventListener("blur", save);
      input.addEventListener("click", (ev) => ev.stopPropagation());
    });
    const rm = document.createElement("button");
    rm.className = "remove-btn"; rm.textContent = "✕"; rm.title = "Remove this CA from the list";
    rm.addEventListener("click", async (e) => {
      e.stopPropagation();
      const dd = await store.get();
      dd.cas = (dd.cas || []).filter(x => x.address !== c.address);
      purgeCache(dd, c.address);                      // drop cached launch scan + saved layout
      await store.set({ cas: dd.cas, cache: dd.cache, caCache: dd.caCache, mapLayouts: dd.mapLayouts });
      if (lastSettings) { lastSettings.cas = dd.cas; lastSettings.caCache = dd.caCache; lastSettings.mapLayouts = dd.mapLayouts; }
      renderCaSaved();
      renderWalletList();
    });
    right.append(cp, rn, rm);
    li.appendChild(right);
    li.addEventListener("click", () => openCaScan(c.address));
    ul.appendChild(li);
  }
}

function renderCaResults(settings = {}) {
  if (!caState) return;
  const s = caState;
  const labels = Object.fromEntries((settings.wallets || []).filter(w => w.name).map(w => [w.address, w.name]));
  $("caTitle").textContent = `${s.symbol ? "$" + s.symbol + " — " : ""}Token launch scan`;
  const flagged = s.buyers.filter(b => b.qualifies);
  const bundleGroups = new Set(s.buyers.filter(b => b.bundleMates).map(b => b.firstT)).size;
  const sharedFunders = Object.values(s.funderGroups || {}).filter(k => k.length >= 2).length;
  $("caSummary").innerHTML =
    `<div class="ca-sum-row"><span>Launched</span><b>${new Date(s.launchTs * 1000).toLocaleString()}</b></div>`
    + `<div class="ca-sum-row"><span>Scanned</span><b>first ${s.txScanned} txs${s.scanTruncated ? " (token history exceeds scan depth)" : ""} · ${s.windowSec >= 3600 ? (s.windowSec / 3600).toFixed(s.windowSec % 3600 ? 1 : 0) + " hr" : Math.round(s.windowSec / 60) + " min"} window</b></div>`
    + `<div class="ca-sum-row"><span>Early buyers</span><b>${s.buyers.length}</b></div>`
    + `<div class="ca-sum-row"><span>Flagged</span><b class="${flagged.length ? "warn-b" : ""}">${flagged.length}</b></div>`
    + `<div class="ca-sum-row"><span>Bundle groups</span><b class="${bundleGroups ? "warn-b" : ""}">${bundleGroups}</b></div>`
    + `<div class="ca-sum-row"><span>Shared funding sources</span><b class="${sharedFunders ? "warn-b" : ""}">${sharedFunders}</b></div>`
    + (s.deployer ? `<div class="ca-sum-row"><span>Deployer</span><b class="mono" title="${escHtml(s.deployer)}">${shortAddr(s.deployer)} <button id="caDeployerCopy" class="copy-mini" title="Copy the deployer address">⧉</button></b></div>` : "");
  $("caSummary").classList.remove("hidden");
  $("caDeployerCopy")?.addEventListener("click", () => {
    navigator.clipboard.writeText(s.deployer);
    $("statusLine").textContent = "Deployer address copied.";
    setTimeout(() => ($("statusLine").textContent = ""), 1500);
  });
  $("caActions").classList.remove("hidden");
  // Current-state block: always visible with results; shows the saved
  // evaluation for this mint if one exists, otherwise just the Check button.
  renderCaCurrent((settings.caCurrent || {})[s.mint] || null);

  // ---- COMMON GROUND panel: the visual guide to what the early buyers share —
  // same gas fee, same funding source, same-second bundles, identical sizes.
  const cg = s.commonGround;
  const cgEl = $("caCommon");
  if (cgEl) {
    if (cg && (cg.gas?.length || cg.funding?.length || cg.bundles?.length || cg.sizes?.length)) {
      const nmOf = (a) => { const nm = labels[a]; return nm ? `[${nm}]` : shortAddr(a); };
      const memberBits = (members) => members.slice(0, 6).map(a => `<span class="mono cg-mem" title="${escHtml(a)}">${nmOf(a)}</span>`).join(" ") + (members.length > 6 ? ` <span class="cg-more">+${members.length - 6} more</span>` : "");
      let rows = "";
      for (const g of (cg.gas || [])) rows += `<div class="cg-row"><span class="cg-kind cg-gas">GAS #${g.id}</span> identical fee ${(g.fee / 1e9).toFixed(6)} SOL × ${g.members.length} wallets — ${memberBits(g.members)}</div>`;
      for (const g of (cg.funding || [])) rows += `<div class="cg-row"><span class="cg-kind cg-fund">FUNDING</span> ${escHtml(fundingSourceName(g.funder, settings))} funded ${g.members.length} — ${memberBits(g.members)}</div>`;
      for (const g of (cg.bundles || [])) rows += `<div class="cg-row"><span class="cg-kind cg-bundle">BUNDLE</span> same-second buys × ${g.members.length} — ${memberBits(g.members)}</div>`;
      for (const g of (cg.sizes || [])) rows += `<div class="cg-row"><span class="cg-kind cg-size">SIZE</span> ~${fmtNum(g.tok)} each × ${g.members.length} — ${memberBits(g.members)}</div>`;
      cgEl.innerHTML = `<div class="cg-title">Common ground between early buyers</div>${rows}`;
      cgEl.classList.remove("hidden");
    } else {
      cgEl.classList.add("hidden");
      cgEl.innerHTML = "";
    }
  }

  const ul = $("caList");
  ul.innerHTML = "";
  const chainSet = new Set((settings.chain || []).map(c => c.address));
  // A generic collapsible group header, shared by BOTH the confidence-band view
  // and the cohort view. Rows carry data-band="<gid>" so the header hides them.
  let bi = 0;
  const addGroupHead = (title, countN, cls, sub) => {
    const gi = "grp" + (bi++);
    const li = document.createElement("li");
    li.className = "group-header collapsible ca-band-head " + (cls || "");
    li.innerHTML = `<span class="caret">▾</span> ${title} <span class="band-n">(${countN})</span>` + (sub ? `<span class="grp-sub">${sub}</span>` : "");
    li.title = "Click to collapse / expand this group";
    li.addEventListener("click", () => {
      const collapsed = li.classList.toggle("grp-collapsed");
      li.querySelector(".caret").textContent = collapsed ? "▸" : "▾";
      ul.querySelectorAll(`[data-band="${gi}"]`).forEach(el => el.classList.toggle("hidden", collapsed));
    });
    ul.appendChild(li);
    return gi;
  };
  const byCert = (a, b) => (b.certainty || 0) - (a.certainty || 0);

  // view-mode toggle bar
  $("caViewBar")?.classList.remove("hidden");
  const gbB = $("caGroupBands"), gcB = $("caGroupCohorts");
  if (gbB && gcB) {
    gbB.classList.toggle("active", caGroupMode === "bands");
    gcB.classList.toggle("active", caGroupMode === "cohorts");
    if (!gbB._wired) { gbB._wired = true; gbB.addEventListener("click", () => { if (caGroupMode !== "bands") { caGroupMode = "bands"; renderCaResults(lastSettings || {}); } }); }
    if (!gcB._wired) { gcB._wired = true; gcB.addEventListener("click", () => { if (caGroupMode !== "cohorts") { caGroupMode = "cohorts"; renderCaResults(lastSettings || {}); } }); }
  }

  if (caGroupMode === "cohorts") {
    // COHORTS: wallets sharing a coordination signal grouped as one suspect
    // cohort (strongest signal first); each row keeps the full detailed view.
    const { cohorts, solo } = buildCaCohorts(s, settings, labels);
    for (const co of cohorts) {
      const avg = Math.round(co.members.reduce((a, b) => a + (b.certainty || 0), 0) / co.members.length);
      const gi = addGroupHead(co.label, co.members.length, co.cls + " cohort-head", `${co.kindLabel} · avg ${avg}%`);
      for (const b of co.members.slice().sort(byCert)) addCaRow(b, gi);
    }
    if (solo.length) {
      const gi = addGroupHead("Ungrouped — no shared signal", solo.length, "band-low", "solo buyers");
      for (const b of solo.slice().sort(byCert)) addCaRow(b, gi);
    }
    if (!cohorts.length) {
      const note = document.createElement("li");
      note.className = "ca-cohort-empty";
      note.textContent = "No coordinated cohorts — no two early buyers shared a bundle, funding source, gas config, or buy size.";
      ul.insertBefore(note, ul.firstChild);
    }
  } else {
    // CONFIDENCE BANDS (default): collapsible HIGH / MED / LOW, empty bands shown.
    const bandOf = (b) => b.certainty >= 60 ? "HIGH" : b.certainty >= 40 ? "MED" : "LOW";
    const bands = { HIGH: [], MED: [], LOW: [] };
    for (const b of s.buyers) bands[bandOf(b)].push(b);
    const BAND_META = { HIGH: ["High confidence", "band-high"], MED: ["Medium confidence", "band-med"], LOW: ["Low / clean", "band-low"] };
    for (const key of ["HIGH", "MED", "LOW"]) {
      const gi = addGroupHead(BAND_META[key][0], bands[key].length, BAND_META[key][1]);
      for (const b of bands[key]) addCaRow(b, gi);
    }
  }
  wireResultsSearch("caSearch", "caList", "caSearchCount", "caSearchClear");
  syncResultsSearch("caSearch", "caList", "caSearchWrap", "caSearchCount");

  function addCaRow(b, bandGi) {
    const li = document.createElement("li");
    li.dataset.band = bandGi;
    li.className = "suspect ca-buyer" + (b.bundleMates ? " bundle" : "");
    li.innerHTML = `
      <div class="suspect-head">
        <span class="row-title mono"></span>
        <span class="pill cert-pill"></span>
      </div>
      <div class="row-sub ca-buyline"></div>
      <div class="ca-flags"></div>
      <div class="suspect-actions ca-actions-row">
        <button class="copy-btn">Copy</button>
        <button class="track-btn">Analyze wallet</button>
        <button class="chain-btn">${chainSet.has(b.addr) ? "⛓ In chain" : "⛓ Add to chain"}</button>
      </div>`;
    const nm = labels[b.addr];
    li.querySelector(".row-title").textContent = (nm ? `[${nm}] ` : "") + shortAddr(b.addr);
    li.querySelector(".row-title").title = b.addr;
    const cp = li.querySelector(".cert-pill");
    const band = b.certainty >= 60 ? "HIGH" : b.certainty >= 40 ? "MED" : "LOW";
    cp.textContent = `${band} ${b.certainty}%`;
    cp.classList.add(band === "HIGH" ? "pill-high" : band === "MED" ? "pill-med" : "pill-low");
    const head = li.querySelector(".suspect-head");
    const addPill = (txt, cls, title) => {
      const p = document.createElement("span");
      p.className = "pill " + cls; p.textContent = txt; if (title) p.title = title;
      head.insertBefore(p, cp);
    };
    if (b.isDeployer) addPill("DEPLOYER", "pill-dev", "This wallet created the token");
    if (b.bundleMates) addPill(`BUNDLE ×${b.bundleMates + 1}`, "pill-critical", "Bought in the same transaction/second as other early wallets");
    if (b.sharedFunder) addPill("SHARED FUNDER", "pill-fund", "Funded by the same source as other early buyers");
    if (b.devFunded) addPill("DEV FUNDED", "pill-dev", "Funded by the deployer wallet");
    if (b.freshAtLaunch) addPill("FRESH ⚠", "pill-fresh", "Wallet was ≤3 days old (or newer) at launch");
    if (b.unfundedFresh) addPill("UNFUNDED ⚠", "pill-fresh", "Fresh wallet with NO SOL funding found anywhere in its first transactions — it received the token with zero SOL history");
    if (b.share != null && b.share >= 0.01) addPill(`SUPPLY ${(b.share * 100).toFixed(1)}%`, "pill-ansem", "Share of total supply taken in the launch window");
    if (b.gasGroup) addPill(`GAS #${b.gasGroup}`, "pill-gas", `Identical priority-fee config as the other wallets in fee group #${b.gasGroup} — see “Common ground” above`);
    const dt = b.firstT - s.launchTs;
    li.querySelector(".ca-buyline").textContent =
      `bought ${fmtNum(b.tok)}${s.symbol ? " $" + s.symbol : ""}`
      + (b.sol > 0.0005 ? ` for ~${fmtNum(b.sol)} SOL` : "")
      + ` · tx #${b.firstIdx + 1} · +${dt < 60 ? dt + "s" : Math.round(dt / 60) + "m"} after launch`
      + (b.ageAtLaunchSec != null ? ` · wallet ${b.ageAtLaunchSec <= 0 ? "born at launch" : fmtAge(b.ageAtLaunchSec) + " old"}` : "")
      + (b.funder ? ` · funded by ${fundingSourceName(b.funder, settings)}` : "");
    const fl = li.querySelector(".ca-flags");
    if (b.flags.length) fl.innerHTML = b.flags.map(f => `<div class="ca-flag-line">• ${escHtml(f)}</div>`).join("");
    else fl.innerHTML = `<div class="ca-flag-line ok">no launch-window flags</div>`;
    li.querySelector(".copy-btn").addEventListener("click", () => {
      navigator.clipboard.writeText(b.addr);
      $("statusLine").textContent = "Address copied.";
      setTimeout(() => ($("statusLine").textContent = ""), 1500);
    });
    li.querySelector(".track-btn").addEventListener("click", async () => {
      const d = await store.get();
      if (!d.wallets.some(w => w.address === b.addr)) {
        d.wallets.push({ address: b.addr, added: Date.now(), name: "" });
        await store.set({ wallets: d.wallets });
        if (lastSettings) lastSettings.wallets = d.wallets;
        renderWalletList();
      }
      openDetail(b.addr);                      // full wallet analysis takes over
    });
    li.querySelector(".chain-btn").addEventListener("click", async (e) => {
      const dNow = await store.get();
      if ((dNow.chain || []).some(c => c.address === b.addr)) {
        await removeFromChain(b.addr);
        e.target.textContent = "⛓ Add to chain";
      } else {
        await addToChain(b.addr, labels[b.addr] || "", s.mint, (s.symbol ? "$" + s.symbol : shortAddr(s.mint)) + " CA");
        e.target.textContent = "⛓ In chain";
      }
    });
    ul.appendChild(li);
  }
}

async function renderWalletList() {
  renderChain();
  renderCaSaved();
  const { wallets, chain, cas } = await store.get();
  const ul = $("walletList");
  ul.innerHTML = "";
  // "Saved wallets" separator matters when another section (chain card or the
  // CA launch-scan list) sits above the wallet list.
  $("savedHeader").classList.toggle("hidden", !(wallets.length && ((chain || []).length || (cas || []).length)));
  $("emptyMsg").classList.toggle("hidden", wallets.length > 0);
  $("listToolbar").classList.toggle("hidden", wallets.length === 0);
  for (const a of [...selectedWallets]) if (!wallets.some(w => w.address === a)) selectedWallets.delete(a);
  for (const w of wallets) {
    const li = document.createElement("li");
    if (selectMode) {
      const chk = document.createElement("input");
      chk.type = "checkbox"; chk.className = "wallet-chk";
      chk.checked = selectedWallets.has(w.address);
      chk.addEventListener("click", (e) => e.stopPropagation());
      chk.addEventListener("change", () => { chk.checked ? selectedWallets.add(w.address) : selectedWallets.delete(w.address); updateSelCount(); });
      li.appendChild(chk);
      li.classList.add("selectable");
    }
    const left = document.createElement("div");
    left.className = "wallet-left";
    const nameHtml = w.name
      ? `<div class="wallet-name"></div><div class="wallet-addr wallet-sub"></div>`
      : `<div class="wallet-addr"></div>`;
    left.innerHTML = `${nameHtml}<div class="wallet-sub added"></div>`;
    if (w.name) {
      left.querySelector(".wallet-name").textContent = w.name;
      left.querySelector(".wallet-addr").textContent = shortAddr(w.address);
    } else {
      left.querySelector(".wallet-addr").textContent = shortAddr(w.address);
    }
    left.querySelector(".added").textContent = "added " + new Date(w.added).toLocaleDateString();

    const rename = document.createElement("button");
    rename.className = "icon-btn small"; rename.textContent = "✎"; rename.title = "Name this wallet";
    rename.addEventListener("click", (e) => {
      e.stopPropagation();
      if (li.querySelector(".rename-input")) return;
      const input = document.createElement("input");
      input.className = "rename-input";
      input.value = w.name || "";
      input.placeholder = "Wallet name";
      left.prepend(input);
      input.focus();
      const save = async () => {
        const d = await store.get();
        const target = d.wallets.find(x => x.address === w.address);
        if (target) { target.name = input.value.trim(); await store.set({ wallets: d.wallets }); }
        renderWalletList();
      };
      input.addEventListener("keydown", (ev) => { if (ev.key === "Enter") save(); if (ev.key === "Escape") renderWalletList(); });
      input.addEventListener("blur", save);
      input.addEventListener("click", (ev) => ev.stopPropagation());
    });

    const rm = document.createElement("button");
    rm.className = "remove-btn"; rm.textContent = "✕"; rm.title = "Remove";
    rm.addEventListener("click", async (e) => {
      e.stopPropagation();
      const d = await store.get();
      d.wallets = d.wallets.filter(x => x.address !== w.address);
      purgeCache(d, w.address);                       // drop cached analysis, CA scan + saved layouts
      await store.set({ wallets: d.wallets, cache: d.cache, caCache: d.caCache, mapLayouts: d.mapLayouts });
      if (lastSettings) { lastSettings.wallets = d.wallets; lastSettings.cache = d.cache; lastSettings.mapLayouts = d.mapLayouts; }
      renderWalletList();
    });

    const cp = document.createElement("button");
    cp.className = "icon-btn small"; cp.textContent = "⧉"; cp.title = "Copy address";
    cp.addEventListener("click", (e) => {
      e.stopPropagation();
      navigator.clipboard.writeText(w.address);
      cp.textContent = "✓"; setTimeout(() => (cp.textContent = "⧉"), 1200);
    });

    const right = document.createElement("div");
    right.className = "wallet-actions";
    right.append(cp, rename, rm);
    li.append(left, right);
    li.addEventListener("click", () => {
      if (selectMode) {
        const chk = li.querySelector(".wallet-chk");
        if (chk) { chk.checked = !chk.checked; chk.dispatchEvent(new Event("change")); }
      } else openDetail(w.address);
    });
    ul.appendChild(li);
  }
  updateSelCount();
}

// Every analysis opens COMPACTED: all collapsible detail sections start closed so
// the user sees the stats + outcome summary first and expands what's relevant.
function collapseAllSections() {
  // Only the DETAIL panel's sections — the chain section lives on the list screen.
  document.querySelectorAll("#detailPanel .h3-toggle[data-target]").forEach(btn => {
    const target = $(btn.dataset.target);
    if (!target) return;
    target.classList.add("hidden");
    const caret = btn.querySelector(".caret");
    if (caret) caret.textContent = "▸";
  });
}

async function openDetail(address, force = false) {
  currentAddress = address;
  show("detail");
  collapseAllSections();   // every analysis opens compacted — expand what's relevant
  const { wallets } = await store.get();
  const named = wallets.find(w => w.address === address);
  $("detailAddr").textContent = named?.name ? `[${named.name}] · ${shortAddr(address)}` : address;
  $("detailAddr").title = address;
  $("detailError").classList.add("hidden");
  $("detailContent").classList.add("hidden");
  $("loading").classList.remove("hidden");
  $("loadingMsg").textContent = "Fetching…";

  const d = await store.get();
  if (!d.apiKey) {
    $("loading").classList.add("hidden");
    showError("detailError", "No API key set. Open Settings and paste your free Helius API key.");
    return;
  }

  // Cached results persist indefinitely — labelling, navigating, and reopening
  // never re-hit the API. A fresh analysis runs ONLY when Refresh is pressed
  // (force) or a per-analysis filter changed (which clears the cache).
  const cached = d.cache[address];
  if (!force && cached && cached.v === CACHE_VERSION) {
    renderDetail(cached.data, d);
    return;
  }

  try {
    const data = await runAnalysis(address, d, (m) => { $("loadingMsg").textContent = m; });
    renderDetail(data, d);
  } catch (err) {
    $("loading").classList.add("hidden");
    showError("detailError", err.message || String(err));
  }
}

// Runs the full fetch → analyze → classify → bundle pipeline for one wallet,
// caches the result, and returns it. Progress strings go to `progress`, so the
// same pipeline powers both the detail view and headless multi-wallet refresh.
async function runAnalysis(address, d, progress = () => {}) {
    const holdingsP = fetchHoldings(address, d.apiKey);
    const txsP = fetchTransactions(address, d.apiKey, d.txDepth, (n) => {
      progress(`Fetched ${n} / up to ${d.txDepth} transactions…`);
    });
    const [holdings, txs] = await Promise.all([holdingsP, txsP]);
    const stats = analyze(txs, address, { dust: d.dust, solThresh: d.solThresh });
    stats.walletEdges = [];   // peer edges (counterparty ↔ counterparty) for the constellation
    // Supply-share flags: one getAssetBatch call for every token that moved
    // directly between this wallet and a counterparty.
    progress("Checking token supplies…");
    const allMints = new Set();
    for (const c of stats.topCounterparties) for (const m of c.tokenMoves || []) allMints.add(m.mint);
    const supplies = await fetchTokenSupplies([...allMints], d.apiKey);
    // Price context, three sources so moved tokens are valued even when the
    // wallet no longer holds them: holdings prices → getAssetBatch prices →
    // Jupiter public price API for anything still unpriced.
    const priceMap = {};
    for (const tk of holdings.tokens) if (tk.pricePerToken != null) priceMap[tk.mint] = tk.pricePerToken;
    for (const [mint, s] of Object.entries(supplies)) if (s.price != null && priceMap[mint] == null) priceMap[mint] = s.price;
    const unpriced = [...allMints].filter(m => priceMap[m] == null).slice(0, 50);
    if (unpriced.length) {
      try {
        const jr = await fetch(`https://lite-api.jup.ag/price/v3?ids=${unpriced.join(",")}`);
        if (jr.ok) {
          const jj = await jr.json();
          const table = jj?.data || jj || {};
          for (const [mint, v] of Object.entries(table)) {
            const p = v?.usdPrice ?? v?.price;
            if (p != null && priceMap[mint] == null) priceMap[mint] = Number(p);
          }
        }
      } catch { /* price data is additive */ }
    }
    const solPrice = holdings.sol.pricePerToken ?? null;
    stats.priceMap = priceMap;
    stats.solPrice = solPrice;
    applySupplyFlags(stats.topCounterparties, supplies, (d.supplyPct ?? 0.5) / 100, { priceMap, solPrice });

    // Ticker resolution: every move/split shows a symbol, never a mint prefix,
    // wherever one exists (supply metadata first, then held-token metadata).
    const symbolMap = {};
    for (const [mint, s] of Object.entries(supplies)) if (s.symbol) symbolMap[mint] = s.symbol;
    for (const tk of holdings.tokens) if (tk.symbol && tk.symbol !== "?" && !symbolMap[tk.mint]) symbolMap[tk.mint] = tk.symbol;
    stats.symbolMap = symbolMap;
    for (const c of stats.topCounterparties) {
      for (const m of c.bigMoves || []) if (!m.symbol && symbolMap[m.mint]) m.symbol = symbolMap[m.mint];
      for (const m of c.tokenMoves || []) if (!m.symbol && symbolMap[m.mint]) m.symbol = symbolMap[m.mint];
      for (const m of c.interactions || []) if (m.mint && !m.symbol && symbolMap[m.mint]) m.symbol = symbolMap[m.mint];
      if (c.splitInfo && !c.splitInfo.symbol && symbolMap[c.splitInfo.mint]) c.splitInfo.symbol = symbolMap[c.splitInfo.mint];
    }

    // Actual wallet age: exact if the analyzed window reaches the first tx,
    // otherwise one tiny lookup for the earliest transaction.
    if (txs.length < d.txDepth && stats.oldestTs) {
      stats.walletAgeSec = Math.floor(Date.now() / 1000) - stats.oldestTs;
      stats.walletAgeExact = true;
    } else {
      try {
        const res = await fetch(`https://api.helius.xyz/v0/addresses/${address}/transactions?api-key=${d.apiKey}&limit=1&sort-order=asc`);
        const first = res.ok ? await res.json() : [];
        if (Array.isArray(first) && first[0]?.timestamp) {
          stats.walletAgeSec = Math.floor(Date.now() / 1000) - first[0].timestamp;
          stats.walletAgeExact = true;
        }
      } catch { /* fall back below */ }
      if (stats.walletAgeSec == null && stats.oldestTs) {
        stats.walletAgeSec = Math.floor(Date.now() / 1000) - stats.oldestTs;
        stats.walletAgeExact = false; // lower bound: window didn't reach the first tx
      }
    }

    // Large-inflow timestamps for the timing-bias score: big SOL in + big supply in.
    stats.largeInflowTs = [
      ...(stats.largeSolInflows || []),
      ...stats.topCounterparties.flatMap(c => (c.supplyMoves || []).filter(m => m.dir === "in").map(m => m.t)),
    ];

    progress("Classifying counterparties…");
    const fundingAddrs = (stats.fundingEvents || []).map(f => f.from);
    const clsAddrs = [...new Set([...stats.topCounterparties.map(c => c.addr), ...fundingAddrs])];
    const cls = await classifyCounterparties(clsAddrs, d.apiKey);
    for (const c of stats.topCounterparties) {
      c.cls = cls[c.addr] || { kind: "unknown", label: "Unclassified" };
      // A counterparty that IS a token mint address is the token contract itself.
      if (allMints.has(c.addr)) c.cls = { kind: "agent", label: "Token mint (contract)", source: "mint match" };
    }
    for (const f of stats.fundingEvents || []) f.cls = cls[f.from] || { kind: "unknown", label: "Unclassified" };

    // FLAG: an established (very old) wallet that seeded this brand-new wallet.
    // A long-lived wallet funding a fresh one is a strong dev/insider seed or
    // linked-main signal. Only checked when the tracked wallet is confirmed
    // brand new (exact age ≤ 30d) and only for personal-wallet funders —
    // exchange/custodial funding is normal — so it costs one tiny first-tx
    // lookup per such funder and nothing for established wallets.
    stats.oldFunderFlags = [];
    const OLD_FUNDER_SEC = 180 * 86400;   // "very old" funder ≥ 6 months
    const NEW_WALLET_SEC = 30 * 86400;    // "brand new" recipient ≤ 30 days
    // The flag used to be skipped whenever the analyzed window didn't reach the
    // wallet's first tx (walletAgeExact false) — very active fresh wallets fell
    // through. Now ONE tiny first-tx lookup settles the wallet's true age.
    if (stats.walletAgeExact !== true && (stats.walletAgeSec == null || stats.walletAgeSec <= NEW_WALLET_SEC * 3)) {
      try {
        const r = await fetch(`https://api.helius.xyz/v0/addresses/${address}/transactions?api-key=${d.apiKey}&limit=1&sort-order=asc`);
        const first = r.ok ? await r.json() : [];
        if (Array.isArray(first) && first[0]?.timestamp) {
          stats.walletAgeSec = Math.floor(Date.now() / 1000) - first[0].timestamp;
          stats.walletAgeExact = true;
        }
      } catch { /* additive — the estimate stands */ }
      await new Promise(res => setTimeout(res, 130));
    }
    if (stats.walletAgeExact === true && stats.walletAgeSec != null && stats.walletAgeSec <= NEW_WALLET_SEC) {
      const personalFunders = (stats.fundingEvents || [])
        // RULE: being in the funding database does NOT exempt a wallet from the
        // old→new check — labeled funders are age-checked too (their label still
        // shows, so custodial noise stays easy to judge). Unclassified senders
        // count too: a funder whose classification failed is still a funder —
        // only clear exchange/program/bot infrastructure is skipped as normal.
        .filter(f => f.cls?.kind === "wallet" || f.cls?.kind === "unknown" || !f.cls || labelFor(f.from))
        .sort((a, b) => a.firstT - b.firstT)                          // earliest (the seeder) first
        .slice(0, 5);
      for (const f of personalFunders) {
        try {
          // limit=10 (was 1): the same page gives the funder's age AND its own
          // ORIGIN — who established this funder. An old "hot wallet" that was
          // itself set up by an exchange years ago reads very differently from
          // a personal main, so the back-check is shown wherever funders are.
          const r = await fetch(`https://api.helius.xyz/v0/addresses/${f.from}/transactions?api-key=${d.apiKey}&limit=10&sort-order=asc`);
          const first = r.ok ? await r.json() : [];
          if (Array.isArray(first) && first[0]?.timestamp) {
            f.funderAgeSec = Math.floor(Date.now() / 1000) - first[0].timestamp;
            f.funderAgeExact = true;
            outer2:
            for (const tx of first) {
              for (const nt of tx.nativeTransfers || []) {
                if (nt.toUserAccount === f.from && nt.fromUserAccount && nt.fromUserAccount !== f.from && Number(nt.amount || 0) > 0) {
                  f.funderOriginAddr = nt.fromUserAccount;
                  const ol = labelFor(nt.fromUserAccount);
                  f.funderOriginLabel = ol ? ol.label.replace(/ \((labeled|added)\)$/, "")
                    : ((d.connectors || []).includes(nt.fromUserAccount) ? "Connector (relayer)" : null);
                  break outer2;
                }
              }
            }
          }
        } catch { /* funder age is additive — skip on error */ }
        await new Promise(res => setTimeout(res, 150));
        if (f.funderAgeSec != null && f.funderAgeSec >= OLD_FUNDER_SEC) {
          const extreme = f.funderAgeSec >= 365 * 86400 && stats.walletAgeSec <= 7 * 86400;
          f.oldFundsNew = true;
          stats.oldFunderFlags.push({
            from: f.from, funderAgeSec: f.funderAgeSec, recipientAgeSec: stats.walletAgeSec,
            gapSec: f.funderAgeSec - stats.walletAgeSec, tier: extreme ? "extreme" : "high",
            total: f.total, count: f.count, firstT: f.firstT,
          });
        }
      }
      stats.oldFunderFlags.sort((a, b) => b.funderAgeSec - a.funderAgeSec);
    }

    // Age the recent SOL/stable-out destinations (bounded, ~6 distinct) so the
    // "recent transfers out" panel can split them into fresh vs aged wallets.
    // Reuses any age already known from funders; costs one tiny lookup each.
    stats.destAges = {};
    for (const f of stats.fundingEvents || []) if (f.funderAgeSec != null) stats.destAges[f.from] = f.funderAgeSec;
    const distinctDests = [];
    for (const o of stats.solStableOut || []) {
      if (!distinctDests.includes(o.to) && stats.destAges[o.to] == null && !labelFor(o.to)) distinctDests.push(o.to);
      if (distinctDests.length >= 6) break;
    }
    for (const dest of distinctDests) {
      try {
        const r = await fetch(`https://api.helius.xyz/v0/addresses/${dest}/transactions?api-key=${d.apiKey}&limit=1&sort-order=asc`);
        const first = r.ok ? await r.json() : [];
        if (Array.isArray(first) && first[0]?.timestamp) stats.destAges[dest] = Math.floor(Date.now() / 1000) - first[0].timestamp;
      } catch { /* additive — skip on error */ }
      await new Promise(res => setTimeout(res, 130));
    }

    // FLAG: serial funder — REWORKED. High fan-out alone NEVER triggers it any
    // more: plenty of legitimate sources (payment services, distribution
    // wallets) fund many recipients by design and were getting mislabeled.
    // The flag now requires the specific habit that matters: an ESTABLISHED
    // wallet REPEATEDLY sending token supply to FRESH wallets that have no
    // funding and no buys — the same fresh-unfunded-receiver profile flagged
    // on individual wallets, observed at least twice among sampled recipients.
    // Bounded: top 3 funders, one 100-tx page each, ≤3 recipient inspections.
    const topFunders = [...(stats.fundingEvents || [])]
      // custodial hot wallets AND connector relayers fund everyone — not a signal
      .filter(f => !(f.cls?.kind === "exchange") && !labelFor(f.from) && !(d.connectors || []).includes(f.from))
      .sort((a, b) => (b.total || 0) - (a.total || 0))
      .slice(0, 3);
    for (const f of topFunders) {
      try {
        if (f.funderAgeSec == null) {                       // age not fetched yet (wallet wasn't ≤30d) — one small lookup, origin included
          const r0 = await fetch(`https://api.helius.xyz/v0/addresses/${f.from}/transactions?api-key=${d.apiKey}&limit=10&sort-order=asc`);
          const first = r0.ok ? await r0.json() : [];
          if (Array.isArray(first) && first[0]?.timestamp) {
            f.funderAgeSec = Math.floor(Date.now() / 1000) - first[0].timestamp;
            f.funderAgeExact = true;
            outer3:
            for (const tx of first) {
              for (const nt of tx.nativeTransfers || []) {
                if (nt.toUserAccount === f.from && nt.fromUserAccount && nt.fromUserAccount !== f.from && Number(nt.amount || 0) > 0) {
                  f.funderOriginAddr = nt.fromUserAccount;
                  const ol = labelFor(nt.fromUserAccount);
                  f.funderOriginLabel = ol ? ol.label.replace(/ \((labeled|added)\)$/, "")
                    : ((d.connectors || []).includes(nt.fromUserAccount) ? "Connector (relayer)" : null);
                  break outer3;
                }
              }
            }
          }
          await new Promise(res => setTimeout(res, 130));
        }
        const r = await fetch(`https://api.helius.xyz/v0/addresses/${f.from}/transactions?api-key=${d.apiKey}&limit=100`);
        const txs = r.ok ? await r.json() : [];
        const dests = new Set();          // every recipient (context only — NOT a trigger)
        const tokenDests = new Set();     // recipients of TOKEN/SUPPLY sends — the ones that matter
        for (const tx of Array.isArray(txs) ? txs : []) {
          for (const nt of tx.nativeTransfers || []) {
            const amt = Number(nt.amount || 0) / LAMPORTS;
            if (nt.fromUserAccount === f.from && nt.toUserAccount && nt.toUserAccount !== f.from && amt >= 0.001) dests.add(nt.toUserAccount);
          }
          for (const tt of tx.tokenTransfers || []) {
            if (tt.fromUserAccount === f.from && tt.toUserAccount && tt.toUserAccount !== f.from && Number(tt.tokenAmount || 0) > 0) tokenDests.add(tt.toUserAccount);
          }
        }
        f.serialFanout = dests.size;
        // Inspect up to 3 token recipients (the analyzed wallet is already known —
        // skip it): fresh + never funded + no buys = the profile that counts.
        let freshUnfunded = 0, sampled = 0;
        for (const dest of tokenDests) {
          if (sampled >= 3) break;
          if (dest === address) continue;
          try {
            const r1 = await fetch(`https://api.helius.xyz/v0/addresses/${dest}/transactions?api-key=${d.apiKey}&limit=10&sort-order=asc`);
            const first = r1.ok ? await r1.json() : [];
            if (Array.isArray(first) && first[0]?.timestamp) {
              sampled++;
              const fresh = (Math.floor(Date.now() / 1000) - first[0].timestamp) <= 45 * 86400;
              let funded = false, bought = false;
              for (const tx of first) {
                if (tx.type === "SWAP" || tx.events?.swap) bought = true;
                for (const nt of tx.nativeTransfers || []) {
                  if (nt.toUserAccount === dest && nt.fromUserAccount && nt.fromUserAccount !== dest && Number(nt.amount || 0) > 0) funded = true;
                }
              }
              if (fresh && !funded && !bought) freshUnfunded++;
            }
          } catch { /* skip */ }
          await new Promise(res => setTimeout(res, 130));
        }
        f.serialFreshUnfunded = freshUnfunded;
        f.serialSampled = sampled;
        f.serialFunder = (f.funderAgeSec != null && f.funderAgeSec >= 180 * 86400) && freshUnfunded >= 2;
      } catch { /* additive — skip on error */ }
      await new Promise(res => setTimeout(res, 130));
    }

    // Trace large outbound supply chunks onward (bundle chains), max 4 recipients.
    const traceTargets = stats.topCounterparties
      .filter(c => c.cls.kind === "wallet" &&
        ((c.bigMoves || []).some(m => m.dir === "out") || (c.supplyMoves || []).some(m => m.dir === "out")))
      .slice(0, 4);
    if (traceTargets.length > 0) {
      progress("Tracing token forwarding (bundle check)…");
      const visited = new Set([address, ...stats.topCounterparties.map(c => c.addr)]);
      for (const c of traceTargets) {
        const m = [...(c.bigMoves || []), ...(c.supplyMoves || [])]
          .filter(x => x.dir === "out").sort((a, b) => b.amt - a.amt)[0];
        try {
          c.bundleChain = await traceForward(d.apiKey, c.addr, m.mint, m.amt, m.t, new Set([address, c.addr]));
        } catch { c.bundleChain = []; }
      }
    }

    // Cross-wallet bundle heuristics: profile the top suspects from their own
    // history (age, first funder, funding time, fees, buys) and correlate.
    const labelsMap = Object.fromEntries((d.wallets || []).filter(w => w.name).map(w => [w.address, w.name]));
    const sideOpts = { solThresh: d.solThresh, usdThresh: d.usdThresh, buyEvents: stats.buyEvents, largeInflowTs: stats.largeInflowTs, ignored: suspectExclusions(d, address), ansem: d.ansemWallets, calib: feedbackCalibration(d.feedback), priceMap, solPrice, labels: labelsMap };
    const prelim = findSideWallets(stats.topCounterparties, sideOpts);
    const bundleCandidates = prelim.filter(s => s.group === "supply" || s.certainty >= 40).slice(0, 8);
    if (bundleCandidates.length >= 2) {
      progress("Cross-checking bundle heuristics (funding, age, fees, timed buys)…");
      const profiles = [];
      for (const cand of bundleCandidates) {
        try {
          let res = await fetch(`https://api.helius.xyz/v0/addresses/${cand.addr}/transactions?api-key=${d.apiKey}&limit=100&sort-order=asc`);
          if (!res.ok) res = await fetch(`https://api.helius.xyz/v0/addresses/${cand.addr}/transactions?api-key=${d.apiKey}&limit=100`);
          const ptxs = res.ok ? await res.json() : [];
          if (Array.isArray(ptxs) && ptxs.length) profiles.push(extractProfile(cand.addr, ptxs));
        } catch { /* skip this wallet's profile */ }
        await new Promise(r => setTimeout(r, 250));
      }
      if (profiles.length >= 2) {
        const corr = correlateBundles(profiles, labelsMap);
        for (const c of stats.topCounterparties) if (corr[c.addr]) c.bundle = corr[c.addr];
      }
      // Constellation peer edges: from each profiled wallet's own history, record
      // direct transfers to OTHER counterparties in this analysis (not the tracked
      // wallet). These become dashed inter-wallet lines on the map.
      const cpSet = new Set(stats.topCounterparties.map(c => c.addr));
      const edgeMap = new Map();   // "lo|hi" -> { ab, ba }  (ab = lo→hi count, ba = hi→lo count)
      for (const p of profiles) {
        for (const [other, io] of Object.entries(p.interactedWith || {})) {
          if (other === address || other === p.addr || !cpSet.has(other)) continue;
          const out = (io && io.out) || 0, inn = (io && io.in) || 0;
          const lo = p.addr < other ? p.addr : other, hi = p.addr < other ? other : p.addr;
          const e = edgeMap.get(lo + "|" + hi) || { ab: 0, ba: 0 };
          if (p.addr === lo) { e.ab += out; e.ba += inn; } else { e.ab += inn; e.ba += out; }
          edgeMap.set(lo + "|" + hi, e);
        }
      }
      stats.walletEdges = [...edgeMap.entries()].map(([k, e]) => { const [a, b] = k.split("|"); return { a, b, ab: e.ab, ba: e.ba, w: Math.max(e.ab, e.ba, 1) }; });
      // Attach each profiled wallet's first funder (for the funding-source badge),
      // even when correlation didn't fire.
      const funderByAddr = Object.fromEntries(profiles.map(p => [p.addr, p.firstFunder]).filter(x => x[1]));
      for (const c of stats.topCounterparties) {
        if (funderByAddr[c.addr]) c.bundle = { ...(c.bundle || { score: 0, evidence: [], refs: [] }), firstFunder: funderByAddr[c.addr] };
      }
    }

    // Persist group labels: wallets repeatedly seen as suspects build a history
    // (side-wallet / funding-wallet / bundle-prone) shown wherever they appear.
    const finalSuspects = findSideWallets(stats.topCounterparties, sideOpts);
    const tags = d.walletTags || {};
    for (const s of finalSuspects) {
      const e = tags[s.addr] || { tags: [], seen: 0 };
      const want = [s.group === "supply" ? "side-wallet" : "funding-wallet", ...(s.bundleRisk ? ["bundle-prone"] : [])];
      for (const t of want) if (!e.tags.includes(t)) e.tags.push(t);
      e.seen++; e.last = Date.now();
      tags[s.addr] = e;
    }
    d.walletTags = tags;

    const data = { holdings, stats, fetchedAt: Date.now() };
    d.cache[address] = { ts: Date.now(), v: CACHE_VERSION, data };
    await store.set({ cache: d.cache, walletTags: tags });
    return data;
}

let lastStats = null;
let lastSettings = null;
let lastData = null;
let resultSort = "relevance"; // relevance | new | old

// Comparator for the user's sort choice; returns 0 (keep prior order) for relevance.
function resultCmp(a, b) {
  if (resultSort === "new") return (b.lastTs || 0) - (a.lastTs || 0);
  if (resultSort === "old") return (a.lastTs || 0) - (b.lastTs || 0);
  return 0;
}
function applySort(arr) { return resultSort === "relevance" ? arr : [...arr].sort(resultCmp); }

function renderDetail(data, settings = {}) {
  lastData = data;
  const { holdings, stats } = data;
  lastStats = stats;
  lastSettings = settings;
  $("loading").classList.add("hidden");
  $("detailContent").classList.remove("hidden");

  $("statBuys").textContent = stats.buys;
  $("statSells").textContent = stats.sells;
  const bsr = stats.buySellRatio;
  $("statBuySell").textContent = (stats.buys === 0 && stats.sells === 0) ? "–"
    : bsr == null ? (stats.buys ? "∞" : "0")            // sells == 0
    : bsr >= 10 ? bsr.toFixed(0) : bsr.toFixed(2);
  $("statSwaps").textContent = stats.swaps;
  $("statHold").textContent = fmtDuration(stats.avgHoldSec);
  $("statHoldOpen").textContent = fmtDuration(stats.avgOpenAgeSec);
  $("statWalletAge").textContent = stats.walletAgeSec != null
    ? fmtDuration(stats.walletAgeSec) + (stats.walletAgeExact === false ? "+" : "")
    : "–";
  $("statTxs").textContent = stats.txCount;

  // Freshness line: cached results are reused indefinitely until Refresh.
  if (data.fetchedAt) {
    const ageMin = Math.round((Date.now() - data.fetchedAt) / 60000);
    const when = ageMin < 1 ? "just now" : ageMin < 60 ? `${ageMin} min ago` : `${Math.round(ageMin / 60)} h ago`;
    $("cacheNote").textContent = `Cached analysis · fetched ${when} · press Refresh for live data`;
    $("cacheNote").classList.remove("hidden");
  } else {
    $("cacheNote").classList.add("hidden");
  }

  const noteParts = [];
  noteParts.push(`Based on the last ${stats.txCount} transactions` + (stats.oldestTs ? ` (back to ${fmtDate(stats.oldestTs)})` : "") + ".");
  noteParts.push(`Transfers: ${stats.transfersIn} in / ${stats.transfersOut} out.`);
  if (stats.avgHoldSec != null) noteParts.push(`Hold time from ${stats.closedCount} closed position lot(s); ${stats.openCount} still open.`);
  if (stats.unmatchedDisposals > 0) noteParts.push(`${stats.unmatchedDisposals} disposal(s) of tokens acquired before this window were excluded from hold time.`);
  if (stats.spamSkippedMints > 0) noteParts.push(`${stats.spamSkippedMints} single-airdrop token(s) excluded from open-position age (dust filter).`);
  $("analysisNote").textContent = noteParts.join(" ");

  // Holdings
  const ul = $("holdingsList");
  ul.innerHTML = "";
  let total = 0;
  const addRow = (title, sub, val, valSub) => {
    const li = document.createElement("li");
    li.innerHTML = `<div class="row-main"><span class="row-title"></span><span class="row-sub"></span></div>
      <div class="row-right"><div class="row-val"></div><div class="row-val-sub"></div></div>`;
    li.querySelector(".row-title").textContent = title;
    li.querySelector(".row-sub").textContent = sub;
    li.querySelector(".row-val").textContent = val;
    li.querySelector(".row-val-sub").textContent = valSub;
    ul.appendChild(li);
  };
  if (holdings.sol.amount > 0 || holdings.sol.usd != null) {
    addRow("SOL", "Solana", fmtNum(holdings.sol.amount, 4), fmtUsd(holdings.sol.usd));
    total += holdings.sol.usd || 0;
  }
  const dustOn = !!settings.dust;
  const dustUsd = Number(settings.dustUsd || 1);
  let dustHidden = 0;
  const visible = holdings.tokens.filter(tk => {
    if (dustOn && tk.usd != null && tk.usd < dustUsd) { dustHidden++; return false; }
    return true;
  });
  for (const tk of visible.slice(0, 60)) {
    addRow(tk.symbol, tk.name === tk.symbol ? shortAddr(tk.mint) : tk.name, fmtNum(tk.amount), fmtUsd(tk.usd));
    total += tk.usd || 0;
  }
  if (visible.length > 60) {
    const li = document.createElement("li");
    li.innerHTML = `<span class="hint">+ ${visible.length - 60} more tokens</span>`;
    ul.appendChild(li);
  }
  if (dustHidden > 0) {
    const li = document.createElement("li");
    li.innerHTML = `<span class="hint">${dustHidden} dust holding(s) hidden (&lt; $${dustUsd})</span>`;
    ul.appendChild(li);
  }
  if (ul.children.length === 0) {
    ul.innerHTML = `<li><span class="hint">No holdings found.</span></li>`;
  }
  $("totalValue").textContent = total > 0 ? "≈ " + fmtUsd(total) : "";

  renderOldFunderAlert(stats, settings);
  renderSoftFlags(stats);
  renderSolOut(stats, settings);
  renderSells(stats);
  renderFunding(stats, settings);
  renderSideWallets(stats, settings);
  renderCounterparties(stats, settings);
  // Self-assessment uses the same suspect set the side-wallet section shows.
  const _sus = findSideWallets(stats.topCounterparties || [], {
    solThresh: settings.solThresh, usdThresh: settings.usdThresh,
    buyEvents: stats.buyEvents, largeInflowTs: stats.largeInflowTs,
    ignored: suspectExclusions(settings, currentAddress), ansem: settings.ansemWallets, calib: feedbackCalibration(settings.feedback),
    priceMap: stats.priceMap, solPrice: stats.solPrice,
    labels: Object.fromEntries((settings.wallets || []).filter(w => w.name).map(w => [w.address, w.name])),
  });
  renderOutcome(stats, settings, _sus);
}

// ---------- investigation self-assessment ----------
// A transparent audit of how much the analysis itself can be trusted for this
// wallet — based on data coverage, not on how "guilty" the wallet looks. This
// is meta-confidence: strong data + clear separation = high; gaps = lower.
// Aggregate confidence that the analysed wallet is part of a side-wallet
// operation, built ONLY from the flagged interactions (the qualifying leads).
//
// This is deliberately NOT a sum of the individual percentages. Each flagged
// wallet's own certainty is one piece of evidence, combined with a noisy-OR
// (probabilistic OR): the figure rises with the NUMBER and STRENGTH of flags but
// can never exceed 100%. To stop many look-alike flags from stacking unfairly,
// flags of the SAME evidence type are discounted geometrically (the 2nd of a
// kind counts half, the 3rd a quarter…), while DIFFERENT evidence types
// (supply-sharing vs high-value funding vs bundle structure) corroborate each
// other at full strength. Capped at 97% — this is inference, not proof.
function assessFlaggedConfidence(suspects) {
  const flags = (suspects || []).filter(s => s && (s.certainty || 0) > 0);
  if (!flags.length) {
    return { confidence: 0, band: "NONE", nFlags: 0, nTypes: 0, top: 0,
      basis: "No interactions cleared the evidence bar in this window — there is nothing to combine, so no side-wallet confidence can be asserted." };
  }
  const typeName = { supply: "supply-sharing", funding: "high-value funding", bundle: "bundle structure", other: "circumstantial" };
  const byType = {};
  for (const s of flags) {
    const t = s.bundleRisk ? "bundle" : (s.group || "other");
    (byType[t] = byType[t] || []).push(Math.min(0.97, (s.certainty || 0) / 100));
  }
  const DECAY = 0.5;
  let across = 1;                        // ∏ (1 − typeConfidence) across evidence types
  for (const t of Object.keys(byType)) {
    const ps = byType[t].sort((a, b) => b - a);
    let within = 1;                      // decayed noisy-OR WITHIN one evidence type
    ps.forEach((p, k) => { within *= (1 - p * Math.pow(DECAY, k)); });
    across *= within;                    // full-strength noisy-OR ACROSS types
  }
  const P = Math.min(0.97, 1 - across);
  const confidence = Math.round(P * 100);
  const band = confidence >= 70 ? "HIGH" : confidence >= 45 ? "MED" : confidence >= 20 ? "LOW" : "MINIMAL";
  const top = Math.max(...flags.map(s => s.certainty || 0));
  const types = Object.keys(byType).map(t => typeName[t] || t);
  const basis =
    `Combined from ${flags.length} flagged interaction${flags.length > 1 ? "s" : ""} across `
    + `${types.length} evidence type${types.length > 1 ? "s" : ""} (${types.join(", ")}). `
    + `Strongest single flag ${top}%. Extra flags raise the figure with diminishing returns (repeats of the same kind count less) — it is not a sum of the percentages.`;
  return { confidence, band, nFlags: flags.length, nTypes: types.length, top, basis };
}

function assessInvestigation(stats, settings, suspects) {
  const depth = settings.txDepth || 300;
  const pos = [], caution = [];
  let score = 50;

  // 1. History depth coverage
  const hitCap = (stats.txCount || 0) >= depth;
  if (!hitCap) { score += 18; pos.push(`Full available history analyzed — ${stats.txCount} txs, below the ${depth} cap, so nothing older was missed.`); }
  else if (depth >= 2000) { score += 3; caution.push(`Hit the ${depth}-tx cap on a very active wallet — activity older than the window isn't included.`); }
  else { score -= 12; caution.push(`Reached the ${depth}-tx cap: only recent history was seen. Raise “Transactions analyzed” for a fuller picture.`); }

  // 2. Wallet-age coverage
  if (stats.walletAgeExact) { score += 6; pos.push(`Wallet age is exact — history reaches the wallet's first transaction.`); }
  else if (stats.walletAgeSec != null) { caution.push(`Wallet age is a lower bound — the window didn't reach the first transaction, so “% of position” for older tokens may be understated.`); }

  // 3. Counterparty classification coverage
  const cps = stats.topCounterparties || [];
  const classified = cps.filter(c => c.cls && c.cls.kind && c.cls.kind !== "unknown").length;
  const clsFrac = cps.length ? classified / cps.length : 1;
  if (cps.length && clsFrac >= 0.9) { score += 9; pos.push(`${Math.round(clsFrac * 100)}% of counterparties classified from on-chain account data.`); }
  else if (cps.length && clsFrac < 0.6) { score -= 8; caution.push(`Only ${Math.round(clsFrac * 100)}% of counterparties could be classified (RPC gaps) — some wallet/agent labels are uncertain.`); }

  // 4. Price coverage for moved tokens (value-based signals depend on this)
  const movedMints = new Set();
  for (const c of cps) for (const m of (c.tokenMoves || [])) movedMints.add(m.mint);
  const priced = [...movedMints].filter(m => stats.priceMap && stats.priceMap[m] != null).length;
  const priceFrac = movedMints.size ? priced / movedMints.size : 1;
  if (movedMints.size && priceFrac >= 0.8) { score += 8; pos.push(`Value data available for ${Math.round(priceFrac * 100)}% of moved tokens.`); }
  else if (movedMints.size && priceFrac < 0.5) { score -= 6; caution.push(`Only ${Math.round(priceFrac * 100)}% of moved tokens had a price — some SOL/USD value estimates are missing.`); }
  if (!stats.solPrice) caution.push(`SOL price was unavailable — value floors used a fallback.`);

  // 5. Bundle heuristics availability
  if (cps.some(c => c.bundle)) { score += 6; pos.push(`Cross-wallet bundle heuristics ran (shared funding, wallet age, gas fees, timed buys).`); }

  // 6. Findings separation / strength
  const highs = suspects.filter(s => s.certBand === "HIGH").length;
  const meds = suspects.filter(s => s.certBand === "MED").length;
  const withBundle = suspects.filter(s => s.bundleRisk).length;
  if (highs > 0) { score += 7; pos.push(`${highs} high-certainty lead(s)${withBundle ? `, ${withBundle} with bundle evidence` : ""} — clear signal, not borderline.`); }
  else if (suspects.length > 0 && meds === suspects.length) { score -= 5; caution.push(`All ${suspects.length} lead(s) are mid-certainty — treat as tentative and verify before acting.`); }
  if (suspects.length === 0) {
    if (!hitCap && (cps.length > 0)) { score += 4; pos.push(`No wallet cleared the evidence bar across a fully-covered history — reasonably confident there are no side wallets in this window.`); }
    else caution.push(`No leads found, but coverage is partial — absence here isn't proof of none.`);
  }

  // "Data draw accuracy from chain" — a single number: how complete/reliable the
  // underlying on-chain data was (the wallet-pull quality, condensed).
  const dataAccuracy = Math.max(10, Math.min(99, Math.round(score)));
  const dataNote = hitCap
    ? `Only the most recent ${depth} transactions were read — raise “Transactions analyzed” for fuller coverage.`
    : `Full available history was read (${stats.txCount} txs).`;

  // Per-result short confidence lines, focused on the side-wallet findings.
  const labelsMap = Object.fromEntries((settings.wallets || []).filter(w => w.name).map(w => [w.address, w.name]));
  const perResult = suspects.slice(0, 8).map(s => {
    const top = (s.factors || []).filter(f => f.w).sort((a, b) => b.w - a.w).slice(0, 3).map(f => f.label);
    return {
      addr: s.addr,
      name: labelsMap[s.addr] ? `[${labelsMap[s.addr]}]` : shortAddr(s.addr),
      certainty: s.certainty, band: s.certBand, bundleRisk: s.bundleRisk, bundleScore: s.bundleScore,
      ansemShare: !!s.ansemShare,
      why: top.join(" · ") || "weak circumstantial signals",
      fundedBy: s.fundedBy || null,
    };
  });

  let summary;
  if (!suspects.length) summary = hitCap
    ? "No side-wallet leads surfaced, but coverage is partial — absence here isn't proof of none. Raise the transaction depth to be sure."
    : "No side-wallet leads surfaced across a fully-read history — reasonably confident there are none in this window.";
  else {
    const highs = suspects.filter(s => s.certBand === "HIGH").length;
    if (highs) summary = `${highs} strong lead${highs > 1 ? "s" : ""} with repeated, high-value patterns — worth close attention. Everything below remains on-chain inference, not proof of ownership.`;
    else summary = "Leads are tentative — the patterns aren't repeated or large enough to be confident. Treat as starting points and verify.";
  }
  if ((stats.oldFunderFlags || []).length) {
    summary = "⚠ An old, established wallet funded this brand-new wallet (flagged at the top) — a strong dev/insider or linked-main signal. " + summary;
  }
  return { dataAccuracy, dataNote, perResult, summary };
}

function renderOutcome(stats, settings, suspects) {
  const a = assessInvestigation(stats, settings, suspects || []);
  const conf = assessFlaggedConfidence(suspects || []);
  const acc = $("dataAccuracy");
  acc.textContent = conf.nFlags ? conf.confidence + "%" : "—";
  acc.className = "oa-val " + (conf.band === "HIGH" ? "ob-strong" : conf.band === "MED" ? "ob-mod" : "ob-lim");
  acc.title = conf.basis + "  ·  Data coverage: " + a.dataNote;
  $("outcomeSummary").textContent = a.summary;
  const ul = $("outcomeResults");
  ul.innerHTML = "";
  if (!a.perResult.length) { ul.classList.add("hidden"); return; }
  ul.classList.remove("hidden");
  for (const r of a.perResult) {
    const li = document.createElement("li");
    const bandCls = r.band === "HIGH" ? "ob-strong" : r.band === "MED" ? "ob-mod" : "ob-lim";
    li.innerHTML = `
      <div class="or-head">
        <span class="or-name mono"></span>
        <span class="or-pills">
          ${r.fundedBy ? `<span class="or-fund">⬦ ${r.fundedBy}</span>` : ""}
          ${r.ansemShare ? `<span class="or-ansem" title="Ansem Derived Coin Supply Share — recognised false-positive pattern, certainty damped">ANSEM ⚠</span>` : ""}
          ${r.bundleRisk ? `<span class="or-bundle">BUNDLE ${r.bundleScore}%</span>` : ""}
          <span class="or-cert ${bandCls}">${r.certainty}%</span>
        </span>
      </div>
      <div class="or-why"></div>`;
    li.querySelector(".or-name").textContent = r.name;
    li.querySelector(".or-why").textContent = r.why;
    ul.appendChild(li);
  }
}

// Prominent banner: a very old wallet seeded this brand-new wallet.
// (The old out-degree "serial" heuristic is GONE — it flagged funding sources
// whose high fan-out is expected behaviour. Serial funding is now decided at
// analysis time only, by the repeated supply→fresh-unfunded-receiver rule.)
const SERIAL_AGE_SEC = 180 * 86400;   // "aged" threshold for supply-sender rows

// SOFT flag (informational, never scored): a fresh wallet that received token
// transfers/supply — ANY amount, no threshold — with its trading activity shown.
// Low or zero buy/sell strengthens the pattern but is not required.
function renderSoftFlags(stats) {
  const el = $("softFlag");
  if (!el) return;
  const fresh = stats.walletAgeSec != null && stats.walletAgeSec <= 30 * 86400;
  const receivedTokens = (stats.topCounterparties || []).some(c =>
    (c.supplyMoves || []).some(m => m.dir === "in") || (c.tokenMoves || []).some(m => m.dir === "in"));
  if (!(fresh && receivedTokens)) { el.classList.add("hidden"); el.innerHTML = ""; return; }
  const b = stats.buys || 0, s = stats.sells || 0;
  el.innerHTML = `<span class="sf-ico">◦</span> <b>Soft flag</b> — fresh wallet (${fmtAge(stats.walletAgeSec)}) received token transfers`
    + ` · trading: ${b} buy${b === 1 ? "" : "s"} / ${s} sell${s === 1 ? "" : "s"}${(b + s) === 0 ? " (none)" : ""}`
    + ` · no supply threshold applied — informational only.`;
  el.classList.remove("hidden");
}

function renderOldFunderAlert(stats, settings = {}) {
  const el = $("oldFunderAlert");
  if (!el) return;
  const flags = stats.oldFunderFlags || [];
  const labels = Object.fromEntries((settings.wallets || []).filter(w => w.name).map(w => [w.address, w.name]));
  // Serial funders under the REWORKED rule only: established wallets seen
  // repeatedly sending supply to fresh unfunded no-buy wallets.
  const serialByAddr = Object.fromEntries((stats.fundingEvents || []).filter(f => f.serialFunder).map(f => [f.from, f.serialFreshUnfunded || 0]));
  const recAge = fmtAge(stats.walletAgeSec);

  // Supply senders into a FRESH wallet — grouped with old→new because the logic
  // is the same family: who seeded this brand-new wallet, with SOL or with supply.
  // Computed at render time from cached data (no re-analysis needed).
  let supplyRows = [];
  if (stats.walletAgeSec != null && stats.walletAgeSec <= 30 * 86400) {
    const ageByFunder = Object.fromEntries((stats.fundingEvents || []).filter(f => f.funderAgeSec != null).map(f => [f.from, f.funderAgeSec]));
    const sus = findSideWallets(stats.topCounterparties || [], {
      solThresh: settings.solThresh, usdThresh: settings.usdThresh,
      buyEvents: stats.buyEvents, largeInflowTs: stats.largeInflowTs,
      ignored: suspectExclusions(settings, currentAddress), ansem: settings.ansemWallets,
      calib: feedbackCalibration(settings.feedback),
      priceMap: stats.priceMap, solPrice: stats.solPrice, labels,
    });
    for (const s of sus) {
      const sentIn = (s.supplyMoves || []).some(m => m.dir === "in") || (s.tokenMoves || []).some(m => m.dir === "in");
      if (!sentIn) continue;
      const age = ageByFunder[s.addr];
      const db = labelFor(s.addr);
      if (s.freshSender) supplyRows.push({ addr: s.addr, kind: "fresh" });
      else if (age != null && age >= SERIAL_AGE_SEC) supplyRows.push({ addr: s.addr, kind: "aged", age, serial: serialByAddr[s.addr] != null });
      else if (db) supplyRows.push({ addr: s.addr, kind: "db", label: db.label });
    }
  }

  // Serial funders get their own prominent section — visible for wallets of ANY
  // age (the habit belongs to the FUNDER), styled like the old→new flag. Funders
  // already listed in the old→new rows aren't repeated (they carry the tag inline).
  const serialRows = (stats.fundingEvents || []).filter(f => f.serialFunder && !flags.some(x => x.from === f.from));

  if (!flags.length && !supplyRows.length && !serialRows.length) { el.classList.add("hidden"); el.innerHTML = ""; return; }
  const extreme = flags.some(f => f.tier === "extreme");
  const rows = flags.map(f => {
    const db = labelFor(f.from);
    const isConn = (settings.connectors || []).includes(f.from);
    const nm = labels[f.from] ? `[${escHtml(labels[f.from])}]`
      : isConn ? "⚡ Connector (relayer) · " + shortAddr(f.from)
      : (db ? escHtml(db.label.replace(/ \((labeled|added)\)$/, "")) + " · " + shortAddr(f.from) : shortAddr(f.from));
    const serial = serialByAddr[f.from] != null;
    const serialTxt = `⟳ serial funder · supplied ${serialByAddr[f.from]} fresh unfunded wallet${serialByAddr[f.from] === 1 ? "" : "s"}`;
    const fe = (stats.fundingEvents || []).find(x => x.from === f.from);
    const originBit = fe?.funderOriginLabel ? ` · established by <b>${escHtml(fe.funderOriginLabel)}</b>`
      : fe?.funderOriginAddr ? ` · established by <span class="mono">${shortAddr(fe.funderOriginAddr)}</span>` : "";
    return `<li><span class="ofa-funder mono">${nm}</span> — <b>${fmtAge(f.funderAgeSec)}</b> old, sent ${fmtQty(f.total)} SOL `
      + `<span class="ofa-gap">· ${fmtAge(f.gapSec)} older than this wallet</span>${originBit}`
      + (serial ? ` <span class="serial-tag">${serialTxt}</span>` : "") + `</li>`;
  }).join("");
  const supRows = supplyRows.map(r => {
    const nm = labels[r.addr] ? `[${escHtml(labels[r.addr])}]` : shortAddr(r.addr);
    const what = r.kind === "fresh"
      ? `fresh, <b>unfunded</b> sender — appeared and immediately sent`
      : r.kind === "aged"
        ? `<b>${fmtAge(r.age)}</b> old — aged wallet sent supply${r.serial ? ` <span class="serial-tag">⟳ serial funder</span>` : ""}`
        : `funding-database wallet (${escHtml((r.label || "labeled").replace(/ \((labeled|added)\)$/, ""))}) sent token supply — unusual for a custodian`;
    return `<li><span class="ofa-funder mono">${nm}</span> — ${what}</li>`;
  }).join("");
  el.className = "old-funder-alert" + (extreme ? " extreme" : "");
  el.innerHTML =
    (flags.length
      ? `<div class="ofa-head"><span class="ofa-ico">⚠</span> Old wallet → brand-new wallet</div>`
        + `<div class="ofa-body">This wallet is only <b>${recAge}</b> old but was seeded by `
        + `${flags.length > 1 ? "established wallets" : "an established wallet"}. An old wallet funding a fresh one is a `
        + `strong sign of a dev/insider seed or a linked main — verify the funder${flags.length > 1 ? "s" : ""}:</div>`
        + `<ul class="ofa-list">${rows}</ul>`
      : "")
    + (supplyRows.length
      ? `<div class="ofa-head${flags.length ? " ofa-sub" : ""}"><span class="ofa-ico">⚠</span> Token supply sent to this fresh wallet</div>`
        + `<div class="ofa-body">This wallet is only <b>${recAge}</b> old and received token supply directly — the same seeding logic as old→new, done with tokens instead of SOL:</div>`
        + `<ul class="ofa-list">${supRows}</ul>`
      : "")
    + (serialRows.length
      ? `<div class="ofa-head${flags.length || supplyRows.length ? " ofa-sub" : ""}"><span class="ofa-ico">⟳</span> Serial funder — repeatedly supplies fresh wallets</div>`
        + `<div class="ofa-body">${serialRows.length > 1 ? "Funders" : "A funder"} of this wallet <b>repeatedly send${serialRows.length > 1 ? "" : "s"} token supply to brand-new wallets that have no funding and no buys</b> — the fresh-receiver pattern, observed more than once. Ordinary high-volume senders (payment services, distributors) do NOT trigger this. Not proof of an insider or dev link — treat it as a lead:</div>`
        + `<ul class="ofa-list">${serialRows.map(f => {
            const nm = labels[f.from] ? `[${escHtml(labels[f.from])}]` : shortAddr(f.from);
            return `<li><span class="ofa-funder mono">${nm}</span> — <b>${fmtAge(f.funderAgeSec)}</b> old, supplied <b>${f.serialFreshUnfunded}/${f.serialSampled || "?"}</b> sampled recipients that are fresh, unfunded and buy-less</li>`;
          }).join("")}</ul>`
      : "");
  el.classList.remove("hidden");
}

function renderFunding(stats, settings = {}) {
  const labels = Object.fromEntries((settings.wallets || []).filter(w => w.name).map(w => [w.address, w.name]));
  const events = stats.fundingEvents || [];
  const section = $("fundingSection");
  section.classList.toggle("hidden", events.length === 0);
  const ul = $("fundingList");
  ul.innerHTML = "";
  for (const f of applySort(events.map(e => ({ ...e, lastTs: e.firstT })))) {
    const li = document.createElement("li");
    // Prefer the live funding-DB / user label over the (possibly older) cached cls.
    const dbHit = labelFor(f.from);
    const kind = dbHit ? "exchange" : (f.cls?.kind || "unknown");
    const label = dbHit ? dbHit.label : (f.cls?.label || "Unclassified");
    li.innerHTML = `<div class="row-main">
        <span class="row-title"></span>
        <span class="row-sub mono"></span></div>
      <div class="row-right"><div class="row-val"></div><div class="row-val-sub"></div>
        <button class="copy-btn" title="Copy address">⧉</button></div>`;
    const nm = labels[f.from];
    const isConn = (settings.connectors || []).includes(f.from);
    li.querySelector(".row-title").textContent = nm ? `[${nm}]`
      : isConn ? "⚡ Connector (relayer)"
      : (kind === "exchange" ? label : (kind === "wallet" ? "Unlabeled wallet" : label));
    if (f.oldFundsNew) li.classList.add("old-funder-row");
    li.querySelector(".row-sub").textContent = shortAddr(f.from);
    li.querySelector(".row-sub").title = f.from;
    // Funder wallet age + old→new flag on the LEFT column, which shrinks/wraps
    // safely in the narrow side panel (the right column never shrinks).
    if (f.funderAgeSec != null) {
      const age = document.createElement("span");
      age.className = "fund-age" + (f.oldFundsNew ? " flagged" : "");
      // BACK-CHECK: who established this funder? An old hot wallet set up by
      // an exchange years ago is shown as exactly that.
      const origin = f.funderOriginLabel ? ` · established by ${f.funderOriginLabel}`
        : f.funderOriginAddr ? ` · established by ${shortAddr(f.funderOriginAddr)}` : "";
      age.textContent = (f.oldFundsNew ? "⚠ old → new · " : "") + `wallet ${fmtAge(f.funderAgeSec)} old${origin}`;
      if (f.funderOriginAddr) age.title = `First funded by ${f.funderOriginAddr}`;
      if (f.oldFundsNew) age.title = "A very old wallet funded this brand-new wallet" + (f.funderOriginAddr ? ` — that funder was itself first funded by ${f.funderOriginAddr}` : "");
      li.querySelector(".row-main").appendChild(age);
    }
    // Serial funder — REWORKED rule only: an established wallet seen repeatedly
    // sending token supply to fresh wallets with no funding and no buys. Plain
    // fan-out (payment services etc.) never triggers this any more.
    if (f.serialFunder) {
      const st = document.createElement("span");
      st.className = "serial-tag";
      st.textContent = `⟳ serial funder · supplied ${f.serialFreshUnfunded} fresh unfunded wallet${f.serialFreshUnfunded === 1 ? "" : "s"} recently`;
      st.title = "Established wallet that repeatedly sends token supply to brand-new wallets with no funding and no buys — the fresh-receiver pattern observed more than once. High send volume alone (payment services, distributors) does not trigger this. Not proof of an insider or dev link.";
      li.querySelector(".row-main").appendChild(st);
    }
    li.querySelector(".row-val").textContent = `${fmtQty(f.total)} SOL`;
    li.querySelector(".row-val-sub").textContent = `${f.count}× · first ${fmtDate(f.firstT)}`;
    li.querySelector(".copy-btn").addEventListener("click", () => {
      navigator.clipboard.writeText(f.from);
      $("statusLine").textContent = "Address copied.";
      setTimeout(() => ($("statusLine").textContent = ""), 1500);
    });
    ul.appendChild(li);
  }
}

// Addresses excluded from SUSPECT detection for a given tracked wallet:
//   • scoped ignores — flagged "not a side wallet" for THIS wallet only
//   • connectors — global relayer/connector wallets (Phantom etc.), de-highlighted everywhere
function suspectExclusions(s, addr) {
  const scoped = (s && s.ignoredScoped && s.ignoredScoped[addr]) || [];
  const conn = (s && s.connectors) || [];
  return [...scoped, ...conn];
}
function addScopedIgnoreObj(d, addr) {
  d.ignoredScoped = d.ignoredScoped || {};
  const set = new Set(d.ignoredScoped[currentAddress] || []);
  set.add(addr);
  d.ignoredScoped[currentAddress] = [...set];
}
async function addScopedIgnore(addr) {
  const d = await store.get();
  addScopedIgnoreObj(d, addr);
  await store.set({ ignoredScoped: d.ignoredScoped });
  if (lastSettings) lastSettings.ignoredScoped = d.ignoredScoped;
  return d;
}

function renderSideWallets(stats, settings = {}) {
  const labels = Object.fromEntries((settings.wallets || []).filter(w => w.name).map(w => [w.address, w.name]));
  const walletTags = settings.walletTags || {};
  const evalOpts = {
    solThresh: settings.solThresh, usdThresh: settings.usdThresh,
    buyEvents: stats.buyEvents, largeInflowTs: stats.largeInflowTs,
    ignored: suspectExclusions(settings, currentAddress), ansem: settings.ansemWallets, calib: feedbackCalibration(settings.feedback),
    priceMap: stats.priceMap, solPrice: stats.solPrice,
    labels,
  };
  const suspects = findSideWallets(stats.topCounterparties || [], evalOpts);
  const section = $("sideWalletSection");
  section.classList.toggle("hidden", suspects.length === 0);
  $("sideWalletTitle").textContent =
    `Possible side wallets — ${labels[currentAddress] ? `[${labels[currentAddress]}]` : shortAddr(currentAddress || "")} (${suspects.length})`;
  const ul = $("sideWalletList");
  ul.innerHTML = "";

  // Group headers are COLLAPSIBLE. Each header owns a numeric group id; every row
  // added after it is tagged data-grp="<id>", and the header toggles rows BY that
  // attribute — robust against sibling-traversal quirks.
  let grpSeq = 0, curGrp = -1;
  const addGroupHeader = (text) => {
    const gi = ++grpSeq; curGrp = gi;
    const li = document.createElement("li");
    li.className = "group-header collapsible";
    li.dataset.grpHead = String(gi);
    li.innerHTML = `<span class="caret">▾</span> `;
    li.appendChild(document.createTextNode(text));
    li.title = "Click to collapse / expand this group";
    li.addEventListener("click", () => {
      const collapsed = li.classList.toggle("grp-collapsed");
      li.querySelector(".caret").textContent = collapsed ? "▸" : "▾";
      ul.querySelectorAll(`[data-grp="${gi}"]`).forEach(el => el.classList.toggle("hidden", collapsed));
    });
    ul.appendChild(li);
  };
  const addSuspect = (s) => {
    const li = document.createElement("li");
    li.className = "suspect" + (s.bundleRisk ? " bundle" : "");
    if (curGrp >= 0) li.dataset.grp = String(curGrp);
    li.innerHTML = `
      <div class="suspect-head">
        <span class="row-title mono"></span>
        <span class="pill fund-pill hidden"></span>
        <span class="pill ansem-pill hidden"></span>
        <span class="pill cert-pill"></span>
        <span class="pill bundle-pill hidden"></span>
        <button class="inter-ico" title="View all interactions with this wallet">⌕</button>
        <span class="expander">▸</span>
      </div>
      <div class="row-sub headline"></div>
      <div class="mutual-tokens hidden"></div>
      <div class="suspect-details hidden">
        <ul class="evidence-list"></ul>
        <div class="bias-line hidden"></div>
        <div class="bundle-block hidden"><div class="bundle-title"></div><ul class="bundle-list"></ul></div>
        <div class="factor-line"></div>
        <div class="meta-line"></div>
        <div class="refs-block"><div class="refs-title">Addresses (full, for copying)</div><ul class="refs-list"></ul></div>
        <div class="suspect-actions">
          <button class="inter-btn">Interactions</button>
          <button class="copy-btn">Copy address</button>
          <button class="track-btn">Track &amp; name wallet</button>
          <button class="chain-btn" title="Pin to the investigation chain — highlighted on every Constellation and listed on the wallets screen">⛓ Add to chain</button>
          <button class="nonsusp-btn hidden" title="Mark this token-supply move as a normal, non-suspicious transfer — records feedback to sharpen supply-sharing precision, and hides it for this wallet">✓ Not a suspicious transfer</button>
          <button class="connector-btn" title="Mark as a connector/relayer wallet (Phantom, Fomo, etc.). It stays visible everywhere but stops being highlighted as a suspect in every wallet.">⚡ Connector wallet</button>
          <button class="ansem-btn" title="Mark as a known Ansem wallet. Leads where ≥45% of a token's supply moved with it get tagged “Ansem Derived Coin Supply Share” and their certainty damped — a recognised false-positive pattern.">◎ Ansem wallet</button>
          <button class="flag-btn" title="Flag this as an incorrect result — say what it actually is and how sure you are; records feedback and hides it for this wallet">⚑ Flag incorrect</button>
          <button class="ignore-btn" title="Not a side wallet for THIS tracked wallet only — it can still be flagged when you analyze other wallets (undo in settings)">Dismiss</button>
        </div>
      </div>`;

    const name = labels[s.addr];
    li.querySelector(".row-title").textContent = name ? `[${name}]` : shortAddr(s.addr);
    li.querySelector(".row-title").title = s.addr;
    if (name) li.querySelector(".row-title").classList.add("named");

    const certPill = li.querySelector(".cert-pill");
    certPill.textContent = `${s.certBand} ${s.certainty}%`;
    certPill.classList.add(s.certBand === "HIGH" ? "pill-high" : s.certBand === "MED" ? "pill-med" : "pill-low");
    certPill.title = "Certainty from matched factors — expand for the breakdown";

    if (s.bundleRisk) {
      const bp = li.querySelector(".bundle-pill");
      bp.classList.remove("hidden");
      bp.textContent = `BUNDLE ${s.bundleScore}%`;
      bp.classList.add("pill-critical");
    }
    if (s.ansemShare) {
      const ap = li.querySelector(".ansem-pill");
      ap.classList.remove("hidden");
      ap.textContent = "ANSEM SUPPLY ⚠";
      ap.classList.add("pill-ansem");
      ap.title = "Ansem Derived Coin Supply Share — ≥45% of this token's supply moved with a known Ansem wallet. A recognised false-positive pattern; certainty damped ×0.45.";
    }
    if (s.freshSender) {
      const fp2 = document.createElement("span");
      fp2.className = "pill pill-fresh";
      fp2.textContent = "FRESH SENDER ⚠";
      fp2.title = "Fresh, unfunded wallet whose first recorded contact was SENDING tokens/supply — burner-style distribution wallet.";
      li.querySelector(".cert-pill").parentElement.insertBefore(fp2, li.querySelector(".cert-pill"));
    }
    if (s.freshReceiver) {
      const fr = document.createElement("span");
      fr.className = "pill pill-fresh";
      fr.textContent = "FRESH RECEIVER ⚠";
      fr.title = "Fresh wallet with NO SOL funding anywhere in the window that RECEIVED tokens/supply — brand-new stash/side-wallet pattern.";
      li.querySelector(".cert-pill").parentElement.insertBefore(fr, li.querySelector(".cert-pill"));
    }
    // Funding-source badge: we could identify where this wallet's money came from.
    if (s.fundedBy) {
      const fp = li.querySelector(".fund-pill");
      fp.classList.remove("hidden");
      fp.textContent = `⬦ ${s.fundedBy}`;
      fp.classList.add("pill-fund");
      fp.title = `First funded from ${s.fundedBy}`;
    }

    li.querySelector(".headline").textContent = s.headline;

    // mutual token tickers exchanged between the two wallets
    if (s.mutualTokens && s.mutualTokens.length) {
      const mt = li.querySelector(".mutual-tokens");
      mt.classList.remove("hidden");
      mt.innerHTML = `<span class="mt-label">Tokens:</span> ` +
        s.mutualTokens.map(t => `<span class="mt-chip">${String(t).replace(/</g, "&lt;")}</span>`).join(" ");
    }

    // expanded details
    const evUl = li.querySelector(".evidence-list");
    for (const sig of s.signals) {
      const evLi = document.createElement("li");
      evLi.textContent = sig;
      evUl.appendChild(evLi);
    }
    if (s.biasTags?.length) {
      const bl = li.querySelector(".bias-line");
      bl.classList.remove("hidden");
      bl.textContent = s.biasTags.join(" · ");
    }
    if (s.bundleEvidence?.length) {
      const bb = li.querySelector(".bundle-block");
      bb.classList.remove("hidden");
      li.querySelector(".bundle-title").textContent = `Bundle evidence · ${s.bundleScore}%`;
      const bul = li.querySelector(".bundle-list");
      for (const e of s.bundleEvidence) {
        const bLi = document.createElement("li");
        bLi.textContent = e;
        bul.appendChild(bLi);
      }
    }
    li.querySelector(".factor-line").textContent =
      `Certainty ${s.certainty}% = evidence ${s.evidencePct}% × bias ×${(s.biasMult ?? 1).toFixed(2)}`;
    const refsUl = li.querySelector(".refs-list");
    for (const r of s.refs || [{ label: "suspect wallet", addr: s.addr }]) {
      const rLi = document.createElement("li");
      rLi.innerHTML = `<span class="ref-label"></span><span class="ref-addr mono"></span><button class="copy-btn" title="Copy">⧉</button>`;
      rLi.querySelector(".ref-label").textContent = r.label;
      rLi.querySelector(".ref-addr").textContent = r.addr;
      rLi.querySelector(".copy-btn").addEventListener("click", () => {
        navigator.clipboard.writeText(r.addr);
        $("statusLine").textContent = "Address copied.";
        setTimeout(() => ($("statusLine").textContent = ""), 1500);
      });
      refsUl.appendChild(rLi);
    }
    const hist = walletTags[s.addr];
    const histTxt = hist && hist.tags.length ? ` · history: ${hist.tags.join(", ")} (seen ${hist.seen}×)` : "";
    li.querySelector(".meta-line").textContent =
      `${s.count} direct transfer(s) · ${s.in} in / ${s.out} out · ${fmtDate(s.firstTs)} → ${fmtDate(s.lastTs)}` +
      (s.alsoFunding ? " · also matches high-value funding" : "") + histTxt;

    const details = li.querySelector(".suspect-details");
    const expander = li.querySelector(".expander");
    li.addEventListener("click", (e) => {
      if (e.target.closest("button")) return;
      const list = $("sideWalletList");
      // In compact mode, the FIRST click on any row lifts compact mode (so its
      // full details — and every function — are available again) rather than
      // toggling that one card's detail block.
      if (list.classList.contains("compact-mode")) {
        list.classList.remove("compact-mode");
        const cb = $("suspectCompactBtn"); if (cb) { cb.textContent = "Compact"; cb.classList.remove("active"); }
        details.classList.remove("hidden");
        expander.textContent = "▾";
        return;
      }
      const open = details.classList.toggle("hidden");
      expander.textContent = open ? "▸" : "▾";
    });
    li.querySelector(".copy-btn").addEventListener("click", () => {
      navigator.clipboard.writeText(s.addr);
      $("statusLine").textContent = "Address copied.";
      setTimeout(() => ($("statusLine").textContent = ""), 1500);
    });
    li.querySelector(".track-btn").addEventListener("click", async (e) => {
      e.stopPropagation();
      const d = await store.get();
      if (d.wallets.some(w => w.address === s.addr)) {
        $("statusLine").textContent = "Already tracked.";
        setTimeout(() => ($("statusLine").textContent = ""), 1500);
        return;
      }
      const actions = li.querySelector(".suspect-actions");
      if (actions.querySelector(".track-name-in")) return;
      const inp = document.createElement("input");
      inp.className = "track-name-in";
      inp.placeholder = "Name this wallet (optional) — Enter to save";
      const commit = async () => {
        const dd = await store.get();
        if (!dd.wallets.some(w => w.address === s.addr)) {
          dd.wallets.push({ address: s.addr, added: Date.now(), name: inp.value.trim() });
          await store.set({ wallets: dd.wallets });
          if (lastSettings) lastSettings.wallets = dd.wallets;
          renderWalletList();
        }
        $("statusLine").textContent = "Tracked" + (inp.value.trim() ? ` as [${inp.value.trim()}]` : "") + ".";
        setTimeout(() => ($("statusLine").textContent = ""), 1800);
        if (lastStats) renderSideWallets(lastStats, lastSettings || {});
      };
      inp.addEventListener("click", (ev) => ev.stopPropagation());
      inp.addEventListener("keydown", (ev) => { ev.stopPropagation(); if (ev.key === "Enter") commit(); else if (ev.key === "Escape" && lastStats) renderSideWallets(lastStats, lastSettings || {}); });
      actions.prepend(inp);
      inp.focus();
    });
    const rerenderSuspects = (d) => { if (lastStats) renderSideWallets(lastStats, { ...(lastSettings || {}), ignoredScoped: d.ignoredScoped, connectors: d.connectors, ansemWallets: d.ansemWallets, feedback: d.feedback }); };
    // Flag incorrect — capture WHAT it actually is + how sure, then hide (scoped).
    li.querySelector(".flag-btn").addEventListener("click", (e) => {
      e.stopPropagation();
      const actions = li.querySelector(".suspect-actions");
      if (actions.querySelector(".flag-form")) return;
      const form = document.createElement("div");
      form.className = "flag-form";
      form.innerHTML =
        `<input class="flag-what" placeholder="What is it really? e.g. exchange, pool, my other wallet">`
        + `<select class="flag-cert"><option value="low">Not sure</option><option value="med" selected>Fairly sure</option><option value="high">Certain</option></select>`
        + `<button class="flag-save tip-btn">Save</button>`;
      form.addEventListener("click", (ev) => ev.stopPropagation());
      form.querySelector(".flag-save").addEventListener("click", async () => {
        const what = form.querySelector(".flag-what").value.trim();
        const cert = form.querySelector(".flag-cert").value;
        const d = await store.get();
        d.feedback = d.feedback || [];
        d.feedback.push({
          addr: s.addr, on: currentAddress, ts: Date.now(), kind: "incorrect",
          certainty: s.certainty, certBand: s.certBand, group: s.group, bundleScore: s.bundleScore,
          actualLabel: what || null, userCertainty: cert,
          signals: (s.signals || []).slice(0, 5),
          factors: (s.factors || []).filter(f => f.w).map(f => f.label),
        });
        addScopedIgnoreObj(d, s.addr);
        await store.set({ feedback: d.feedback, ignoredScoped: d.ignoredScoped });
        if (lastSettings) lastSettings.ignoredScoped = d.ignoredScoped;
        $("statusLine").textContent = "Flagged as incorrect — thanks, this helps improve accuracy.";
        setTimeout(() => ($("statusLine").textContent = ""), 2600);
        rerenderSuspects(d);
      });
      actions.appendChild(form);
      form.querySelector(".flag-what").focus();
    });
    // Connector/relayer wallet (Phantom etc.) — GLOBAL de-highlight, never removed/hidden.
    li.querySelector(".connector-btn").addEventListener("click", async (e) => {
      e.stopPropagation();
      const d = await store.get();
      d.connectors = d.connectors || [];
      if (!d.connectors.includes(s.addr)) d.connectors.push(s.addr);
      // A connector mark is also a correction — record it so the certainty of the
      // remaining results in this evidence family (and the constellation) recalibrates.
      d.feedback = d.feedback || [];
      if (!d.feedback.some(f => f.addr === s.addr && f.kind === "connector")) {
        d.feedback.push({ addr: s.addr, on: currentAddress, ts: Date.now(), kind: "connector", group: s.group, certainty: s.certainty, certBand: s.certBand, signals: (s.signals || []).slice(0, 3) });
      }
      await store.set({ connectors: d.connectors, feedback: d.feedback });
      if (lastSettings) { lastSettings.connectors = d.connectors; lastSettings.feedback = d.feedback; }
      $("statusLine").textContent = "Marked as connector wallet — no longer highlighted, and similar results recalibrated.";
      setTimeout(() => ($("statusLine").textContent = ""), 2800);
      rerenderSuspects(d);
    });
    // Pin to / unpin from the investigation chain (second click removes).
    const chainBtn = li.querySelector(".chain-btn");
    if (inChain(s.addr)) chainBtn.textContent = "⛓ In chain";
    chainBtn.addEventListener("click", async (e) => {
      e.stopPropagation();
      if (inChain(s.addr)) { await removeFromChain(s.addr); chainBtn.textContent = "⛓ Add to chain"; }
      else { await addToChain(s.addr, labels[s.addr] || ""); chainBtn.textContent = "⛓ In chain"; }
    });
    // Known Ansem wallet — large supply shares to it are tagged + damped (false-positive control).
    li.querySelector(".ansem-btn").addEventListener("click", async (e) => {
      e.stopPropagation();
      const d = await store.get();
      d.ansemWallets = d.ansemWallets || [];
      if (!d.ansemWallets.includes(s.addr)) d.ansemWallets.push(s.addr);
      await store.set({ ansemWallets: d.ansemWallets });
      if (lastSettings) lastSettings.ansemWallets = d.ansemWallets;
      $("statusLine").textContent = "Marked as an Ansem wallet — large supply shares with it are now tagged and damped.";
      setTimeout(() => ($("statusLine").textContent = ""), 2800);
      rerenderSuspects(d);
    });
    // Supply-sharing: "not a suspicious transfer" (scoped) — hones supply precision.
    if (s.group === "supply") {
      const nb = li.querySelector(".nonsusp-btn");
      nb.classList.remove("hidden");
      nb.addEventListener("click", async (e) => {
        e.stopPropagation();
        const d = await store.get();
        d.feedback = d.feedback || [];
        const mints = (s.refs || []).filter(r => /mint|CA/i.test(r.label)).map(r => r.addr);
        if (!d.feedback.some(f => f.addr === s.addr && f.on === currentAddress && f.kind === "supply-ok")) {
          d.feedback.push({ addr: s.addr, on: currentAddress, ts: Date.now(), kind: "supply-ok", group: s.group, certainty: s.certainty, certBand: s.certBand, mints, signals: (s.signals || []).slice(0, 5) });
        }
        addScopedIgnoreObj(d, s.addr);
        await store.set({ feedback: d.feedback, ignoredScoped: d.ignoredScoped });
        if (lastSettings) lastSettings.ignoredScoped = d.ignoredScoped;
        $("statusLine").textContent = "Marked as non-suspicious — thanks, this sharpens supply precision.";
        setTimeout(() => ($("statusLine").textContent = ""), 2600);
        rerenderSuspects(d);
      });
    }
    li.querySelector(".inter-btn").addEventListener("click", () => openInteractions(s));
    li.querySelector(".inter-ico").addEventListener("click", (e) => { e.stopPropagation(); openInteractions(s); });
    // Dismiss = "not a side wallet for THIS wallet only" (scoped, not global).
    li.querySelector(".ignore-btn").addEventListener("click", async () => {
      const d = await addScopedIgnore(s.addr);
      $("statusLine").textContent = "Not a side wallet for this wallet — undo in settings.";
      setTimeout(() => ($("statusLine").textContent = ""), 2600);
      rerenderSuspects(d);
    });
    ul.appendChild(li);
  };

  const supplyGroup = applySort(suspects.filter(s => s.group === "supply"));
  const fundingGroup = applySort(suspects.filter(s => s.group === "funding"));
  if (supplyGroup.length) {
    addGroupHeader(`Token supply sharing · ${supplyGroup.length}`);
    supplyGroup.forEach(addSuspect);
  }
  if (fundingGroup.length) {
    addGroupHeader(`High-value transfers · ${fundingGroup.length}`);
    fundingGroup.forEach(addSuspect);
  }

  // Every other wallet interaction — low suspicion, but still visible and
  // expandable so connections are never silently hidden.
  const others = applySort(findOtherWallets(stats.topCounterparties || [], evalOpts));
  if (others.length) {
    addGroupHeader(`Other wallet interactions · ${others.length} · low suspicion`);
    others.forEach(addSuspect);
  }
  if (suspects.length === 0 && others.length === 0) {
    const li = document.createElement("li");
    li.innerHTML = `<span class="hint">No direct wallet interactions in the analyzed window.</span>`;
    ul.appendChild(li);
  }
  section.classList.toggle("hidden", suspects.length === 0 && others.length === 0);
  wireResultsSearch("suspectSearch", "sideWalletList", "suspectSearchCount", "suspectSearchClear");
  syncResultsSearch("suspectSearch", "sideWalletList", "suspectSearchWrap", "suspectSearchCount");
}


// Category assignment for the agent/interaction breakdown. Labels come from
// on-chain classification + known-address list + observed behavior.
function agentCategory(c) {
  const kind = c.cls?.kind || "unknown";
  const label = c.cls?.label || "";
  if (kind === "wallet" && c.exchangeLike) return { key: "amm", title: "Pools & market makers · behavioral" };
  if (kind === "wallet" && c.botLike) return { key: "bots", title: "Bots & fee collectors · behavioral" };
  if (kind === "wallet") return { key: "wallets", title: "Wallets" };
  if (kind === "exchange") return { key: "cex", title: "Exchanges · labeled" };
  if (/tip/i.test(label) || /fee/i.test(label)) return { key: "fees", title: "Tips & fee accounts" };
  if (/mint \(contract\)/i.test(label)) return { key: "contracts", title: "Token contracts" };
  if (/token account/i.test(label)) return { key: "tokenacct", title: "Token accounts" };
  if (/program|pda|validator|stake/i.test(label)) return { key: "programs", title: "Programs & PDAs" };
  return { key: "other", title: "Unclassified" };
}

const CATEGORY_ORDER = ["wallets", "amm", "cex", "fees", "contracts", "programs", "tokenacct", "bots", "other"];

let cpSort = "count", progSort = "count";   // count | new | old — per-section sorts
const WALLET_CATS = ["wallets", "amm", "cex", "bots"];             // "Interacted addresses"
const PROG_CATS = ["fees", "contracts", "programs", "tokenacct", "other"]; // "Programs & PDAs"
function cpCmp(sort) {
  return (a, b) => sort === "new" ? (b.lastTs || 0) - (a.lastTs || 0)
    : sort === "old" ? (a.lastTs || 0) - (b.lastTs || 0)
    : (b.count || 0) - (a.count || 0);
}
function cpRow(c, labels, walletTags, symbolMap, connectors) {
  const li = document.createElement("li");
  const kinds = [c.sol ? `${c.sol} SOL` : null, c.token ? `${c.token} token` : null].filter(Boolean).join(", ");
  const dir = `${c.in || 0} in / ${c.out || 0} out`;
  const hist = walletTags[c.addr];
  const histTxt = hist && hist.tags.length ? " · history: " + hist.tags.join(", ") : "";
  const flagTxt = ((c.flags && c.flags.length) ? " · " + c.flags.join(" · ") : "") + histTxt;
  li.innerHTML = `<div class="row-main">
      <span class="row-title mono"></span>
      <span class="row-sub sub1"></span>
      <span class="row-sub sub2"></span></div>
    <div class="row-right"><span class="badge"></span> <button class="copy-btn" title="Copy address">⧉</button></div>`;
  const nm = labels[c.addr];
  const rt = li.querySelector(".row-title");
  // If this counterparty address is a known token mint/contract, surface its $ticker.
  const ticker = symbolMap && symbolMap[c.addr];
  rt.textContent = nm ? `[${nm}]` : (ticker ? `$${ticker}` : shortAddr(c.addr));
  if (nm || ticker) rt.classList.add("named");
  rt.title = ticker ? `$${ticker} · ${c.addr}` : c.addr;
  const isConn = connectors && connectors.has(c.addr);
  li.querySelector(".sub1").textContent = (c.cls?.label || "Unclassified") + (ticker ? ` · $${ticker}` : "") + (isConn ? " · ⚡ connector" : "");
  if (isConn) li.classList.add("connector-row");
  li.querySelector(".sub2").textContent = `${kinds} · ${dir} · last ${fmtDate(c.lastTs)}${flagTxt}`;
  li.querySelector(".badge").textContent = c.count + "×";
  li.querySelector(".copy-btn").addEventListener("click", () => {
    navigator.clipboard.writeText(c.addr);
    $("statusLine").textContent = "Address copied.";
    setTimeout(() => ($("statusLine").textContent = ""), 1500);
  });
  return li;
}
function renderCpInto(listEl, cats, sort, labels, walletTags, list, symbolMap, connectors) {
  listEl.innerHTML = "";
  const groups = new Map();
  for (const c of list) {
    const cat = agentCategory(c);
    if (!cats.includes(cat.key)) continue;
    if (!groups.has(cat.key)) groups.set(cat.key, { title: cat.title, items: [] });
    groups.get(cat.key).items.push(c);
  }
  let total = 0;
  for (const key of cats) {
    const g = groups.get(key);
    if (!g) continue;
    g.items.sort(cpCmp(sort));
    const head = document.createElement("li");
    head.className = "group-header";
    head.textContent = `${g.title} (${g.items.length})`;
    listEl.appendChild(head);
    for (const c of g.items) { listEl.appendChild(cpRow(c, labels, walletTags, symbolMap, connectors)); total++; }
  }
  if (total === 0) listEl.innerHTML = `<li><span class="hint">None in the analyzed window.</span></li>`;
  return total;
}
function renderCounterparties(stats, settings = {}) {
  const labels = Object.fromEntries((settings.wallets || []).filter(w => w.name).map(w => [w.address, w.name]));
  const walletTags = settings.walletTags || {};
  const list = stats.topCounterparties || [];
  const symbolMap = stats.symbolMap || {};
  const connectors = new Set(settings.connectors || []);
  renderCpInto($("counterpartyList"), WALLET_CATS, cpSort, labels, walletTags, list, symbolMap, connectors);
  renderCpInto($("programsList"), PROG_CATS, progSort, labels, walletTags, list, symbolMap, connectors);
}

// ---------- interactions overlay ----------
function openInteractions(s) {
  const labels = Object.fromEntries(((lastSettings && lastSettings.wallets) || []).filter(w => w.name).map(w => [w.address, w.name]));
  const nameOf = (a) => labels[a] ? `[${labels[a]}]` : shortAddr(a);
  $("interTitle").textContent = `Interactions: ${nameOf(currentAddress || "")} ↔ ${nameOf(s.addr)}`;
  $("interSub").textContent = s.addr;
  $("interSub").title = s.addr;
  const ul = $("interList");
  ul.innerHTML = "";
  const events = s.interactions || [];
  if (events.length === 0) {
    ul.innerHTML = `<li><span class="hint">No recorded direct transfers (only trade/fee legs, which are filtered).</span></li>`;
  }
  for (const e of events) {
    const li = document.createElement("li");
    // Direction from the tracked wallet's perspective: out = tracked → suspect
    const arrow = e.dir === "out" ? "→ sent to them" : "← received from them";
    const what = e.kind === "sol"
      ? `${fmtQty(e.amt)} SOL`
      : `${fmtQty(e.amt)} ${e.symbol || (e.mint ? e.mint.slice(0, 4) + "…" : "token")}`;
    const curPrice = e.mint && lastStats?.priceMap?.[e.mint];
    const sp = lastStats?.solPrice;
    const value = e.kind === "sol" ? ""
      : e.estSol != null ? ` · worth ≈${fmtQty(e.estSol)} SOL at transfer`
      : curPrice != null ? ` · worth ≈$${fmtQty(e.amt * curPrice)}${sp ? ` / ${fmtQty(e.amt * curPrice / sp)} SOL` : ""} at current price`
      : "";
    const paired = e.paired ? " · ⇄ trade leg" : "";
    li.innerHTML = `<div class="row-main">
        <span class="row-title"></span>
        <span class="row-sub"></span></div>
      <div class="row-right"><span class="row-val-sub"></span></div>`;
    li.querySelector(".row-title").textContent = what;
    li.querySelector(".row-sub").textContent = `${arrow}${value}${paired}`;
    li.querySelector(".row-val-sub").textContent = new Date(e.t * 1000).toLocaleString(undefined, { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" });
    ul.appendChild(li);
  }
  $("interPanel").classList.remove("hidden");
  $("interPanel").scrollTop = 0;
}

// ---------- recent sells ----------
function sellRow(sv, symbolMap) {
  const li = document.createElement("li");
  const rawSym = symbolMap[sv.mint] || sv.symbol || "";
  const sym = rawSym || (sv.mint ? sv.mint.slice(0, 4) + "…" : "token");
  const got = sv.sol > 0 ? `${fmtQty(sv.sol)} SOL` : sv.quote > 0 ? `${fmtQty(sv.quote)} stable` : "—";
  li.innerHTML = `<div class="row-main"><span class="row-title"></span><span class="row-sub mono"></span></div>
    <div class="row-right"><div class="row-val"></div><div class="row-val-sub"></div></div>`;
  li.querySelector(".row-title").textContent = `Sold ${fmtQty(sv.amt)} ${sym}`;
  // Ticker ($SYMBOL) shown right beside the CA, when a real symbol is known.
  if (rawSym) {
    const tick = document.createElement("span");
    tick.className = "sell-tick";
    tick.textContent = `$${rawSym}`;
    li.querySelector(".row-title").appendChild(tick);
  }
  const sub = li.querySelector(".row-sub");
  sub.textContent = sv.mint || "";
  sub.title = sv.mint || "";
  if (sv.mint) {
    const cp = document.createElement("button");
    cp.className = "copy-mini"; cp.textContent = "⧉"; cp.title = "Copy CA";
    cp.addEventListener("click", (e) => {
      e.stopPropagation();
      navigator.clipboard.writeText(sv.mint);
      cp.textContent = "✓"; setTimeout(() => (cp.textContent = "⧉"), 1200);
    });
    sub.appendChild(cp);
  }
  li.querySelector(".row-val").textContent = `→ ${got}`;
  li.querySelector(".row-val-sub").textContent = sv.t ? new Date(sv.t * 1000).toLocaleString(undefined, { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" }) : "";
  return li;
}
function renderSells(stats) {
  const sells = stats.sellEvents || [];
  $("sellsSection").classList.toggle("hidden", sells.length === 0);
  const ul = $("sellsList");
  ul.innerHTML = "";
  const symbolMap = stats.symbolMap || {};
  for (const sv of sells.slice(0, 30)) ul.appendChild(sellRow(sv, symbolMap));
  $("loadMoreSellsBtn").textContent = sells.length > 30
    ? `Load more sells… (showing 30 of ${sells.length} in window)`
    : "Load more sells…";
}

// Recent outbound SOL / stablecoin transfers, split by destination wallet age.
function renderSolOut(stats, settings = {}) {
  const el = $("solOutSection");
  if (!el) return;
  const out = stats.solStableOut || [];
  el.classList.toggle("hidden", out.length === 0);
  if (!out.length) return;
  const labels = Object.fromEntries((settings.wallets || []).filter(w => w.name).map(w => [w.address, w.name]));
  const ages = stats.destAges || {};
  const FRESH = 30 * 86400, AGED = 180 * 86400;
  const ul = $("solOutList");
  ul.innerHTML = "";
  const cls = (addr) => {
    const a = ages[addr];
    if (a == null) return "unknown";
    return a <= FRESH ? "fresh" : a >= AGED ? "aged" : "mid";
  };
  const buckets = {
    fresh: { title: "To fresh wallets (≤ 30d)", rows: [] },
    aged: { title: "To aged wallets (≥ 6mo)", rows: [] },
    mid: { title: "To other wallets", rows: [] },
    unknown: { title: "Age not resolved", rows: [] },
  };
  for (const o of out.slice(0, 40)) buckets[cls(o.to)].rows.push(o);
  let gseq = 0;
  const header = (title, n) => {
    const gi = ++gseq;
    const li = document.createElement("li");
    li.className = "group-header collapsible";
    li.innerHTML = `<span class="caret">▾</span> `;
    li.appendChild(document.createTextNode(`${title} · ${n}`));
    li.addEventListener("click", () => {
      const c = li.classList.toggle("grp-collapsed");
      li.querySelector(".caret").textContent = c ? "▸" : "▾";
      ul.querySelectorAll(`[data-sg="${gi}"]`).forEach(x => x.classList.toggle("hidden", c));
    });
    ul.appendChild(li);
    return gi;
  };
  for (const key of ["fresh", "aged", "mid", "unknown"]) {
    const b = buckets[key];
    if (!b.rows.length) continue;
    const gi = header(b.title, b.rows.length);
    for (const o of b.rows) {
      const li = document.createElement("li");
      li.dataset.sg = String(gi);
      const nm = labels[o.to] ? `[${escHtml(labels[o.to])}]` : shortAddr(o.to);
      const amtTxt = o.asset === "SOL" ? `${fmtQty(o.amt)} SOL` : `${fmtQty(o.amt)} ${(stats.symbolMap && stats.symbolMap[o.mint]) || "stable"}`;
      const ageTxt = ages[o.to] != null ? `${fmtAge(ages[o.to])} old` : "age n/a";
      li.innerHTML = `<div class="row-main"><span class="row-title"></span><span class="row-sub mono"></span></div>`
        + `<div class="row-right"><div class="row-val"></div><div class="row-val-sub"></div>`
        + `<button class="copy-mini" title="Copy address">⧉</button></div>`;
      li.querySelector(".row-title").textContent = `→ ${amtTxt}`;
      const sub = li.querySelector(".row-sub");
      sub.textContent = `${nm} · ${ageTxt}`;
      sub.title = o.to;
      li.querySelector(".row-val").textContent = fmtDate(o.t);
      li.querySelector(".copy-mini").addEventListener("click", (e) => {
        e.stopPropagation();
        navigator.clipboard.writeText(o.to);
        e.target.textContent = "✓"; setTimeout(() => (e.target.textContent = "⧉"), 1200);
      });
      ul.appendChild(li);
    }
  }
}

let sellsPanelState = null; // { sells:[], oldestSig }
function openSellsPanel() {
  if (!lastStats) return;
  const nm = (lastSettings?.wallets || []).find(w => w.address === currentAddress)?.name;
  $("sellsPanelSub").textContent = nm ? `[${nm}] · ${shortAddr(currentAddress || "")}` : (currentAddress || "");
  sellsPanelState = { sells: [...(lastStats.sellEvents || [])], oldestSig: lastStats.oldestSig || null };
  renderSellsPanel();
  $("sellsPanel").classList.remove("hidden");
  $("sellsPanel").scrollTop = 0;
}
function renderSellsPanel() {
  const ul = $("sellsPanelList");
  ul.innerHTML = "";
  const symbolMap = (lastStats && lastStats.symbolMap) || {};
  if (!sellsPanelState.sells.length) ul.innerHTML = `<li><span class="hint">No sells found in the analyzed window.</span></li>`;
  for (const sv of sellsPanelState.sells) ul.appendChild(sellRow(sv, symbolMap));
  $("sellsPanelStatus").textContent = `${sellsPanelState.sells.length} sells`;
  $("loadOlderSellsBtn").classList.toggle("hidden", !sellsPanelState.oldestSig);
}
async function loadOlderSells() {
  if (!sellsPanelState || !sellsPanelState.oldestSig) return;
  const d = await store.get();
  if (!d.apiKey) { $("sellsPanelStatus").textContent = "No API key set."; return; }
  $("loadOlderSellsBtn").disabled = true;
  $("sellsPanelStatus").textContent = "Paging older history…";
  try {
    const url = `https://api.helius.xyz/v0/addresses/${currentAddress}/transactions?api-key=${d.apiKey}&limit=100&before=${sellsPanelState.oldestSig}`;
    const res = await fetch(url);
    const txs = res.ok ? await res.json() : [];
    if (!Array.isArray(txs) || txs.length === 0) {
      sellsPanelState.oldestSig = null;
      $("sellsPanelStatus").textContent = "Reached the end of available history.";
      renderSellsPanel();
      return;
    }
    const asc = [...txs].sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
    const found = [];
    for (const tx of asc) { const sv = sellFromTx(tx, currentAddress); if (sv) found.push(sv); }
    found.reverse(); // newest of this older batch first
    sellsPanelState.sells.push(...found);
    sellsPanelState.oldestSig = asc[0]?.signature || null;
    renderSellsPanel();
    $("sellsPanelStatus").textContent = `+${found.length} older sell(s) · ${sellsPanelState.sells.length} total`;
  } catch (e) {
    $("sellsPanelStatus").textContent = "Error: " + (e && e.message ? e.message : String(e));
  } finally {
    $("loadOlderSellsBtn").disabled = false;
  }
}

// ---------- connection bubble map ----------
let MAP_W = 760, MAP_H = 580;   // dynamic — grown by openBubbleMap for busy maps
let mapShowInfra = false;        // toggle: aggregate infrastructure as cluster nodes
let mapLowConfThresh = 0;        // hide connections below this certainty % (0 = show all)
// Constellation colour palettes — four combinations, selectable on the map and
// persisted. v5.7.4.w rework: the two encoding channels are now SEPARATED —
// node-group hues and line-direction hues no longer share colours (previously
// e.g. Arctic drew inflow lines in the wallet colour and outflow in the funding
// colour, so lines impersonated node categories).
// LINES are identical across all four palettes (learnability: a line always
// means the same thing) and follow a diverging structure, because direction is
// a polarity: cool pole = inflow teal, warm pole = outflow gold, and a muted
// steel MIDPOINT for two-way (neutral on purpose, like a diverging midpoint);
// peer links between other wallets get a reserved rose that matches nothing else.
// NODES keep each palette's mood but hold the same semantics everywhere:
// side leads = hot orange, bundle-prone = rose red, funding = violet, ordinary
// wallets = the palette's body hue, infra/exchange/cluster = quiet neutrals.
// Every combination was machine-checked (Machado-2009 CVD simulation, OKLCH):
// same-mark pairs (circle↔circle, line↔line) ≥ ΔE 12 under protan/deutan/tritan,
// cross-mark pairs ≥ 8 (mark shape is the secondary encoding), all key colours
// ≥ 3:1 contrast on the map background. Slate's silver/steel and the two-way
// line are deliberate low-chroma neutrals (labels + certainty numerals carry
// identity there). Colours are intentionally luminous for the near-black
// starfield surface.
// Every palette also carries its own BACKGROUND depth (bg gradient stops +
// star tint + a faint nebula accent) so the whole map, not just the marks,
// matches the chosen scheme.
// Every palette shares ONE highlight colour (electric magenta, via CHAIN_HL) for
// the investigation chain — the per-palette `chain` field is kept in sync so any
// legacy reader stays on-brand.
const MAP_LINES = { dirIn: "#26e0b0", dirOut: "#ffb340", dirBoth: "#5d6d88", peer: "#ff77b9" };
// v5.7.5.a: FOUR palettes (Lagoon and Trench removed), and the node sets are
// now genuinely different from one another — each palette assigns DIFFERENT
// hues to the same roles, so switching schemes visibly recolours the nodes,
// not just the water:
//   hubs:    cyan → pale orchid → aqua → void white
//   leads:   spring green → dark lime → sky → ice cyan
//   bundles: bright purple → deep violet → LIME → purple
//   wallets: deep teal → moonlit lavender → royal blue → steel
// Nodes stay COOL SPECTRUM ONLY (no yellow/orange/red in any node fill) —
// warm hues exist only on lines (outflow gold, peer rose). Every set is
// machine-checked against ITS OWN background: CVD same-mark pairs ≥ ΔE 12,
// cross-mark ≥ 8, chroma ≥ 0.1, ≥ 3:1 contrast (Ghost's void-white/steel and
// Midnight's lavender wallets are deliberate low-chroma tiers — labels and
// certainty numerals carry identity there). Storage keys arctic/slate are
// legacy; removed keys (sunset/solana) fall back to Abyss automatically.
const MAP_PALETTES = {
  arctic: { label: "Abyss",    // cyan hub · light-aqua leads · purple bundles · deep ocean blue
    groups: { self: "#35e6ff", side: "#7dffd8", bundle: "#b83bff", funding: "#5a4bd4", wallet: "#2d9e8f", agent: "#647c92", exchange: "#9ec9dd", other: "#647c92", cluster: "#465866" },
    ...MAP_LINES, chain: "#ff2bd6",
    bg: ["#071120", "#02060e"], star: "#aee6ff", nebula: "#1a5a9e" },
  midnight: { label: "Midnight", // orchid hub · aqua leads · violet bundles · lavender wallets
    groups: { self: "#f09aff", side: "#3dffc8", bundle: "#8a3af0", funding: "#1f8a70", wallet: "#9890c8", agent: "#6f7a9e", exchange: "#b8c2e8", other: "#6f7a9e", cluster: "#4a5570" },
    ...MAP_LINES, dirIn: "#2fd8e0",   // cyan-shifted so inflow clears the aqua leads
    chain: "#ff2bd6",
    bg: ["#150f2e", "#070313"], star: "#cabfff", nebula: "#4a2ba8" },
  siren: { label: "Siren",     // aqua hub · sky leads · orchid bundles · royal wallets
    groups: { self: "#2dffc4", side: "#45c8ff", bundle: "#d24dff", funding: "#1f8a70", wallet: "#4d6ad0", agent: "#8a7a8a", exchange: "#d0b8cc", other: "#8a7a8a", cluster: "#665262" },
    ...MAP_LINES, chain: "#ff2bd6",
    bg: ["#1f0e1e", "#0a040a"], star: "#ffc9ec", nebula: "#8a2b6e" },
  slate: { label: "Ghost",     // TRUE monochrome: white hub, a gray ladder for the
    // ordinary tiers (light-gray funding, mid-gray wallets, dark-gray infra),
    // and exactly TWO accents where they matter — ice-cyan side leads and
    // purple bundles. The gray tiers are deliberate low-chroma roles; labels
    // and certainty numerals carry identity there.
    groups: { self: "#f0f6ff", side: "#5cd5ff", bundle: "#b048ff", funding: "#8b98a8", wallet: "#5f6a77", agent: "#4d5966", exchange: "#c4d2de", other: "#4d5966", cluster: "#46505d" },
    ...MAP_LINES, chain: "#ff2bd6",
    bg: ["#131722", "#06080d"], star: "#dcecff", nebula: "#333d4d" },
};
let mapPaletteName = "arctic";
let GROUP_COLOR = { ...MAP_PALETTES.arctic.groups };
let DIR_IN = MAP_PALETTES.arctic.dirIn;
let DIR_OUT = MAP_PALETTES.arctic.dirOut;
let DIR_BOTH = MAP_PALETTES.arctic.dirBoth;
let PEER_COLOR = MAP_PALETTES.arctic.peer;
let CHAIN_COLOR = MAP_PALETTES.arctic.chain;   // legacy per-palette value (no longer used by the highlight)
let MAP_BG = MAP_PALETTES.arctic.bg;           // background gradient stops [centre, edge]
let MAP_STAR = MAP_PALETTES.arctic.star;       // starfield tint
let MAP_NEBULA = MAP_PALETTES.arctic.nebula;   // faint background nebula accent
const CHAIN_HL = "#ff2bd6";                    // investigation-chain highlight — bold ELECTRIC MAGENTA; pops hard on every palette, no weak yellows/oranges
function applyMapPalette(name) {
  if (name === "mono") name = "slate";                 // legacy stored value
  const p = MAP_PALETTES[name] || MAP_PALETTES.arctic;
  mapPaletteName = MAP_PALETTES[name] ? name : "arctic";
  GROUP_COLOR = { ...p.groups };
  DIR_IN = p.dirIn; DIR_OUT = p.dirOut; DIR_BOTH = p.dirBoth; PEER_COLOR = p.peer;
  CHAIN_COLOR = p.chain || "#ffdf57";
  MAP_BG = p.bg || ["#0c1016", "#050506"];
  MAP_STAR = p.star || "#cfe0ff";
  MAP_NEBULA = p.nebula || "#1f4f96";
}
const GROUP_LABEL = {
  self: "Tracked wallet", side: "Side-wallet lead", bundle: "Bundle-prone",
  funding: "Funding-related", wallet: "Wallet", agent: "Program / pool / bot", exchange: "Exchange",
  cluster: "Infrastructure group",
};
// Connection colours encode DIRECTION of flow relative to the tracked wallet —
// the actual values come from the active palette (applyMapPalette above).
function edgeDir(net) {
  return net < -0.15 ? { col: DIR_IN, flow: -1 } : net > 0.15 ? { col: DIR_OUT, flow: 1 } : { col: DIR_BOTH, flow: 0 };
}
// Shift a #rrggbb toward white (amt>0) or black (amt<0) — for solid bubble depth.
function lighten(hex, amt) {
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex);
  if (!m) return hex;
  const mix = (h) => {
    const v = parseInt(h, 16);
    const nv = amt >= 0 ? v + (255 - v) * amt : v * (1 + amt);
    return Math.max(0, Math.min(255, Math.round(nv))).toString(16).padStart(2, "0");
  };
  return `#${mix(m[1])}${mix(m[2])}${mix(m[3])}`;
}

function buildMapData(stats, settings) {
  const labels = Object.fromEntries((settings.wallets || []).filter(w => w.name).map(w => [w.address, w.name]));
  const scopedIgn = suspectExclusions(settings, currentAddress);
  const evalOpts = {
    solThresh: settings.solThresh, usdThresh: settings.usdThresh,
    buyEvents: stats.buyEvents, largeInflowTs: stats.largeInflowTs,
    ignored: scopedIgn, ansem: settings.ansemWallets, calib: feedbackCalibration(settings.feedback),
    priceMap: stats.priceMap, solPrice: stats.solPrice, labels,
  };
  const ignored = new Set(scopedIgn);
  const evalById = {};
  for (const c of stats.topCounterparties || []) {
    if (c.cls?.kind === "wallet" && !c.botLike && !c.exchangeLike && !ignored.has(c.addr)) {
      evalById[c.addr] = evaluateWallet(c, evalOpts);
    }
  }

  const groupOf = (c) => {
    const s = evalById[c.addr];
    if (s && s.qualifies) {
      if (s.bundleRisk) return "bundle";
      return s.group === "supply" ? "side" : "funding";
    }
    const k = c.cls?.kind;
    if (k === "exchange") return "exchange";
    if (k === "agent") return "agent";
    if (c.exchangeLike || c.botLike) return "agent";
    return "wallet";
  };

  // Center = the tracked wallet, ALWAYS shown by its label (or short address).
  const nodes = [{ id: currentAddress, self: true, group: "self", label: labels[currentAddress] || shortAddr(currentAddress || ""), named: !!labels[currentAddress], certainty: null, weight: 0, count: 0 }];
  const links = [];
  const cps = (stats.topCounterparties || []).slice();
  // Wallet counterparties + labeled exchanges become individual nodes (sized by
  // certainty). Infrastructure (bots, pools, programs, token accounts) is set
  // aside — optionally shown as aggregated CLUSTER nodes (≤25 members each).
  const candidates = [];
  const infra = [];
  for (const c of cps) {
    const s = evalById[c.addr];
    if (s) {
      candidates.push({ c, s, cert: s.certainty || 0, group: groupOf(c) });
    } else if (c.cls?.kind === "exchange") {
      candidates.push({ c, s: null, cert: null, group: "exchange" });
    } else {
      infra.push(c); // bots, pools, programs, token accounts, unclassified
    }
  }
  candidates.sort((a, b) => (b.cert ?? 55) - (a.cert ?? 55) || (b.c.count || 0) - (a.c.count || 0));
  // The layout ALWAYS includes every candidate — the low-confidence % filter is
  // applied later at render time so that hiding weak connections never re-seeds
  // positions (keeps the arrangement, just hides nodes).
  const shown = candidates.slice(0, 40);
  const overflow = candidates.slice(40).map(x => x.c);   // beyond the 40 cap
  for (const { c, s, group } of shown) {
    nodes.push({
      id: c.addr, group, label: labels[c.addr] || shortAddr(c.addr),
      named: !!labels[c.addr], count: c.count || 1,
      certainty: s ? s.certainty : null, bundleScore: s ? s.bundleScore : null, bundleRisk: s ? s.bundleRisk : false,
      inN: c.in || 0, outN: c.out || 0, clsLabel: (labelFor(c.addr)?.label) || c.cls?.label || "",
      topSig: s ? ((s.signals && s.signals[0]) || "") : "",
    });
    links.push({ source: currentAddress, target: c.addr, w: c.count || 1, group });
  }

  const minor = [...infra, ...overflow];
  let hidden = minor.length;
  // Cluster nodes are ALWAYS built and laid out (into empty gaps, see layoutMap), so
  // the Show/Hide infrastructure toggle can add/remove them at RENDER time without
  // re-seeding positions. Whether they're actually drawn is decided in rerenderMap.
  if (minor.length) {
    // Group by category, then chunk each category into cluster nodes of ≤25.
    const byCat = new Map();
    for (const c of minor) {
      const cat = agentCategory(c);
      if (!byCat.has(cat.key)) byCat.set(cat.key, { title: cat.title, members: [] });
      byCat.get(cat.key).members.push(c);
    }
    hidden = 0;
    for (const [key, g] of byCat) {
      g.members.sort((a, b) => (b.count || 0) - (a.count || 0));
      for (let i = 0; i < g.members.length; i += 25) {
        const chunk = g.members.slice(i, i + 25);
        const totalTx = chunk.reduce((a, m) => a + (m.count || 1), 0);
        const parts = byCat.get(key).members.length > 25 ? ` ${Math.floor(i / 25) + 1}` : "";
        const id = `cluster:${key}:${i}`;
        nodes.push({
          id, cluster: true, group: "cluster",
          label: `${g.title}${parts}`, clusterCat: g.title, count: chunk.length, totalTx,
          members: chunk.map(m => ({ addr: m.addr, label: m.cls?.label || "", n: m.count || 1 })),
          certainty: null, named: false,
        });
        links.push({ source: currentAddress, target: id, w: Math.max(1, Math.round(totalTx / chunk.length)), group: "cluster" });
      }
    }
  }
  // Inter-wallet ("peer") edges: counterparties that also transacted directly
  // with each other. Drawn only when BOTH endpoints are shown as nodes.
  const shownIds = new Set(nodes.map(n => n.id));
  const seenPeer = new Set();
  let peerCount = 0;
  for (const e of (stats.walletEdges || [])) {
    if (!shownIds.has(e.a) || !shownIds.has(e.b)) continue;
    const k = e.a < e.b ? e.a + "|" + e.b : e.b + "|" + e.a;
    if (seenPeer.has(k)) continue;
    seenPeer.add(k);
    links.push({ source: e.a, target: e.b, w: e.w || 1, group: "peer", peer: true, ab: e.ab || 0, ba: e.ba || 0 });
    peerCount++;
  }
  return { nodes, links, hidden, infraTotal: minor.length, peerCount };
}

// Deterministic hash → [0,1), used for organic (noise-like) seeding.
function hash01(str, salt) {
  let h = 2166136261 ^ salt;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  h ^= h >>> 15; h = Math.imul(h, 2246822507); h ^= h >>> 13;
  return ((h >>> 0) % 100000) / 100000;
}

// Organic force layout — noise-seeded positions, repulsion, and a soft,
// per-node-varied pull toward the hub so it disperses like scattered growth
// rather than concentric rings. Center is pinned; nodes are draggable after.
// Node sizing shared by BOTH layouts (wallet map + launch map). Sizes are
// deliberately NOT proportional to certainty — low-% nodes stay comfortably
// clickable/readable; high-% nodes still read as bigger.
function mapRadiusFor(n) {
  if (n.self) return 28;
  if (n.cluster) return 15 + Math.min(20, Math.sqrt(n.count || 1) * 4);   // clusters sized by members
  // CA launch buyers: SIZE ENCODES HOW HARD THEY APED IN. n.mag (0…1) is the
  // wallet's buy magnitude; a whale is a big bubble, a dust buy is small. A
  // small lift for flagged wallets lets a risky whale pop the most.
  if (n.mag != null) {
    const m = Math.max(0, Math.min(1, n.mag));
    const certLift = n.certainty != null ? n.certainty / 100 : 0.15;
    // Skewed curve: only the true apers read BIG, the long tail stays small — so
    // the eye separates "the whales" from "everyone else" at a glance.
    const base = 11 + 31 * Math.pow(m, 1.4) + 3 * certLift;   // ~11 (dust) … ~45 (whale): bigger, clearer
    return base * (0.96 + hash01(n.id, 53) * 0.08);
  }
  const cert = n.certainty;
  let base;
  if (cert == null) base = 14;                          // exchanges/funding sources
  else if (cert < 60) base = 10 + 8 * (cert / 60);      // 10…18 — small but never tiny
  else base = 18 + 16 * Math.pow((cert - 60) / 40, 0.8);// 18…34 — prominent
  // Deterministic per-wallet jitter so equal-confidence spheres aren't identical
  // (narrow band, so the floor above actually holds).
  return base * (0.9 + hash01(n.id, 53) * 0.25);        // ×0.90 … ×1.15
}

function layoutMap(nodes, links) {
  // ---- CLEAN RADIAL LAYOUT (v5.7.4.j rework) ----
  // One coherent scheme, no fighting subsystems: the tracked wallet sits near
  // centre; every counterparty gets a UNIQUE, evenly-spaced angular slot so
  // spokes never bunch and no wedge is left empty; RADIUS encodes certainty
  // (low % near the hub, high % out where labels have room); peer-connected
  // wallets are ordered ADJACENT so the "between other wallets" chords stay
  // short instead of slashing across the canvas. Straight spokes, tidy rings.
  const cx = MAP_W / 2, cy = MAP_H / 2, minDim = Math.min(MAP_W, MAP_H);
  for (const n of nodes) n.r = mapRadiusFor(n);
  const self = nodes.find(n => n.self);
  const reals = nodes.filter(n => !n.self && !n.cluster);
  const clusters = nodes.filter(n => n.cluster);
  const N = reals.length || 1;
  const netOf = (n) => { const i = n.inN || 0, o = n.outN || 0, t = i + o; return t ? (o - i) / t : 0; };
  for (const n of reals) n.net = netOf(n);
  const confOf = (n) => (n.certainty != null ? n.certainty : 55);   // exchanges ~55
  // "Redraw" salts the seed so each attempt is a fresh variation (salt 0 = the
  // canonical arrangement, unchanged from before this feature).
  const seedId = mapLayoutSalt ? self.id + "|" + mapLayoutSalt : self.id;

  // Hub near centre with a small per-wallet offset — organic, never lopsided.
  const ha = hash01(seedId, 3) * Math.PI * 2;
  self.x = cx + Math.cos(ha) * minDim * 0.05;
  self.y = cy + Math.sin(ha) * minDim * 0.05;
  self.viaX = undefined; self.viaY = undefined;

  // --- angular ORDER: keep peer-linked wallets together (short chords) and
  // colours contiguous. Build peer components, then order components by group. ---
  const idSet = new Set(reals.map(n => n.id));
  const adj = {};
  for (const l of links) if (l.peer && idSet.has(l.source) && idSet.has(l.target)) {
    (adj[l.source] = adj[l.source] || []).push(l.target);
    (adj[l.target] = adj[l.target] || []).push(l.source);
  }
  const byId = Object.fromEntries(reals.map(n => [n.id, n]));
  const GORDER = { side: 0, bundle: 1, funding: 2, wallet: 3, exchange: 4, agent: 5, other: 6 };
  const go = (n) => GORDER[n.group] ?? 8;
  const seen = new Set(), comps = [];
  for (const n of reals) {
    if (seen.has(n.id)) continue;
    const stack = [n.id], comp = []; seen.add(n.id);
    while (stack.length) { const id = stack.pop(); comp.push(byId[id]); for (const m of (adj[id] || [])) if (!seen.has(m)) { seen.add(m); stack.push(m); } }
    comp.sort((a, b) => go(a) - go(b) || confOf(b) - confOf(a));
    comps.push(comp);
  }
  comps.sort((a, b) => (Math.min(...a.map(go)) - Math.min(...b.map(go))) || (b.length - a.length));
  const order = [];
  for (const comp of comps) order.push(...comp);

  // --- even angular slots + certainty radius (elliptical to fill wide canvas) ---
  // CLEAN radial burst — distance is the certainty value. Labels still need some
  // radial separation on busy maps, so each node gets one of 4 radial bands, but
  // the band is chosen by a HASH of the node id — NOT by its angular index — so
  // there's no index↔angle correlation and therefore no spiral pattern. Straight
  // spokes, no elbows.
  const phase = hash01(seedId, 17) * Math.PI * 2;
  const ex = Math.min(1.25, MAP_W / MAP_H);
  const rInner = minDim * (0.13 + Math.min(0.05, N * 0.001));
  const rSpan = minDim * 0.30;
  const bandGap = minDim * (N > 30 ? 0.045 : N > 16 ? 0.035 : 0.022);
  const BANDS = [-1.5, -0.5, 0.5, 1.5];
  order.forEach((n, i) => {
    const ang = phase + (i / order.length) * Math.PI * 2;
    const certN = Math.pow(Math.max(0, Math.min(100, confOf(n))) / 100, 0.85);
    const band = BANDS[Math.floor(hash01(n.id, 91 + mapLayoutSalt) * 4) % 4];
    const r = rInner + certN * rSpan + band * bandGap;
    n.x = self.x + Math.cos(ang) * r * ex;
    n.y = self.y + Math.sin(ang) * r;
    n.ang = ang;
    n.viaX = undefined; n.viaY = undefined;
  });

  // --- light de-overlap (hub pinned) ---
  const m = 12;
  for (let it = 0; it < 70; it++) {
    for (let a = 0; a < reals.length; a++) for (let b = a + 1; b < reals.length; b++) {
      const p = reals[a], q = reals[b];
      let dx = q.x - p.x, dy = q.y - p.y; const d = Math.hypot(dx, dy) || 0.01;
      const need = p.r + q.r + 16;
      if (d < need) { const push = (need - d) / 2 / d; p.x -= dx * push; p.y -= dy * push; q.x += dx * push; q.y += dy * push; }
    }
    for (const p of reals) { let dx = p.x - self.x, dy = p.y - self.y; const d = Math.hypot(dx, dy) || 0.01; const need = p.r + self.r + 28; if (d < need) { p.x += dx / d * (need - d); p.y += dy / d * (need - d); } }
    for (const p of reals) { p.x = Math.max(m + p.r, Math.min(MAP_W - m - p.r, p.x)); p.y = Math.max(m + p.r, Math.min(MAP_H - m - p.r, p.y)); }
  }

  // --- infrastructure clusters into the emptiest gaps (reserved, so toggling
  // them never disturbs the real layout) ---
  if (clusters.length) {
    const GX = 6, GY = 5, cells = [];
    for (let gy = 0; gy < GY; gy++) for (let gx = 0; gx < GX; gx++) {
      const px = (gx + 0.5) / GX * MAP_W, py = (gy + 0.5) / GY * MAP_H;
      let nearest = 1e9;
      for (const n of [self, ...reals]) { const dd = Math.hypot(n.x - px, n.y - py) - n.r; if (dd < nearest) nearest = dd; }
      cells.push({ px, py, score: nearest });
    }
    cells.sort((a, b) => b.score - a.score);
    clusters.forEach((n, i) => { const c = cells[Math.min(i, cells.length - 1)]; n.x = c.px; n.y = c.py; n.viaX = undefined; n.viaY = undefined; });
    for (let it = 0; it < 90; it++) for (const p of clusters) for (const q of nodes) {
      if (q === p) continue;
      let dx = p.x - q.x, dy = p.y - q.y; const d = Math.hypot(dx, dy) || 0.01;
      const need = p.r + q.r + 16;
      if (d < need) { const push = (need - d) * 0.5; p.x += dx / d * push; p.y += dy / d * push; }
    }
  }

  for (const n of nodes) {
    if (n.self) continue;
    n.x = Math.max(n.r + 8, Math.min(MAP_W - n.r - 8, n.x));
    n.y = Math.max(n.r + 8, Math.min(MAP_H - n.r - 8, n.y));
  }
}

// LAUNCH-MAP LAYOUT — a magnitude gravity well, purpose-built for CA maps.
// Launch data is a hierarchy (CA → early buyers → funding sources). Two axes,
// each one thing the eye reads instantly:
//   • SIZE + PROXIMITY = how hard a wallet aped in. Buyers are RANK-normalised by
//     buy magnitude (rank, NOT the raw ratio — so one whale can't flatten every
//     other bubble to the same size, the bug that made them look identical). The
//     biggest buyers are BIG bubbles packed into a TIGHT CORE hugging the token;
//     the small buys are small bubbles that spread out loosely on the rim.
//   • ANGLE = funding group. Each funder's buyers share a wedge, so the funder
//     sits beside them and its lines never rake across the map.
// The pack is settled by a WEIGHTED 2D separation: when two bubbles touch, the
// bigger one barely yields and the smaller one gives way, so whales stay central
// and the tail is pushed outward — guaranteeing the hierarchy AND zero overlaps.
function layoutCaMap(nodes, links) {
  const cx = MAP_W / 2, cy = MAP_H / 2, minDim = Math.min(MAP_W, MAP_H);
  const self = nodes.find(n => n.self);
  const buyers = nodes.filter(n => !n.self && n.group !== "funding");
  const funders = nodes.filter(n => n.group === "funding");
  const N = buyers.length || 1;

  // ---- MAGNITUDE: RANK-normalised, so it can NEVER collapse ----
  const rawOf = {};
  for (const l of links) if (!l.peer && l.target) rawOf[l.target] = Math.max(rawOf[l.target] || 0, l.w || 1);
  const rankedRaw = buyers.map(b => ({ b, raw: b.magRaw != null ? b.magRaw : (rawOf[b.id] || 1) }))
    .sort((a, z) => (z.raw - a.raw) || (hash01(a.b.id, 5) - hash01(z.b.id, 5)));
  const rankOf = new Map();
  rankedRaw.forEach((o, i) => { o.b.mag = N > 1 ? 1 - i / (N - 1) : 1; rankOf.set(o.b.id, i); });
  for (const n of nodes) n.r = mapRadiusFor(n);       // size AFTER magnitude is known
  // Direction colour needs n.net just like the wallet layout computes it —
  // without this every CA spoke fell back to the two-way colour and lost its
  // chevron (buyers carry inN:0/outN:1 = token flowed CA → buyer).
  for (const n of nodes) if (!n.self) { const i = n.inN || 0, o = n.outN || 0, t = i + o; n.net = t ? (o - i) / t : 0; }

  self.x = cx; self.y = cy;                            // hub dead centre
  const seedId = mapLayoutSalt ? self.id + "|" + mapLayoutSalt : self.id;
  const phase = hash01(seedId, 17) * Math.PI * 2;

  // funder → kids / kid → funder, for the angular grouping and funder placement
  const kidsOf = {};
  for (const l of links) if (l.peer) (kidsOf[l.source] = kidsOf[l.source] || []).push(l.target);
  const funderOf = {};
  for (const [f, ks] of Object.entries(kidsOf)) for (const k of ks) funderOf[k] = f;

  // ---- ANGLE + RADIUS together: one RADIAL SPOKE per funder. Every buyer a
  // funder seeded shares ONE direction AND stacks OUTWARD along it (biggest
  // nearest the token), so its funder sits at the far end of a single STRAIGHT
  // line — no fan, no angles. Bundle groups get their own spoke; each solo buyer
  // is a one-bubble spoke at its own magnitude radius. Spoke directions use the
  // golden angle so they spread evenly and never bunch to one side. ----
  const solo = [];
  const groupsMap = new Map();
  for (const b of buyers) {
    const key = funderOf[b.id] || (b.bKey ? "bundle:" + b.bKey : null);
    if (!key) solo.push(b);
    else { if (!groupsMap.has(key)) groupsMap.set(key, []); groupsMap.get(key).push(b); }
  }
  let spokes = [
    ...[...groupsMap.values()].sort((a, b) => b.length - a.length),   // funder/bundle networks, biggest first
    ...solo.map(b => [b]),                                            // each solo buyer = its own tiny spoke
  ];
  // "Redraw" doesn't just rotate — it RE-ASSIGNS which direction each group points,
  // so networks genuinely land in new places. Salt 0 = canonical (biggest-first);
  // any other salt reshuffles the spoke order deterministically.
  if (mapLayoutSalt) {
    spokes = spokes
      .map(m => ({ m, key: hash01((m[0] && m[0].id) || "s", 131 + mapLayoutSalt * 7) }))
      .sort((a, b) => a.key - b.key)
      .map(o => o.m);
  }
  const GA = Math.PI * (3 - Math.sqrt(5));      // golden angle → evenly spread spoke directions
  const biggestR = Math.max(14, ...buyers.map(b => b.r));
  const coreR = self.r + biggestR * 0.7 + minDim * 0.012;
  const outerR = minDim * 0.53;                             // fill more of the canvas — less empty space
  const span = Math.max(minDim * 0.24, outerR - coreR);
  const rankFracOf = (b) => N > 1 ? (rankOf.get(b.id) || 0) / (N - 1) : 0;
  const seq = [];
  spokes.forEach((members, k) => {
    const ang = phase + k * GA;                 // this spoke's single radial direction
    members.sort((a, b) => (rankOf.get(a.id) || 0) - (rankOf.get(b.id) || 0));   // biggest (lowest rank) innermost
    let rr = coreR + span * Math.pow(rankFracOf(members[0]), 1.5);               // spoke starts at its biggest buyer's radius
    members.forEach((b, j) => {
      b._ta = ang;                              // all mates share the spoke direction
      b.yield = 0.12 + 0.88 * rankFracOf(b);    // small buys yield, whales hold
      b.x = self.x + Math.cos(ang) * rr;
      b.y = self.y + Math.sin(ang) * rr;
      const nxt = members[j + 1];
      rr += b.r + (nxt ? nxt.r : 0) + minDim * 0.011;   // stack the next mate straight out behind this one
      seq.push(b);
    });
  });

  // ---- SETTLE: weighted 2D separation + hub clearance + a gentle pull back to
  // the wedge angle (keeps funder lines local without fighting the pack). Iterated
  // to convergence, so the finished map has NO overlaps. ----
  const hubClear = () => {
    let mv = false;
    for (const b of buyers) {
      let dx = b.x - self.x, dy = b.y - self.y, d = Math.hypot(dx, dy) || 0.01, need = b.r + self.r + 8;
      if (d < need) { b.x = self.x + dx / d * need; b.y = self.y + dy / d * need; mv = true; }
    }
    return mv;
  };
  // NOTE: the canvas clamp is deliberately NOT inside this loop — clamping mid-
  // settle jams edge bubbles back together and the pack can never converge. We
  // let it settle freely (it stays on-canvas by construction) and clamp once at
  // the very end.
  let maxOv = 0;
  for (let it = 0; it < 300; it++) {
    // angular spring toward the spoke direction (tangential only — radius free) so
    // a funder's buyers line up on ONE straight radial → straight funder lines.
    // Stronger + longer than before, then fades so it can't fight convergence.
    if (it < 120) for (const b of buyers) {
      const a = Math.atan2(b.y - self.y, b.x - self.x), r = Math.hypot(b.x - self.x, b.y - self.y) || 0.01;
      const d = Math.atan2(Math.sin(b._ta - a), Math.cos(b._ta - a));
      const na = a + d * 0.08;
      b.x = self.x + Math.cos(na) * r; b.y = self.y + Math.sin(na) * r;
    }
    // weighted pairwise separation: the bigger bubble barely yields, the smaller
    // gives way — so whales stay central and the tail is pushed outward.
    maxOv = 0;
    for (let i = 0; i < buyers.length; i++) {
      const a = buyers[i];
      for (let j = i + 1; j < buyers.length; j++) {
        const b = buyers[j];
        let ux = b.x - a.x, uy = b.y - a.y, dd = Math.hypot(ux, uy) || 0.01, need = a.r + b.r + 5;
        if (dd < need) {
          const push = need - dd, wa = a.yield / (a.yield + b.yield), wb = 1 - wa;
          ux /= dd; uy /= dd;
          a.x -= ux * push * wa; a.y -= uy * push * wa;
          b.x += ux * push * wb; b.y += uy * push * wb;
          if (push > maxOv) maxOv = push;
        }
      }
    }
    hubClear();
    if (it >= 120 && maxOv < 0.5) break;                // converged — no overlaps left
  }
  for (const b of buyers) { b.ang = Math.atan2(b.y - self.y, b.x - self.x); b._rr = Math.hypot(b.x - self.x, b.y - self.y); }
  const buyerMaxRR = Math.max(coreR, ...buyers.map(b => b._rr));

  // ---- FUNDERS: just outside their own buyers, at the buyers' mean angle so the
  // lines fan inward at one cluster — short and non-crossing. ----
  const gap = minDim * 0.05;
  const placedA = [];
  const angDiff = (a, b) => Math.abs(Math.atan2(Math.sin(a - b), Math.cos(a - b)));
  funders.sort((a, b) => (kidsOf[b.id]?.length || 0) - (kidsOf[a.id]?.length || 0));
  funders.forEach((f) => {
    const kids = (kidsOf[f.id] || []).map(id => buyers.find(b => b.id === id)).filter(Boolean);
    let ang, kidR;
    if (kids.length) {
      let sx = 0, sy = 0;
      for (const k of kids) { sx += Math.cos(k.ang); sy += Math.sin(k.ang); }
      ang = Math.atan2(sy, sx);
      kidR = Math.max(...kids.map(k => k._rr || coreR));
    } else { ang = hash01(f.id, 29) * Math.PI * 2; kidR = buyerMaxRR; }
    const MINSEP = 0.26;
    const base0 = ang; let k = 1;
    while (placedA.some(pa => angDiff(ang, pa) < MINSEP) && k < 80) { ang = base0 + (k % 2 ? 1 : -1) * Math.ceil(k / 2) * 0.1; k++; }
    placedA.push(ang);
    let r = Math.min(minDim * 0.62, kidR + gap + f.r);
    f.x = self.x + Math.cos(ang) * r;
    f.y = self.y + Math.sin(ang) * r;
    // clear any NON-child buyer it landed on: slide the funder outward along its
    // own spoke until nothing overlaps (buyers are already settled, so only the
    // funder moves — its lines stay pointed at its cluster).
    for (let g = 0; g < 40; g++) {
      let hit = false;
      for (const b of buyers) {
        if (Math.hypot(b.x - f.x, b.y - f.y) < b.r + f.r + 4) { hit = true; break; }
      }
      if (!hit) break;
      r += minDim * 0.02;
      f.x = self.x + Math.cos(ang) * r;
      f.y = self.y + Math.sin(ang) * r;
    }
  });

  // NOTE: no "reserved zone" nudge above the hub — shoving buyers sideways out of
  // a label box re-introduced overlaps a settled pack had already resolved. The
  // CA's symbol chip renders on TOP of the bubbles (its own background in
  // renderMapSVG), so it stays readable without moving anything.

  // ---- horizontal stretch to use the wide canvas (only widens gaps → never
  // creates a new overlap) ----
  const ex = Math.min(1.38, MAP_W / MAP_H);
  for (const n of nodes) { if (!n.self) n.x = self.x + (n.x - self.x) * ex; }

  // ---- safety clamp FIRST (nudge any edge node on-canvas), THEN a final cleanup
  // so the cleanup gets the last word and clamping can't re-introduce an overlap. ----
  const mX = MAP_W * 0.02, mY = MAP_H * 0.02;
  for (const n of nodes) { if (!n.self) { n.x = Math.max(mX, Math.min(MAP_W - mX, n.x)); n.y = Math.max(mY, Math.min(MAP_H - mY, n.y)); } }

  // A few gentle passes over ALL non-hub nodes (buyers AND funders) erase any last
  // few-pixel residual overlap from funder placement, the stretch, or the clamp.
  // Moves are sub-pixel on an already-settled pack, so the hierarchy is untouched.
  for (let it = 0; it < 16; it++) {
    let moved = false;
    for (let i = 0; i < nodes.length; i++) {
      const a = nodes[i]; if (a.self) continue;
      for (let j = i + 1; j < nodes.length; j++) {
        const b = nodes[j]; if (b.self) continue;
        let ux = b.x - a.x, uy = b.y - a.y, dd = Math.hypot(ux, uy) || 0.01, need = a.r + b.r + 4;
        if (dd < need) { const p = (need - dd) / 2 / dd; ux *= p; uy *= p; a.x -= ux; a.y -= uy; b.x += ux; b.y += uy; moved = true; }
      }
      let dx = a.x - self.x, dy = a.y - self.y, d = Math.hypot(dx, dy) || 0.01, hn = a.r + self.r + 8;
      if (d < hn) { a.x = self.x + dx / d * hn; a.y = self.y + dy / d * hn; }
    }
    if (!moved) break;
  }

  // Launch spokes stay STRAIGHT — no elbow bend points on this map type.
  for (const n of nodes) { n.viaX = undefined; n.viaY = undefined; }
}

function renderMapSVG(nodes, links) {
  const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const groupsUsed = [...new Set(nodes.map(n => n.group))];

  // SOLID bubbles with a glossy highlight (lighter center → solid edge, all
  // opacity 1) so they read cleanly over the connection lines.
  let defs = "";
  for (const g of groupsUsed) {
    const col = GROUP_COLOR[g] || "#666";
    defs += `<radialGradient id="grad-${g}" cx="36%" cy="30%" r="82%">`
      + `<stop offset="0%" stop-color="${lighten(col, 0.42)}" stop-opacity="1"/>`
      + `<stop offset="52%" stop-color="${col}" stop-opacity="1"/>`
      + `<stop offset="100%" stop-color="${lighten(col, -0.18)}" stop-opacity="1"/>`
      + `</radialGradient>`;
  }
  defs += `<filter id="glow" x="-60%" y="-60%" width="220%" height="220%">`
    + `<feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>`;
  // Background depth is part of the palette: gradient stops, star tint and a
  // pair of very faint nebula blooms all follow the selected scheme.
  defs += `<radialGradient id="mapbg" cx="50%" cy="42%" r="75%">`
    + `<stop offset="0%" stop-color="${MAP_BG[0]}"/><stop offset="100%" stop-color="${MAP_BG[1]}"/></radialGradient>`;
  defs += `<radialGradient id="mapneb" cx="50%" cy="50%" r="50%">`
    + `<stop offset="0%" stop-color="${MAP_NEBULA}" stop-opacity="0.22"/><stop offset="70%" stop-color="${MAP_NEBULA}" stop-opacity="0.08"/><stop offset="100%" stop-color="${MAP_NEBULA}" stop-opacity="0"/></radialGradient>`;

  // Constellation edges: clean STRAIGHT lines — no curves, no noise. Each line to
  // the tracked wallet is COLOURED BY DIRECTION (green = inflow, purple = outflow,
  // teal = two-way) with a chevron pointing the way value flows. Interactions
  // BETWEEN other wallets get a SOLID pink line (its own colour, not dashed).
  // Line thickness grows with the number of transfers, so recurring links read
  // as heavier.
  const centerMax = Math.max(...links.filter(l => !l.peer).map(l => l.w), 1);
  const peerMax = Math.max(...links.filter(l => l.peer).map(l => l.w), 1);
  // A small triangle at fraction `at` along s→t, pointing along the flow.
  const chevron = (s, t, at, sign, col, sw) => {
    let ux = t.x - s.x, uy = t.y - s.y; const L = Math.hypot(ux, uy) || 1; ux /= L; uy /= L;
    ux *= sign; uy *= sign;                              // +1 = s→t, -1 = t→s
    const mx = s.x + (t.x - s.x) * at, my = s.y + (t.y - s.y) * at;
    const px = -uy, py = ux, z = 5 + (sw || 2) * 1.7;    // arrowhead grows with line thickness
    // Arrows stay FULLY OPAQUE with a dark outline (lines are semi-transparent, the
    // direction marker must not be) — solid and slightly larger for readability.
    return `<path d="M${(mx + ux * z).toFixed(1)},${(my + uy * z).toFixed(1)} `
      + `L${(mx - ux * z + px * z * 0.7).toFixed(1)},${(my - uy * z + py * z * 0.7).toFixed(1)} `
      + `L${(mx - ux * z - px * z * 0.7).toFixed(1)},${(my - uy * z - py * z * 0.7).toFixed(1)} Z" fill="${col}" fill-opacity="1" stroke="#05070a" stroke-width="1" stroke-linejoin="round"/>`;
  };
  let peerEdges = "", edges = "", arrows = "", peerArrows = "";
  for (const l of links) {
    const s = nodes.find(n => n.id === l.source), t = nodes.find(n => n.id === l.target);
    if (!s || !t) continue;
    if (l.peer) {
      // Interaction between two OTHER counterparties — solid pink line, thicker when
      // they transacted more, directional chevrons (both ways when bidirectional).
      const psw = 0.9 + 3.4 * Math.pow(l.w / peerMax, 0.7);
      peerEdges += `<line x1="${s.x.toFixed(1)}" y1="${s.y.toFixed(1)}" x2="${t.x.toFixed(1)}" y2="${t.y.toFixed(1)}" stroke="${PEER_COLOR}" stroke-opacity="0.60" stroke-width="${psw.toFixed(2)}" stroke-linecap="round"/>`;
      const ab = l.ab || 0, ba = l.ba || 0;   // ab = source→target, ba = target→source
      if (ab > 0) peerArrows += chevron(s, t, 0.64, 1, PEER_COLOR, psw);
      if (ba > 0) peerArrows += chevron(s, t, 0.36, -1, PEER_COLOR, psw);
      if (!ab && !ba) peerArrows += chevron(s, t, 0.5, 1, PEER_COLOR, psw);
      continue;
    }
    // source is the tracked wallet; target is the counterparty. Colour by the
    // counterparty's net flow; chevron points the way value moved; thickness by count.
    const cp = t.self ? s : t;
    const hub = t.self ? t : s;
    const { col, flow } = edgeDir(cp.net != null ? cp.net : 0);
    const sw = 0.8 + 4.4 * Math.pow(l.w / centerMax, 0.72);   // recurring transfers → thicker
    if (cp.viaX != null && !cp.cluster) {
      // Long spoke with an ELBOW: hub → bend point → node, so the endpoint can sit
      // laterally off the ray and the space between spokes gets used.
      edges += `<path d="M${hub.x.toFixed(1)},${hub.y.toFixed(1)} L${cp.viaX.toFixed(1)},${cp.viaY.toFixed(1)} L${cp.x.toFixed(1)},${cp.y.toFixed(1)}" fill="none" stroke="${col}" stroke-opacity="0.50" stroke-width="${sw.toFixed(2)}" stroke-linecap="round" stroke-linejoin="round"/>`;
      if (flow !== 0) arrows += chevron({ x: cp.viaX, y: cp.viaY }, cp, 0.6, flow, col, sw); // on the outer segment
    } else {
      edges += `<line x1="${s.x.toFixed(1)}" y1="${s.y.toFixed(1)}" x2="${t.x.toFixed(1)}" y2="${t.y.toFixed(1)}" stroke="${col}" stroke-opacity="0.50" stroke-width="${sw.toFixed(2)}" stroke-linecap="round"/>`;
      if (flow !== 0 && !cp.cluster) arrows += chevron(s, t, 0.62, flow, col, sw); // +1 out (self→cp), -1 in (cp→self)
    }
  }

  // Faint deterministic starfield behind everything, for the constellation feel.
  // Star tint follows the palette; two soft nebula blooms give the space depth.
  let stars = `<ellipse cx="${(MAP_W * 0.30).toFixed(0)}" cy="${(MAP_H * 0.26).toFixed(0)}" rx="${(MAP_W * 0.42).toFixed(0)}" ry="${(MAP_H * 0.36).toFixed(0)}" fill="url(#mapneb)"/>`
    + `<ellipse cx="${(MAP_W * 0.76).toFixed(0)}" cy="${(MAP_H * 0.74).toFixed(0)}" rx="${(MAP_W * 0.36).toFixed(0)}" ry="${(MAP_H * 0.30).toFixed(0)}" fill="url(#mapneb)"/>`;
  const starN = Math.round((MAP_W * MAP_H) / 8500);
  for (let i = 0; i < starN; i++) {
    const sx = hash01("star" + i, 3) * MAP_W, sy = hash01("star" + i, 7) * MAP_H;
    const sr = 0.4 + hash01("star" + i, 11) * 1.0;
    const so = 0.05 + hash01("star" + i, 13) * 0.20;
    stars += `<circle cx="${sx.toFixed(1)}" cy="${sy.toFixed(1)}" r="${sr.toFixed(2)}" fill="${MAP_STAR}" fill-opacity="${so.toFixed(2)}"/>`;
  }

  let bubbles = "";
  let topLabel = "";                          // the hub's own label — drawn LAST so a tight core can't bury the token symbol
  // The canvas grows with node count but is squeezed into the same panel width —
  // so label font must grow WITH the canvas or dense maps become unreadable when
  // fully zoomed out. LBL keeps the on-screen label size constant at 1× zoom.
  const LBL = Math.max(1, MAP_W / 760);

  // ---- LABEL PLACEMENT (v5.7.4.j): radial anchor + force de-collision ----
  // Each visible label starts just OUTSIDE its node along the radial from the
  // hub (so labels fan outward into open space), then a short relaxation pushes
  // overlapping chips apart and off every node body. When a chip ends up far
  // from its node a thin leader line ties them together. Deterministic.
  const lblPlan = new Map();
  const lblLeaders = [];
  {
    const dense = nodes.length > 26;                     // on busy maps, label the meaningful nodes
    const hubN = nodes.find(x => x.self) || { x: MAP_W / 2, y: MAP_H / 2 };
    const jobs = [];
    nodes.forEach((n) => {
      if (mapLabelMode === "funding"
          && !(n.self || n.group === "funding" || (mapMode !== "ca" && n.group === "exchange"))) return;
      const showLabel = n.self || n.named || n.cluster || mapLabelsAll
        || !dense || (n.certainty != null && n.certainty >= 30) || n.r >= 17;
      if (!showLabel) return;
      const base = n.cluster ? n.label : (n.named ? `[${n.label}]` : n.label);
      const pct = n.cluster ? ` · ${n.count}` : (n.certainty != null ? ` · ${n.certainty}%` : "");
      const labelText = base + pct;
      const fontSize = (n.self ? 12 : 10.5) * LBL;
      const maxW = 190 * LBL;
      const estW = (t) => 10 * LBL + t.length * (fontSize * 0.58);
      let lines2 = [labelText];
      if (estW(labelText) > maxW) {
        const mid = Math.ceil(labelText.length / 2);
        let cut = labelText.lastIndexOf(" ", mid);
        if (cut < 4) cut = labelText.indexOf(" ", mid);
        if (cut < 4) cut = mid;
        lines2 = [labelText.slice(0, cut).trim(), labelText.slice(cut).trim()];
        while (lines2[1].length > 4 && estW(lines2[1]) > maxW) lines2[1] = lines2[1].slice(0, -2).trimEnd() + "…";
      }
      const lineH = fontSize + 3;
      const chipH = fontSize + 6 + (lines2.length - 1) * lineH;
      const chipW = Math.min(maxW, Math.max(...lines2.map(estW)));
      // ideal chip CENTRE: radially outward from the hub, just past the node.
      let ux = n.x - hubN.x, uy = n.y - hubN.y;
      const ul = Math.hypot(ux, uy) || 1; ux /= ul; uy /= ul;
      if (n.self) { ux = 0; uy = -1; }                   // hub label sits straight above
      const gap = n.r + 6 + chipH * 0.55 + chipW * 0.10;
      const ideal = { cx: n.x + ux * gap, cy: n.y + uy * gap };
      jobs.push({ n, lines: lines2, fontSize, lineH, chipH, chipW,
        cx: ideal.cx, cy: ideal.cy, ix: ideal.cx, iy: ideal.cy,
        prio: n.self ? 1e9 : (n.certainty ?? 55) });
    });
    // Node bodies are fixed obstacles for labels.
    const bodies = nodes.map(x => ({ x: x.x, y: x.y, r: x.r + 3 }));
    const ov = (a, b) => {   // signed overlap of two boxes → separation vector
      const ox = Math.min(a.cx + a.chipW / 2, b.cx + b.chipW / 2) - Math.max(a.cx - a.chipW / 2, b.cx - b.chipW / 2);
      const oy = Math.min(a.cy + a.chipH / 2, b.cy + b.chipH / 2) - Math.max(a.cy - a.chipH / 2, b.cy - b.chipH / 2);
      return { ox, oy };
    };
    const hcx = hubN.x, hcy = hubN.y;
    for (let it = 0; it < 110; it++) {
      const cool = 1 - it / 150;
      // chip vs chip — separate with a little extra padding so nothing kisses
      for (let i = 0; i < jobs.length; i++) for (let k = i + 1; k < jobs.length; k++) {
        const a = jobs[i], b = jobs[k];
        const { ox, oy } = ov(a, b);
        if (ox > -3 && oy > -3 && ox > 0 && oy > 0) {
          if (ox < oy) { const s = (ox / 2 + 1) * (a.cx <= b.cx ? -1 : 1); a.cx += s; b.cx -= s; }
          else { const s = (oy / 2 + 1) * (a.cy <= b.cy ? -1 : 1); a.cy += s; b.cy -= s; }
        }
      }
      // chip vs node bodies
      for (const a of jobs) for (const bd of bodies) {
        const nx = Math.max(a.cx - a.chipW / 2, Math.min(bd.x, a.cx + a.chipW / 2));
        const ny = Math.max(a.cy - a.chipH / 2, Math.min(bd.y, a.cy + a.chipH / 2));
        const dnx = bd.x - nx, dny = bd.y - ny, dd = Math.hypot(dnx, dny);
        if (dd < bd.r) {
          let dx = a.cx - bd.x, dy = a.cy - bd.y; const L = Math.hypot(dx, dy) || 1;
          const push = (bd.r - dd) + 1;
          a.cx += dx / L * push; a.cy += dy / L * push;
        }
      }
      // gentle OUTWARD nudge only when a chip sits right on the hub, so the
      // centre stays clear — no far floating (labels have no leader lines now).
      for (const a of jobs) {
        let ux = a.cx - hcx, uy = a.cy - hcy; const L = Math.hypot(ux, uy) || 1;
        const near = Math.max(0, 1 - L / (0.20 * Math.min(MAP_W, MAP_H)));
        if (near > 0) { a.cx += (ux / L) * 1.2 * near * cool; a.cy += (uy / L) * 1.2 * near * cool; }
      }
      // STRONG spring back to the label's ideal spot beside its node — keeps
      // every chip hugging its owner so it's unambiguous without a leader line.
      for (const a of jobs) { a.cx += (a.ix - a.cx) * 0.10; a.cy += (a.iy - a.cy) * 0.10; }
      // clamp to canvas
      for (const a of jobs) {
        a.cx = Math.max(a.chipW / 2 + 3, Math.min(MAP_W - a.chipW / 2 - 3, a.cx));
        a.cy = Math.max(a.chipH / 2 + 3, Math.min(MAP_H - a.chipH / 2 - 3, a.cy));
      }
    }
    for (const a of jobs) {
      const lx = a.cx, ly = a.cy - a.chipH / 2 + a.fontSize;   // baseline of first line
      lblPlan.set(a.n.id, { lx, ly, lines: a.lines, fontSize: a.fontSize, lineH: a.lineH, chipH: a.chipH, chipW: a.chipW });
      // (no leader lines — labels stay close to their nodes; see the gentler
      //  outward bias / spring in the relaxation above)
    }
  }

  for (const n of nodes) {
    const col = GROUP_COLOR[n.group] || "#666";
    bubbles += `<g class="mnode" data-id="${esc(n.id)}" style="cursor:grab">`;
    bubbles += `<circle cx="${n.x.toFixed(1)}" cy="${n.y.toFixed(1)}" r="${(n.r + (n.self ? 8 : 5)).toFixed(1)}" fill="${col}" fill-opacity="${n.self ? 0.20 : 0.12}" filter="url(#glow)"/>`;
    bubbles += `<circle class="mbub" cx="${n.x.toFixed(1)}" cy="${n.y.toFixed(1)}" r="${n.r.toFixed(1)}" fill="url(#grad-${n.group})" stroke="${lighten(col, 0.25)}" stroke-width="${n.self ? 2.5 : 1.4}" stroke-opacity="0.95"/>`;
    // bright star-core glint (skipped where a certainty numeral fills the node)
    if (!n.cluster && (n.self || n.r < 19)) bubbles += `<circle cx="${n.x.toFixed(1)}" cy="${n.y.toFixed(1)}" r="${Math.max(1.4, n.r * 0.16).toFixed(1)}" fill="#ffffff" fill-opacity="0.85" pointer-events="none"/>`;
    // clusters get a concentric outline to read as "a stack of many"
    if (n.cluster) bubbles += `<circle cx="${n.x.toFixed(1)}" cy="${n.y.toFixed(1)}" r="${(n.r + 3.5).toFixed(1)}" fill="none" stroke="${col}" stroke-width="1" stroke-opacity="0.5" stroke-dasharray="2 3"/>`;
    if (n.bundleRisk) bubbles += `<circle cx="${n.x.toFixed(1)}" cy="${n.y.toFixed(1)}" r="${(n.r + 3).toFixed(1)}" fill="none" stroke="${lighten(GROUP_COLOR.bundle || "#b83bff", 0.3)}" stroke-width="1.2" stroke-opacity="0.75" stroke-dasharray="3 3"/>`;
    if (mapChainSet.has(n.id)) {   // pinned to the investigation chain — BOLD electric-magenta targeting halo: glow bloom + crisp white edge + breathing pulse + slow-spinning dashes. Pops on every palette.
      const cx1 = n.x.toFixed(1), cy1 = n.y.toFixed(1), R = n.r;
      bubbles += `<circle cx="${cx1}" cy="${cy1}" r="${(R + 18).toFixed(1)}" fill="${CHAIN_HL}" fill-opacity="0.17" filter="url(#glow)" pointer-events="none"/>`;                                     // soft glow bloom
      bubbles += `<circle cx="${cx1}" cy="${cy1}" r="${(R + 6).toFixed(1)}" fill="none" stroke="${CHAIN_HL}" stroke-width="3.6" stroke-opacity="1" filter="url(#glow)" pointer-events="none"/>`;         // bold glowing ring
      bubbles += `<circle cx="${cx1}" cy="${cy1}" r="${(R + 3).toFixed(1)}" fill="none" stroke="#ffffff" stroke-width="1.2" stroke-opacity="0.95" pointer-events="none"/>`;                              // crisp white inner edge
      bubbles += `<circle class="chain-pulse" cx="${cx1}" cy="${cy1}" r="${(R + 12).toFixed(1)}" fill="none" stroke="${CHAIN_HL}" stroke-width="2" stroke-opacity="0.85" pointer-events="none"/>`;         // breathing outer ring
      bubbles += `<circle class="chain-spin" cx="${cx1}" cy="${cy1}" r="${(R + 9).toFixed(1)}" fill="none" stroke="${CHAIN_HL}" stroke-width="2.6" stroke-opacity="0.9" stroke-dasharray="2.5 8" stroke-linecap="round" pointer-events="none"/>`;   // slow-spinning targeting dashes
    }
    if (mapSelection.has(n.id)) bubbles += `<circle cx="${n.x.toFixed(1)}" cy="${n.y.toFixed(1)}" r="${(n.r + 6).toFixed(1)}" fill="none" stroke="#57b8ff" stroke-width="1.7" stroke-opacity="0.95" stroke-dasharray="5 3"/>`;
    if (lblPlan.has(n.id)) {
      const P = lblPlan.get(n.id);
      // mlabel group: zoom counter-scales these around their anchor so labels keep
      // a constant on-screen size (readable at 1×, out of the way when zoomed in).
      // The hub's label is collected into topLabel so it draws ON TOP of every
      // bubble — a tight launch core can never bury the token symbol.
      let lbl = `<g class="mlabel" data-ax="${P.lx.toFixed(1)}" data-ay="${(P.ly - P.fontSize + P.chipH / 2).toFixed(1)}">`;
      lbl += `<rect x="${(P.lx - P.chipW / 2).toFixed(1)}" y="${(P.ly - P.fontSize).toFixed(1)}" width="${P.chipW.toFixed(1)}" height="${P.chipH.toFixed(1)}" rx="${Math.min(9 * LBL, P.chipH / 2).toFixed(1)}" fill="#0b0e13" fill-opacity="${n.self ? 0.92 : 0.78}" stroke="${col}" stroke-opacity="${n.self ? 0.85 : 0.4}" stroke-width="${n.self ? 1.3 : 0.8}"/>`;
      P.lines.forEach((t, li2) => {
        lbl += `<text x="${P.lx.toFixed(1)}" y="${(P.ly + 1.5 + li2 * P.lineH).toFixed(1)}" text-anchor="middle" dominant-baseline="middle" font-size="${P.fontSize.toFixed(1)}" fill="${n.named || n.self ? "#eafff6" : "#cfd4dc"}" font-family="system-ui,sans-serif" font-weight="${n.named || n.self ? 700 : 500}">${esc(t)}</text>`;
      });
      lbl += `</g>`;
      if (n.self) topLabel += lbl; else bubbles += lbl;
    }
    // certainty numeral inside big bubbles too (redundant-but-clear)
    if (!n.self && n.certainty != null && n.r >= 19) {
      bubbles += `<text x="${n.x.toFixed(1)}" y="${(n.y + 4).toFixed(1)}" text-anchor="middle" font-size="${Math.min(13, n.r * 0.48).toFixed(1)}" fill="#ffffff" font-family="system-ui,sans-serif" font-weight="800" pointer-events="none">${n.certainty}</text>`;
    }
    bubbles += `</g>`;
  }
  return `<svg id="mapSvg" data-build="${RELEASE_TAG.toString(36)}" viewBox="0 0 ${MAP_W} ${MAP_H}" width="100%" xmlns="http://www.w3.org/2000/svg" style="border-radius:12px">`
    + `<defs>${defs}</defs>`
    + `<rect x="0" y="0" width="${MAP_W}" height="${MAP_H}" fill="url(#mapbg)"/>`
    + `<g>${stars}</g><g>${peerEdges}</g><g>${peerArrows}</g><g>${edges}</g><g>${arrows}</g><g>${lblLeaders.join("")}</g><g>${bubbles}</g><g>${topLabel}</g></svg>`;
}

let lastMapSVG = "";
let mapNodes = [], mapLinks = [], mapDrag = null, mapMoved = false, mapBound = false, mapPinnedId = null;
let mapSelectMode = false;                 // group-select: click to add, drag to move all, Enter to finish
const mapSelection = new Set();
let mapChainSet = new Set();                // wallet ids pinned to the investigation chain (gold halo)
let mapZoom = 1, mapPanX = 0, mapPanY = 0; // constellation zoom (viewBox-based) + pan
let mapLabelsAll = false;                  // zoomed in ≥1.8× → reveal EVERY label (local density is low)
let mapMode = "wallet";                    // "wallet" (tracked-wallet map) | "ca" (launch map) — routes Reset/Back
let mapLayoutSalt = 0;                      // "Redraw" bumps this → a fresh layout VARIATION (salt 0 = canonical)

// Persisted arrangement helpers — "Set display" saves the current node
// positions so they're restored next time; keyed per wallet / per CA.
function mapStorageKey() {
  return mapMode === "ca" ? (caState ? "c:" + caState.mint : null) : (currentAddress ? "w:" + currentAddress : null);
}
function applySavedLayout(nodes) {
  const key = mapStorageKey();
  const saved = key && lastSettings?.mapLayouts ? lastSettings.mapLayouts[key] : null;
  if (!saved || !saved.pos) return false;
  const sx = saved.w ? MAP_W / saved.w : 1, sy = saved.h ? MAP_H / saved.h : 1;   // rescale if the canvas size changed
  let applied = 0;
  for (const nd of nodes) {
    const p = saved.pos[nd.id];
    if (p) { nd.x = p[0] * sx; nd.y = p[1] * sy; nd.viaX = undefined; nd.viaY = undefined; applied++; }
  }
  return applied > 0;
}
async function saveCurrentLayout() {
  const key = mapStorageKey();
  if (!key || !mapNodes.length) { $("statusLine").textContent = "Nothing to save yet."; setTimeout(() => ($("statusLine").textContent = ""), 1600); return; }
  const d = await store.get();
  d.mapLayouts = d.mapLayouts || {};
  const pos = {};
  for (const nd of mapNodes) pos[nd.id] = [Math.round(nd.x), Math.round(nd.y)];
  d.mapLayouts[key] = { pos, w: MAP_W, h: MAP_H, ts: Date.now() };
  const keys = Object.keys(d.mapLayouts).sort((a, b) => (d.mapLayouts[b].ts || 0) - (d.mapLayouts[a].ts || 0));
  for (const k of keys.slice(20)) delete d.mapLayouts[k];   // keep the 20 most recent
  await store.set({ mapLayouts: d.mapLayouts });
  if (lastSettings) lastSettings.mapLayouts = d.mapLayouts;
  $("statusLine").textContent = "Arrangement saved — it'll be restored next time.";
  setTimeout(() => ($("statusLine").textContent = ""), 2200);
}
let mapLabelMode = "all";                  // "all" | "funding" — hide wallet ids/labels, keep only funding sources

// Labels keep a CONSTANT on-screen size: zooming in scales the world up, so we
// counter-scale each label chip around its anchor by 1/zoom. Aids navigation —
// zoomed-out labels are readable, zoomed-in labels stay compact instead of huge.
function scaleMapLabels() {
  const svg = $("mapStage")?.querySelector("svg");
  if (!svg) return;
  const s = (1 / mapZoom).toFixed(4);
  svg.querySelectorAll("g.mlabel").forEach(g => {
    const ax = g.getAttribute("data-ax"), ay = g.getAttribute("data-ay");
    g.setAttribute("transform", mapZoom > 1.001 ? `translate(${ax} ${ay}) scale(${s}) translate(-${ax} -${ay})` : "");
  });
}

// Apply the current zoom/pan as the SVG viewBox (clamped so the view can't
// wander far off-canvas). Zoom never touches node data — pure viewport.
function applyMapView() {
  const svg = $("mapStage")?.querySelector("svg");
  if (!svg) return;
  // Crossing the reveal threshold changes WHICH labels exist → re-render once.
  const all = mapZoom >= 1.8;
  if (all !== mapLabelsAll) { mapLabelsAll = all; rerenderMap(); return; }
  const w = MAP_W / mapZoom, h = MAP_H / mapZoom;
  mapPanX = Math.max(-20, Math.min(MAP_W - w + 20, mapPanX));
  mapPanY = Math.max(-20, Math.min(MAP_H - h + 20, mapPanY));
  svg.setAttribute("viewBox", `${mapPanX.toFixed(1)} ${mapPanY.toFixed(1)} ${w.toFixed(1)} ${h.toFixed(1)}`);
  scaleMapLabels();
  const zl = $("zoomLevel");
  if (zl) zl.textContent = mapZoom.toFixed(1).replace(/\.0$/, "") + "×";
}

// Recompute a node's elbow after it moves: SAME deterministic lateral angle
// (hash-seeded per address), applied to the new position — dragging no longer
// resets the bend to a straight line.
function refreshVia(n) {
  // Spokes are STRAIGHT on every map now (the elbow system is gone) — keep the
  // hook so drag handlers stay valid, but it only clears any stale bend.
  if (!n) return;
  n.viaX = undefined; n.viaY = undefined;
}
let mapMeta = { peerCount: 0, hidden: 0, infraTotal: 0 };

// Rich per-node profile for a LAUNCH-map click: what this wallet actually did
// with THIS token. Buyers show size / share / timing / wallet-age / funding /
// bundle / gas / every flag; funding sources show who and how many they seeded;
// the token shows the launch summary.
function caNodeDetailHTML(n) {
  if (!caState) return "";
  const S = lastSettings || {};
  const row = (label, val) => `<div class="tip-row"><span>${label}</span><b>${val}</b></div>`;
  if (n.self) {
    const flagged = (caState.buyers || []).filter(b => b.qualifies).length;
    return `<div class="tip-cadetail">`
      + row("Early buyers", `${(caState.buyers || []).length}`)
      + row("Flagged", `${flagged}`)
      + (caState.supplyUi ? row("Supply", `${fmtNum(caState.supplyUi, 0)}`) : "")
      + row("Scan window", `${fmtDuration(caState.windowSec || 0)} · ${caState.txScanned || 0} tx`)
      + `</div>`;
  }
  if (n.group === "funding") {
    const kids = (caState.funderGroups && caState.funderGroups[n.id]) || [];
    const nm = fundingSourceName(n.id, S);
    return `<div class="tip-cadetail">`
      + row("Funded", `${kids.length} early buyer${kids.length !== 1 ? "s" : ""}`)
      + (nm && nm !== shortAddr(n.id) ? row("Label", escHtml(nm)) : "")
      + `<div class="tip-flag muted">Seeded the wallets it points to just before / around launch.</div>`
      + `</div>`;
  }
  const b = (caState.buyers || []).find(x => x.addr === n.id);
  if (!b) return "";
  const dt = b.firstT - caState.launchTs;
  let h = `<div class="tip-cadetail">`;
  h += row("Bought", `${fmtNum(b.tok)}${caState.symbol ? " $" + caState.symbol : ""}`);
  if (b.sol > 0.0005) h += row("Paid", `~${fmtNum(b.sol)} SOL`);
  if (b.share != null && b.share >= 0.0001) h += row("Supply", `${(b.share * 100).toFixed(2)}%`);
  h += row("Buys", `${b.n || 1} tx · entry #${b.firstIdx + 1}`);
  h += row("Timing", `+${dt < 60 ? dt + "s" : Math.round(dt / 60) + "m"} after launch`);
  if (b.ageAtLaunchSec != null) h += row("Wallet age", b.ageAtLaunchSec <= 0 ? "born at launch" : fmtAge(b.ageAtLaunchSec) + " old");
  if (b.funder) h += row("Funded by", `${escHtml(fundingSourceName(b.funder, S))}${b.funderAmt ? ` · ${fmtNum(b.funderAmt)} SOL` : ""}`);
  if (b.bundleMates) h += row("Bundle", `× ${b.bundleMates + 1} wallets, one tx/second`);
  if (b.gasGroup) h += row("Gas config", `group #${b.gasGroup}`);
  if ((b.flags || []).length) h += `<div class="tip-flags">${b.flags.map(f => `<div class="tip-flag">• ${escHtml(f)}</div>`).join("")}</div>`;
  else h += `<div class="tip-flag ok">no launch-window flags</div>`;
  h += `</div>`;
  return h;
}

function pinMapTip(n) {
  const tip = $("mapTip");
  if (!tip) return;
  mapPinnedId = n.id;
  const col = GROUP_COLOR[n.group] || "#888";
  const tracked = ((lastSettings?.wallets) || []).some(w => w.address === n.id);
  const bar = n.certainty != null ? `<div class="tip-bar"><span style="width:${n.certainty}%;background:${col}"></span></div>` : "";
  const tipGrp = mapMode === "ca"
    ? (n.self ? "Token (CA)" : n.group === "funding" ? "Funding source" : n.group === "wallet" ? "Early buyer" : "Flagged early buyer")
    : GROUP_LABEL[n.group];
  // On a LAUNCH map, a clicked node opens its FULL launch profile — exactly what
  // this wallet did with THIS token (size, timing, funding, flags) — not just its
  // one-line assessment.
  const caDetail = mapMode === "ca" ? caNodeDetailHTML(n) : "";
  tip.innerHTML =
    `<div class="tip-name" style="color:${n.self ? GROUP_COLOR.self : col}">${n.self ? "◎ " : ""}${(n.named ? `[${n.label}]` : n.label)}</div>`
    + `<div class="tip-grp">${tipGrp}${n.clsLabel && !caDetail ? ` · ${n.clsLabel}` : ""}${(lastStats && lastStats.symbolMap && lastStats.symbolMap[n.id]) ? ` · $${lastStats.symbolMap[n.id]}` : ""}</div>`
    + (n.certainty != null ? `<div class="tip-row"><span>Certainty</span><b>${n.certainty}%</b></div>${bar}` : "")
    + caDetail
    + `<div class="tip-actions">`
    + `<button class="tip-btn tip-copy">Copy</button>`
    + (!n.self && !tracked ? `<button class="tip-btn tip-track">＋ Track &amp; name</button>` : (tracked ? `<span class="tip-tracked">✓ tracked</span>` : ""))
    + (!n.self ? `<button class="tip-btn tip-chain" title="${mapChainSet.has(n.id) ? "Click to REMOVE from the investigation chain" : "Pin to the investigation chain"}">${mapChainSet.has(n.id) ? "⛓ in chain ✕" : "⛓ chain"}</button>` : "")
    + `<button class="tip-btn tip-close">✕</button>`
    + `</div>`;
  tip.classList.add("pinned");
  tip.classList.remove("hidden");
  // Position the card as a VIEWPORT-FIXED element. The map stage has
  // overflow:hidden and can be taller than the screen, so an absolutely-positioned
  // card gets clipped or falls below the fold. A fixed card escapes that clip and
  // is clamped to the visible window on both axes at any node position or zoom;
  // its height is capped to the window (then it scrolls internally).
  const svg = $("mapStage")?.querySelector("svg");
  if (svg) {
    const M = 8, vw = window.innerWidth, vh = window.innerHeight;
    tip.style.position = "fixed";
    tip.style.maxHeight = Math.max(140, vh - 2 * M) + "px";
    const svgRect = svg.getBoundingClientRect();
    const scale = svgRect.width / (MAP_W / mapZoom) || 1;
    const px = svgRect.left + (n.x - mapPanX) * scale;             // node centre in VIEWPORT px
    const py = svgRect.top + (n.y - mapPanY) * scale;
    const tw = tip.offsetWidth || 224, th = tip.offsetHeight || 200;
    const nodePx = (n.r || 10) * scale;
    // prefer RIGHT of the node, flip left if it would overflow, then hard-clamp
    let x = px + nodePx + 12;
    if (x + tw > vw - M) x = px - nodePx - 12 - tw;
    x = Math.max(M, Math.min(x, vw - tw - M));
    // prefer BELOW the node, flip above if it would overflow, then hard-clamp
    let y = py + nodePx + 12;
    if (y + th > vh - M) y = py - nodePx - 12 - th;
    y = Math.max(M, Math.min(y, vh - th - M));
    tip.style.left = x + "px"; tip.style.top = y + "px";
  }
  tip.querySelector(".tip-copy")?.addEventListener("click", () => {
    navigator.clipboard.writeText(n.id);
    $("statusLine").textContent = "Address copied.";
    setTimeout(() => ($("statusLine").textContent = ""), 1500);
  });
  tip.querySelector(".tip-close")?.addEventListener("click", () => unpinMapTip());
  tip.querySelector(".tip-chain")?.addEventListener("click", async () => {
    if (mapChainSet.has(n.id)) {
      // second click UNPINS — remove from the chain of investigation
      await removeFromChain(n.id);
      mapChainSet.delete(n.id);
    } else {
      // On a LAUNCH map, chain additions group under the CA, not the last wallet.
      if (mapMode === "ca" && caState) await addToChain(n.id, (n.named ? n.label : ""), caState.mint, (caState.symbol ? "$" + caState.symbol : shortAddr(caState.mint)) + " CA");
      else await addToChain(n.id, (n.named ? n.label : ""));
      mapChainSet.add(n.id);
    }
    rerenderMap();
    unpinMapTip();
  });
  tip.querySelector(".tip-track")?.addEventListener("click", () => {
    const actions = tip.querySelector(".tip-actions");
    actions.innerHTML = `<input class="tip-name-in" placeholder="Name (optional)"><button class="tip-btn tip-name-save">Track</button>`;
    const inp = actions.querySelector(".tip-name-in");
    const save = async () => {
      const d = await store.get();
      if (!d.wallets.some(w => w.address === n.id)) {
        d.wallets.push({ address: n.id, added: Date.now(), name: inp.value.trim() });
        await store.set({ wallets: d.wallets });
        if (lastSettings) lastSettings.wallets = d.wallets;
        renderWalletList();
      }
      $("statusLine").textContent = "Tracked" + (inp.value.trim() ? ` as [${inp.value.trim()}]` : "") + ".";
      setTimeout(() => ($("statusLine").textContent = ""), 1800);
      unpinMapTip();
    };
    actions.querySelector(".tip-name-save").addEventListener("click", save);
    inp.addEventListener("keydown", (ev) => { if (ev.key === "Enter") save(); });
    inp.focus();
  });
}
function unpinMapTip() {
  mapPinnedId = null;
  const tip = $("mapTip");
  if (tip) {
    tip.classList.remove("pinned"); tip.classList.add("hidden");
    // clear the fixed-position overrides so the hover tip's CSS (absolute) applies
    tip.style.position = ""; tip.style.maxHeight = ""; tip.style.left = ""; tip.style.top = "";
  }
}

function rerenderMap() {
  // Apply the confidence filter at RENDER time only — hidden nodes keep their
  // positions so the arrangement never resets when the % changes.
  const thr = mapLowConfThresh;
  // Render-time filters — BOTH the low-% filter and the infrastructure toggle hide
  // nodes without touching their positions, so neither one ever resets the layout.
  const visNodes = mapNodes.filter(n => {
    if (n.self) return true;
    if (n.cluster) return mapShowInfra;                 // infra clusters only when toggled on
    if (n.certainty == null) return true;               // exchanges / funding sources
    return n.certainty >= thr;                          // low-confidence filter
  });
  const visIds = new Set(visNodes.map(n => n.id));
  const visLinks = mapLinks.filter(l => visIds.has(l.source) && visIds.has(l.target));
  lastMapSVG = renderMapSVG(visNodes, visLinks);
  const stage = $("mapStage");
  const tip = stage.querySelector("#mapTip");
  const holder = document.createElement("div");
  holder.innerHTML = lastMapSVG;
  stage.replaceChildren(holder.firstChild, tip || makeTip());
  attachNodeHandlers();
  applyMapView();            // re-apply zoom/pan — re-renders never reset the viewport
  const lowHidden = mapNodes.filter(n => !n.self && !n.cluster && n.certainty != null && n.certainty < thr).length;
  renderMapLegend(visNodes, lowHidden);
}

function renderMapLegend(visNodes, lowConfHidden) {
  const present = [...new Set(visNodes.map(n => n.group))];
  const dirBit =
    `<span class="leg"><span class="leg-line" style="background:${DIR_IN}"></span>inflow → you</span>`
    + `<span class="leg"><span class="leg-line" style="background:${DIR_OUT}"></span>you → outflow</span>`
    + `<span class="leg"><span class="leg-line" style="background:${DIR_BOTH}"></span>two-way</span>`;
  const peerBit = mapMeta.peerCount
    ? ` <span class="leg"><span class="leg-line" style="background:${PEER_COLOR}"></span>between other wallets (${mapMeta.peerCount})</span>`
    : "";
  const infoBit = mapMeta.infraTotal
    ? (mapShowInfra
        ? ` <span class="leg" style="color:var(--ink-3)">${mapMeta.infraTotal} infrastructure grouped into clusters</span>`
        : ` <span class="leg" style="color:var(--ink-3)">${mapMeta.infraTotal} infrastructure/minor hidden — use “Show infrastructure”</span>`)
    : "";
  const lowBit = mapLowConfThresh > 0 && lowConfHidden
    ? ` <span class="leg" style="color:var(--ink-3)">${lowConfHidden} below ${mapLowConfThresh}% hidden</span>` : "";
  const chainN = visNodes.filter(n => mapChainSet.has(n.id)).length;
  const chainBit = chainN ? ` <span class="leg"><span class="leg-dot" style="background:${CHAIN_HL};box-shadow:0 0 7px ${CHAIN_HL}, 0 0 0 1.5px #fff"></span>investigation chain (${chainN})</span>` : "";
  // CA launch maps re-read two roles: the hub is the TOKEN, funding = seeders.
  const legLabel = (g) => mapMode === "ca" && g === "self" ? "Token (CA)"
    : mapMode === "ca" && g === "funding" ? "Funding source"
    : mapMode === "ca" && g === "side" ? "Flagged early buyer"
    : mapMode === "ca" && g === "wallet" ? "Early buyer"
    : GROUP_LABEL[g];
  const groupBit = present.map(g =>
    `<span class="leg"><span class="leg-dot" style="background:${GROUP_COLOR[g]}"></span>${legLabel(g)}</span>`).join("");
  $("mapLegend").innerHTML = `<span class="leg-group">lines: ${dirBit}${peerBit}</span><span class="leg-group">nodes: ${groupBit}${chainBit}</span>${infoBit}${lowBit}`;
}
function makeTip() { const t = document.createElement("div"); t.id = "mapTip"; t.className = "map-tip hidden"; return t; }

function attachNodeHandlers() {
  const tip = $("mapTip");
  const nodeById = Object.fromEntries(mapNodes.map(n => [n.id, n]));
  $("mapStage").querySelectorAll(".mnode").forEach(g => {
    const n = nodeById[g.getAttribute("data-id")];
    if (!n) return;
    g.addEventListener("mouseenter", () => {
      if (mapDrag || mapPinnedId) return;
      const col = GROUP_COLOR[n.group] || "#888";
      if (n.cluster) {
        const sample = (n.members || []).slice(0, 6).map(m => `${m.addr.slice(0, 4)}…${m.addr.slice(-4)}${m.label ? ` — ${m.label}` : ""}`).join("<br>");
        tip.innerHTML =
          `<div class="tip-name" style="color:${col}">${n.clusterCat}</div>`
          + `<div class="tip-grp">${n.count} address(es) · ${n.totalTx} transfer(s) total</div>`
          + `<div class="tip-sig">${sample}${n.members && n.members.length > 6 ? `<br>+ ${n.members.length - 6} more…` : ""}</div>`
          + `<div class="tip-hint">grouped infrastructure — drag to move</div>`;
        tip.classList.remove("hidden");
        return;
      }
      const bar = n.certainty != null ? `<div class="tip-bar"><span style="width:${n.certainty}%;background:${col}"></span></div>` : "";
      const tracked = ((lastSettings?.wallets) || []).some(w => w.address === n.id);
      const hovGrp = mapMode === "ca"
        ? (n.self ? "Token (CA)" : n.group === "funding" ? "Funding source" : n.group === "wallet" ? "Early buyer" : "Flagged early buyer")
        : GROUP_LABEL[n.group];
      tip.innerHTML =
        `<div class="tip-name" style="color:${n.self ? GROUP_COLOR.self : col}">${n.self ? "◎ " : ""}${(n.named ? `[${n.label}]` : n.label)}</div>`
        + `<div class="tip-grp">${hovGrp}${n.clsLabel ? ` · ${n.clsLabel}` : ""}${(lastStats && lastStats.symbolMap && lastStats.symbolMap[n.id]) ? ` · $${lastStats.symbolMap[n.id]}` : ""}</div>`
        + (n.certainty != null ? `<div class="tip-row"><span>Certainty</span><b>${n.certainty}%</b></div>${bar}` : "")
        + (n.bundleScore ? `<div class="tip-row"><span>Bundle</span><b style="color:#ff8f8e">${n.bundleScore}%</b></div>` : "")
        + (n.count ? `<div class="tip-row"><span>Transfers</span><b>${n.count} · ${n.inN} in / ${n.outN} out</b></div>` : "")
        + (n.topSig ? `<div class="tip-sig">${String(n.topSig).replace(/</g, "&lt;")}</div>` : "")
        + `<div class="tip-hint">drag to move · click to ${n.self ? "copy" : (tracked ? "copy" : "copy / track")}</div>`;
      tip.classList.remove("hidden");
    });
    g.addEventListener("mouseleave", () => { if (!mapDrag && !mapPinnedId) tip.classList.add("hidden"); });
    g.addEventListener("pointerdown", (ev) => {
      ev.preventDefault();
      mapDrag = n; mapMoved = false;
      tip.classList.add("hidden");
      $("mapStage").querySelector("svg")?.classList.add("dragging");
    });
  });
}

// Stage-level move/up (bound once) so a full re-render mid-drag never severs the gesture.
function bindMapDrag() {
  if (mapBound) return; mapBound = true;
  const stage = $("mapStage");
  const tip = () => $("mapTip");
  let marquee = null;   // drag-select rectangle (select mode): {x0,y0 in svg units, el}
  let panDrag = null;   // background pan while zoomed: {cx, cy} last client coords
  const toSvg = (ev) => {
    const svg = stage.querySelector("svg"); if (!svg) return null;
    const rect = svg.getBoundingClientRect();
    return {
      x: mapPanX + (ev.clientX - rect.left) / rect.width * (MAP_W / mapZoom),
      y: mapPanY + (ev.clientY - rect.top) / rect.height * (MAP_H / mapZoom),
    };
  };
  const marqueeBox = (ev) => {
    const p = toSvg(ev); if (!p) return null;
    return { x0: Math.min(marquee.x0, p.x), y0: Math.min(marquee.y0, p.y), x1: Math.max(marquee.x0, p.x), y1: Math.max(marquee.y0, p.y) };
  };
  const drawMarquee = (box) => {
    const svg = stage.querySelector("svg"); if (!svg) return;
    const rect = svg.getBoundingClientRect(), host = stage.getBoundingClientRect();
    const scale = rect.width / (MAP_W / mapZoom) || 1;
    marquee.el.style.left = (rect.left - host.left + (box.x0 - mapPanX) * scale) + "px";
    marquee.el.style.top = (rect.top - host.top + (box.y0 - mapPanY) * scale) + "px";
    marquee.el.style.width = ((box.x1 - box.x0) * scale) + "px";
    marquee.el.style.height = ((box.y1 - box.y0) * scale) + "px";
  };
  stage.addEventListener("pointermove", (ev) => {
    if (marquee) {                       // rubber-band select: grow the rectangle
      const box = marqueeBox(ev);
      if (box) drawMarquee(box);
      return;
    }
    if (panDrag) {                       // zoomed-in background pan
      const svg = stage.querySelector("svg");
      if (svg) {
        const rect = svg.getBoundingClientRect();
        mapPanX -= (ev.clientX - panDrag.cx) / rect.width * (MAP_W / mapZoom);
        mapPanY -= (ev.clientY - panDrag.cy) / rect.height * (MAP_H / mapZoom);
        panDrag = { cx: ev.clientX, cy: ev.clientY };
        applyMapView();
      }
      return;
    }
    if (mapDrag) {
      const p = toSvg(ev); if (!p) return;
      const nx = Math.max(mapDrag.r + 4, Math.min(MAP_W - mapDrag.r - 4, p.x));
      const ny = Math.max(mapDrag.r + 4, Math.min(MAP_H - mapDrag.r - 4, p.y));
      if (mapSelectMode && mapSelection.has(mapDrag.id)) {
        // group move: shift every selected node by the same delta
        const dx = nx - mapDrag.x, dy = ny - mapDrag.y;
        for (const id of mapSelection) {
          const nn = mapNodes.find(n2 => n2.id === id);
          if (!nn) continue;
          nn.x = Math.max(nn.r + 4, Math.min(MAP_W - nn.r - 4, nn.x + dx));
          nn.y = Math.max(nn.r + 4, Math.min(MAP_H - nn.r - 4, nn.y + dy));
          refreshVia(nn);                                // keep the SAME elbow angle at the new spot
        }
      } else {
        mapDrag.x = nx; mapDrag.y = ny;
        refreshVia(mapDrag);
      }
      mapMoved = true;
      rerenderMap();
      return;
    }
    // move the tooltip with the cursor when hovering (not when pinned)
    const t = tip(); if (!t || t.classList.contains("hidden") || mapPinnedId) return;
    const rect = stage.getBoundingClientRect();
    let x = ev.clientX - rect.left + 16, y = ev.clientY - rect.top + 16;
    if (x + 220 > rect.width) x = ev.clientX - rect.left - 224;
    if (y + (t.offsetHeight || 120) > rect.height) y = rect.height - (t.offsetHeight || 120) - 6;
    t.style.left = Math.max(6, x) + "px"; t.style.top = Math.max(6, y) + "px";
  });
  const endDrag = (ev) => {
    if (marquee) {                       // finish rubber-band
      const box = marqueeBox(ev);
      if (box) {
        const tiny = (box.x1 - box.x0) < 6 && (box.y1 - box.y0) < 6;
        if (tiny) {
          // plain click on empty canvas = CLEAR the current selection so the
          // user can start another one (Enter is what completes the action)
          mapSelection.clear();
        } else {
          for (const n of mapNodes) {
            if (n.self) continue;
            if (n.x >= box.x0 && n.x <= box.x1 && n.y >= box.y0 && n.y <= box.y1) mapSelection.add(n.id);
          }
        }
      }
      marquee.el.remove(); marquee = null;
      rerenderMap();
      return;
    }
    if (mapDrag && !mapMoved && mapSelectMode && !mapDrag.self) {
      // group-select mode: a click toggles the node in/out of the selection
      if (mapSelection.has(mapDrag.id)) mapSelection.delete(mapDrag.id);
      else mapSelection.add(mapDrag.id);
      rerenderMap();
    } else if (mapDrag && !mapMoved && !mapDrag.self && !mapDrag.cluster) {
      // click (no drag) on a wallet node → pin an actions popover (copy / track)
      pinMapTip(mapDrag);
    }
    if (mapDrag) stage.querySelector("svg")?.classList.remove("dragging");
    mapDrag = null;
  };
  stage.addEventListener("pointerup", endDrag);
  stage.addEventListener("pointerleave", () => {
    if (mapDrag) { stage.querySelector("svg")?.classList.remove("dragging"); mapDrag = null; }
    if (marquee) { marquee.el.remove(); marquee = null; }
  });
  stage.addEventListener("pointerdown", (ev) => {
    // click on empty stage background dismisses a pinned popover
    if (mapPinnedId && !ev.target.closest(".mnode") && !ev.target.closest("#mapTip")) unpinMapTip();
    // select mode: dragging on EMPTY canvas starts a rubber-band selection
    if (mapSelectMode && !ev.target.closest(".mnode") && !ev.target.closest("#mapTip")) {
      const p = toSvg(ev); if (!p) return;
      const el = document.createElement("div");
      el.className = "map-marquee";
      stage.appendChild(el);
      marquee = { x0: p.x, y0: p.y, el };
    } else if (!mapSelectMode && mapZoom > 1 && !ev.target.closest(".mnode") && !ev.target.closest("#mapTip")) {
      panDrag = { cx: ev.clientX, cy: ev.clientY };   // zoomed: drag background to pan
    }
  });
  stage.addEventListener("pointerup", () => { panDrag = null; });
  // Wheel = zoom around the cursor (1×–4×). Pure viewport — nothing moves.
  stage.addEventListener("wheel", (ev) => {
    const svg = stage.querySelector("svg"); if (!svg) return;
    ev.preventDefault();
    const rect = svg.getBoundingClientRect();
    const fx = (ev.clientX - rect.left) / rect.width, fy = (ev.clientY - rect.top) / rect.height;
    const sx = mapPanX + fx * (MAP_W / mapZoom), sy = mapPanY + fy * (MAP_H / mapZoom);
    mapZoom = Math.max(1, Math.min(4, mapZoom * (ev.deltaY < 0 ? 1.15 : 1 / 1.15)));
    if (mapZoom <= 1.001) { mapZoom = 1; mapPanX = 0; mapPanY = 0; }
    else { mapPanX = sx - fx * (MAP_W / mapZoom); mapPanY = sy - fy * (MAP_H / mapZoom); }
    applyMapView();
  }, { passive: false });
}

// Full (re)build + fresh layout — this is the "original arrangement" / Reset path.
// Launch Constellation — reads CA → early-buyer wallets → funding sources.
// Same layout/render/interaction pipeline as the wallet map: the CA is the hub,
// buys are direction-coloured spokes (thicker = bigger buy), and funder→buyer
// ties render as the lateral "between other wallets" chords on the outer ring.
function openCaMap(restore = true) {
  if (!caState) return;
  mapMode = "ca";
  const s = caState;
  const labels = Object.fromEntries(((lastSettings?.wallets) || []).filter(w => w.name).map(w => [w.address, w.name]));
  const nodes = [{ id: s.mint, self: true, group: "self", label: s.symbol ? `$${s.symbol}` : shortAddr(s.mint), named: !!s.symbol, certainty: null, count: 0 }];
  const links = [];
  const maxTok = Math.max(...s.buyers.map(b => b.tok), 1);
  // v5.7.5.c rule: bundles are organized by FUNDING SOURCE first. A funding
  // family (personal funder + everyone it seeded) is classified and ringed as
  // ONE bundle and keeps its members adjacent on the ring even when the funder
  // node itself is not drawn; same-tx/second timing remains the fallback key.
  const famKey = caFundingFamilies(s.buyers, lastSettings?.connectors, caBundleEligible(s.buyers));
  for (const b of s.buyers) {
    const fam = famKey(b);
    nodes.push({
      id: b.addr,
      group: (b.bundleMates || fam) ? "bundle" : (b.qualifies ? "side" : "wallet"),
      label: labels[b.addr] || shortAddr(b.addr), named: !!labels[b.addr],
      certainty: b.certainty ?? null, bundleRisk: !!(b.bundleMates || fam),
      inN: 0, outN: 1,                        // token flowed CA → buyer (outflow colour)
      count: b.n || 1,
      bKey: fam ? "f:" + fam : (b.bundleMates ? b.firstT : 0),   // funding family first; same-tx/second timing as fallback — the ring sort keeps mates adjacent
      // RAW ape-magnitude for the map: how much of the token this wallet grabbed,
      // blended with the SOL it paid. The layout RANK-normalises this so bubble
      // size can never collapse even when one whale dwarfs everyone.
      magRaw: (b.tok || 0) + (b.sol || 0) * (maxTok / Math.max(1, Math.max(...s.buyers.map(x => x.sol || 0)))) * 0.5,
      clsLabel: (b.isDeployer ? "deployer" : b.flags[0] || "early buyer"),
    });
    links.push({ source: s.mint, target: b.addr, w: 1 + Math.round(9 * (b.tok / maxTok)), group: "side" });
  }
  // Funding tier: shared funders first (the interesting hubs), then funders of
  // flagged buyers — capped so the outer ring stays readable.
  const buyerSet = new Set(s.buyers.map(b => b.addr));
  const funders = Object.entries(s.funderGroups || {})
    .filter(([f]) => !buyerSet.has(f))                              // a buyer who funded another buyer is already on the map
    .map(([f, kids]) => ({ f, kids, shared: kids.length >= 2, flaggedKid: kids.some(k => s.buyers.find(b => b.addr === k)?.qualifies) }))
    .filter(x => x.shared || x.flaggedKid)
    .sort((a, b) => b.kids.length - a.kids.length)
    .slice(0, 12);
  const connSet = new Set((lastSettings?.connectors) || []);
  for (const { f, kids, shared } of funders) {
    const db = labelFor(f);
    const userNm = labels[f];
    const isConn = connSet.has(f);
    nodes.push({
      id: f, group: "funding",
      // LABELLED funding sources show their label — user name first, then the
      // connector flag, then the funding DB — never the bare address.
      label: userNm || (isConn ? "⚡ Connector" : db ? db.label.replace(/ \((labeled|added)\)$/, "") : shortAddr(f)),
      named: !!(userNm || isConn || db),
      certainty: null, inN: 0, outN: kids.length, count: kids.length,
      clsLabel: isConn ? "connector relayer — original source obscured" : (shared ? `funded ${kids.length} early buyers` : "funding source"),
    });
    for (const k of kids) {
      if (!buyerSet.has(k)) continue;
      links.push({ source: f, target: k, w: 1 + kids.length, group: "peer", peer: true, ab: 1, ba: 0 });   // funder → buyer
    }
  }
  // Deployer as a funding-tier node when it funded buyers but isn't a buyer itself
  if (s.deployer && !buyerSet.has(s.deployer) && !nodes.some(n => n.id === s.deployer)) {
    const devKids = s.buyers.filter(b => b.funder === s.deployer).map(b => b.addr);
    if (devKids.length) {
      nodes.push({ id: s.deployer, group: "funding", label: "deployer", named: true, certainty: null, inN: 0, outN: devKids.length, count: devKids.length, clsLabel: "deployer wallet" });
      for (const k of devKids) links.push({ source: s.deployer, target: k, w: 2 + devKids.length, group: "peer", peer: true, ab: 1, ba: 0 });
    }
  }
  const n = nodes.length;
  const grow = Math.min(3.0, Math.max(1.15, Math.sqrt(n / 8)));
  MAP_W = Math.round(760 * grow);
  MAP_H = Math.round(560 * grow);
  layoutCaMap(nodes, links);                 // dedicated sorted-ring layout, NOT the wallet layout
  if (restore) applySavedLayout(nodes);      // restore a "Set display" arrangement if the user saved one
  mapNodes = nodes; mapLinks = links; mapDrag = null; mapPinnedId = null;
  mapChainSet = new Set(((lastSettings?.chain) || []).map(c => c.address));
  mapSelectMode = false; mapSelection.clear();
  $("mapSelectBtn").textContent = "Select group";
  $("mapSelectBtn").classList.remove("active");
  mapZoom = 1; mapPanX = 0; mapPanY = 0; mapLabelsAll = false;
  mapMeta = { peerCount: links.filter(l => l.peer).length, hidden: 0, infraTotal: 0 };
  $("mapStage").replaceChildren(makeTip());
  bindMapDrag();
  rerenderMap();
  $("mapTitle").textContent = `Launch Constellation — ${s.symbol ? "$" + s.symbol : shortAddr(s.mint)}`;
  $("infraToggle").classList.add("hidden");                          // no infrastructure tier on launch maps
  $("lowConfInput").value = mapLowConfThresh > 0 ? String(mapLowConfThresh) : "";
  $("mapPaletteSel").value = mapPaletteName;
  $("labelsToggle").textContent = mapLabelMode === "all" ? "Labels: all" : "Labels: funding";
  $("labelsToggle").classList.toggle("active", mapLabelMode === "funding");
  $("mapPanel").classList.remove("hidden");
  $("mapPanel").scrollTop = 0;
}

function openBubbleMap(restore = true) {
  if (!lastStats) return;
  mapMode = "wallet";
  $("infraToggle").classList.remove("hidden");
  const built = buildMapData(lastStats, lastSettings || {});
  // Grow the canvas with crowding so bubbles have room to breathe.
  const n = built.nodes.length;
  const grow = Math.min(3.0, Math.max(1.15, Math.sqrt(n / 8)));  // every map gets extra room; dense ones much more
  MAP_W = Math.round(760 * grow);
  MAP_H = Math.round(560 * grow);
  const { nodes, links, hidden, infraTotal, peerCount } = built;
  layoutMap(nodes, links);
  if (restore) applySavedLayout(nodes);     // restore a "Set display" arrangement if the user saved one
  mapNodes = nodes; mapLinks = links; mapDrag = null; mapPinnedId = null;
  mapChainSet = new Set(((lastSettings?.chain) || []).map(c => c.address));   // chain halos
  mapSelectMode = false; mapSelection.clear();
  $("mapSelectBtn").textContent = "Select group";
  $("mapSelectBtn").classList.remove("active");
  mapZoom = 1; mapPanX = 0; mapPanY = 0; mapLabelsAll = false;
  mapMeta = { peerCount, hidden, infraTotal };
  $("mapStage").replaceChildren(makeTip());
  bindMapDrag();
  rerenderMap();            // renders + builds the legend (with the current % filter)
  const nm = (lastSettings?.wallets || []).find(w => w.address === currentAddress)?.name;
  $("mapTitle").textContent = `Constellation — ${nm ? `[${nm}]` : shortAddr(currentAddress || "")}`;
  $("infraToggle").textContent = mapShowInfra ? "Hide infrastructure" : "Show infrastructure";
  $("infraToggle").classList.toggle("active", mapShowInfra);
  $("lowConfInput").value = mapLowConfThresh > 0 ? String(mapLowConfThresh) : "";
  $("mapPaletteSel").value = mapPaletteName;
  $("labelsToggle").textContent = mapLabelMode === "all" ? "Labels: all" : "Labels: funding";
  $("labelsToggle").classList.toggle("active", mapLabelMode === "funding");
  $("mapPanel").classList.remove("hidden");
  $("mapPanel").scrollTop = 0;
}

function saveMapSVG() {
  if (!lastMapSVG) return;
  const blob = new Blob([lastMapSVG], { type: "image/svg+xml" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `constellation-${shortAddr(currentAddress || "wallet").replace(/[^\w]/g, "")}.svg`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// ---------- self-update (File System Access API) ----------
// Chrome won't let an unpacked extension rewrite its own files from ordinary
// JS. The File System Access API can — but only on a directory the user grants.
// So: remember a read/write handle to the install folder (asked once), then
// "Update from folder" copies a chosen new-version folder into it and reloads.
const IDB_NAME = "wt-fs", IDB_STORE = "handles";
function idbOpen() {
  return new Promise((res, rej) => {
    const r = indexedDB.open(IDB_NAME, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(IDB_STORE);
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}
async function idbGet(key) {
  const db = await idbOpen();
  return new Promise((res, rej) => {
    const tx = db.transaction(IDB_STORE, "readonly").objectStore(IDB_STORE).get(key);
    tx.onsuccess = () => res(tx.result); tx.onerror = () => rej(tx.error);
  });
}
async function idbSet(key, val) {
  const db = await idbOpen();
  return new Promise((res, rej) => {
    const tx = db.transaction(IDB_STORE, "readwrite").objectStore(IDB_STORE).put(val, key);
    tx.onsuccess = () => res(); tx.onerror = () => rej(tx.error);
  });
}

async function ensurePermission(handle, mode) {
  const opts = { mode };
  if ((await handle.queryPermission(opts)) === "granted") return true;
  return (await handle.requestPermission(opts)) === "granted";
}

async function readManifest(dirHandle) {
  const fh = await dirHandle.getFileHandle("manifest.json");
  return JSON.parse(await (await fh.getFile()).text());
}

async function copyDir(src, dst) {
  for await (const [name, entry] of src.entries()) {
    if (name.startsWith(".")) continue;
    if (entry.kind === "file") {
      const file = await entry.getFile();
      const w = await (await dst.getFileHandle(name, { create: true })).createWritable();
      await w.write(await file.arrayBuffer());
      await w.close();
    } else if (entry.kind === "directory") {
      const sub = await dst.getDirectoryHandle(name, { create: true });
      await copyDir(entry, sub);
    }
  }
}

function cmpVer(a, b) {
  const pa = String(a).split("."), pb = String(b).split(".");
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (parseInt(pa[i] || 0, 10)) - (parseInt(pb[i] || 0, 10));
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

const setUpStatus = (msg, ok) => {
  const el = $("updateStatus");
  el.textContent = msg;
  el.style.color = ok === true ? "var(--good)" : ok === false ? "var(--critical)" : "var(--ink-3)";
};

// One-time: link the folder Chrome actually loaded this extension from.
// This MUST be the exact directory shown as the extension's path in
// chrome://extensions — otherwise files are copied somewhere reload() won't read.
// Identify our extension folder by its FILES, never by the manifest name — the
// display name can change between versions (e.g. a rebrand), and matching on it
// is what used to break updates across a rename.
async function hasFile(dir, name) {
  try { await dir.getFileHandle(name); return true; } catch { return false; }
}
async function looksLikeOurExtension(dir) {
  return (await hasFile(dir, "popup.js")) && (await hasFile(dir, "popup.html"));
}
async function linkInstallFolder() {
  const myManifest = chrome.runtime.getManifest();
  if (!window.showDirectoryPicker) {
    setUpStatus("This browser build doesn't expose folder access here — use “Reload now” after replacing files manually.", false);
    return null;
  }
  setUpStatus("Select the folder Chrome loaded this extension from (its Path in chrome://extensions)…");
  const dir = await window.showDirectoryPicker({ id: "wt-install", mode: "readwrite" });
  let m;
  try { m = await readManifest(dir); }
  catch { setUpStatus("That folder has no manifest.json — it isn't the extension folder.", false); return null; }
  if (!(await looksLikeOurExtension(dir))) { setUpStatus("That folder doesn't look like this extension (no popup.js / popup.html). Pick the extension's own folder.", false); return null; }
  // Sanity: the linked folder's manifest version should match what's running.
  if (m.version !== myManifest.version) {
    setUpStatus(`Linked folder is v${m.version} but the running extension is v${myManifest.version}. That folder is probably NOT the one Chrome loaded — pick the exact Path from chrome://extensions.`, false);
    return null;
  }
  await idbSet("installDir", dir);
  await refreshLinkLabel();
  setUpStatus(`Linked install folder “${dir.name}”. You can now update from a new-version folder.`, true);
  return dir;
}

async function refreshLinkLabel() {
  try {
    const dir = await idbGet("installDir");
    $("linkedFolder").textContent = dir ? `Linked: ${dir.name}` : "Not linked yet";
  } catch { $("linkedFolder").textContent = "Not linked yet"; }
}

async function updateFromFolder() {
  const myManifest = chrome.runtime.getManifest();
  if (!window.showDirectoryPicker) {
    setUpStatus("This browser build doesn't allow folder access here. Replace files in your extension folder and click Reload now.", false);
    return;
  }
  try {
    // Ensure the install folder is linked first (this is the key correctness step).
    let installDir = await idbGet("installDir");
    if (!installDir) {
      setUpStatus("First, link your installed folder…");
      installDir = await linkInstallFolder();
      if (!installDir) return;
    }
    if (!(await ensurePermission(installDir, "readwrite"))) {
      setUpStatus("Write permission to the install folder was denied.", false); return;
    }
    // The linked folder must still be the running version (else it's the wrong folder).
    let insM;
    try { insM = await readManifest(installDir); } catch { insM = null; }
    if (!insM || insM.version !== myManifest.version) {
      setUpStatus(`Linked folder (v${insM ? insM.version : "?"}) doesn't match the running v${myManifest.version}. Re-link it to the exact chrome://extensions Path.`, false);
      await idbSet("installDir", undefined);
      await refreshLinkLabel();
      return;
    }

    setUpStatus("Select the NEW version folder…");
    const newDir = await window.showDirectoryPicker({ id: "wt-new", mode: "read" });
    let newManifest;
    try { newManifest = await readManifest(newDir); }
    catch { setUpStatus("That folder has no manifest.json — pick the new version's folder.", false); return; }
    // Identify by files, not name — a rebrand (renamed extension) must still update.
    if (!(await looksLikeOurExtension(newDir))) { setUpStatus("That folder doesn't look like an ARRAY.FIND build (no popup.js / popup.html). Pick the new version's folder.", false); return; }
    if (cmpVer(newManifest.version, myManifest.version) < 0) {
      setUpStatus(`Selected v${newManifest.version} is older than installed v${myManifest.version}. Aborted.`, false); return;
    }

    setUpStatus(`Copying v${newManifest.version} into “${installDir.name}”…`);
    await copyDir(newDir, installDir);

    // VERIFY the files actually landed: re-read the install folder's manifest.
    const check = await readManifest(installDir);
    if (check.version !== newManifest.version) {
      setUpStatus(`Copy finished but the install folder still reads v${check.version}. The linked folder is likely not the one Chrome loaded — re-link to the exact Path and retry. NOT reloading.`, false);
      return;
    }
    setUpStatus(`Verified v${check.version} in place. Reloading…`, true);
    setTimeout(() => chrome.runtime.reload(), 800);
  } catch (e) {
    if (e && e.name === "AbortError") { setUpStatus("Cancelled."); return; }
    setUpStatus("Update failed: " + (e?.message || e) + ". You can still replace files manually and click Reload now.", false);
  }
}

function reloadExtension() {
  setUpStatus("Reloading…", true);
  setTimeout(() => chrome.runtime.reload(), 300);
}

// ---------- export / import (additive sharing) ----------
const setShareStatus = (msg, ok) => {
  const el = $("shareStatus");
  el.textContent = msg;
  el.style.color = ok === true ? "var(--good)" : ok === false ? "var(--critical)" : "var(--ink-3)";
};

function downloadJSON(obj, filename) {
  const blob = new Blob([JSON.stringify(obj, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function exportWallets() {
  const d = await store.get();
  const labelled = (d.wallets || []).filter(w => w.name);
  if (!labelled.length) { setShareStatus("No labelled wallets to export yet.", false); return; }
  downloadJSON({ type: "wt-wallet-labels", v: 1, exportedAt: new Date().toISOString(), wallets: labelled.map(w => ({ address: w.address, name: w.name })) }, "wallet-labels.json");
  setShareStatus(`Exported ${labelled.length} wallet label(s).`, true);
}

async function exportFunding() {
  const d = await store.get();
  const user = d.userFunding || [];
  if (!user.length) { setShareStatus("No custom funding sources to export (built-ins ship with the extension).", false); return; }
  downloadJSON({ type: "wt-funding", v: 1, exportedAt: new Date().toISOString(), funding: user.map(f => ({ address: f.address, label: f.label, category: f.category || "user" })) }, "funding-sources.json");
  setShareStatus(`Exported ${user.length} funding source(s).`, true);
}

async function exportFeedback() {
  const d = await store.get();
  const fb = d.feedback || [];
  if (!fb.length) { setShareStatus("No flagged results to export yet.", false); return; }
  downloadJSON({ type: "arrayfind-feedback", v: 1, exportedAt: new Date().toISOString(), flagged: fb }, "arrayfind-flagged-results.json");
  setShareStatus(`Exported ${fb.length} flagged result(s).`, true);
}

let importMode = null; // "wallets" | "funding"
async function exportConnectors() {
  const d = await store.get();
  const list = d.connectors || [];
  if (!list.length) { setShareStatus("No connector flags to export yet.", false); return; }
  downloadJSON({ type: "arrayfind-connectors", v: 1, exportedAt: new Date().toISOString(), connectors: list }, "arrayfind-connector-flags.json");
  setShareStatus(`Exported ${list.length} connector flag(s).`, true);
}

async function exportAnsem() {
  const d = await store.get();
  const list = d.ansemWallets || [];
  if (!list.length) { setShareStatus("No Ansem wallets to export yet.", false); return; }
  downloadJSON({ type: "arrayfind-ansem", v: 1, exportedAt: new Date().toISOString(), ansemWallets: list }, "arrayfind-ansem-wallets.json");
  setShareStatus(`Exported ${list.length} Ansem wallet(s).`, true);
}

function triggerImport(mode) { importMode = mode; $("importFile").value = ""; $("importFile").click(); }

async function handleImportFile(file) {
  if (!file) return;
  let data;
  try { data = JSON.parse(await file.text()); }
  catch { setShareStatus("That file isn't valid JSON.", false); return; }

  const d = await store.get();
  if (importMode === "wallets") {
    const incoming = Array.isArray(data) ? data : (data.wallets || []);
    if (!Array.isArray(incoming) || (data.type && data.type !== "wt-wallet-labels")) { setShareStatus("Not a wallet-labels export.", false); return; }
    const have = new Set((d.wallets || []).map(w => w.address));
    let added = 0, skipped = 0;
    for (const w of incoming) {
      if (!w || !BASE58_RE.test(w.address || "")) { continue; }
      if (have.has(w.address)) { skipped++; continue; }   // never overwrite existing
      d.wallets.push({ address: w.address, added: Date.now(), name: (w.name || "").toString().slice(0, 60) });
      have.add(w.address); added++;
    }
    await store.set({ wallets: d.wallets });
    renderWalletList();
    setShareStatus(`Imported ${added} new wallet label(s); ${skipped} already present were kept as-is.`, true);
  } else if (importMode === "funding") {
    const incoming = Array.isArray(data) ? data : (data.funding || []);
    if (!Array.isArray(incoming) || (data.type && data.type !== "wt-funding")) { setShareStatus("Not a funding-sources export.", false); return; }
    const have = new Set((d.userFunding || []).map(f => f.address));
    let added = 0, skipped = 0;
    for (const f of incoming) {
      if (!f || !BASE58_RE.test(f.address || "")) continue;
      if (have.has(f.address) || KNOWN_ADDRESSES[f.address]) { skipped++; continue; } // skip existing + built-ins
      d.userFunding.push({ address: f.address, label: (f.label || "Funding source").toString().slice(0, 60), category: f.category || "imported" });
      have.add(f.address); added++;
    }
    await store.set({ userFunding: d.userFunding });
    rebuildExtraLabels(d.userFunding);
    renderFundingLib();
    setShareStatus(`Imported ${added} new funding source(s); ${skipped} already present/built-in were skipped.`, true);
  } else if (importMode === "feedback") {
    const incoming = Array.isArray(data) ? data : (data.flagged || []);
    if (!Array.isArray(incoming) || (data.type && data.type !== "atlas-feedback" && data.type !== "arrayfind-feedback")) { setShareStatus("Not a flagged-results export.", false); return; }
    d.feedback = d.feedback || [];
    const key = (f) => `${f.addr}|${f.on || ""}|${f.kind || "incorrect"}`;
    const have = new Set(d.feedback.map(key));
    let added = 0, skipped = 0;
    for (const f of incoming) {
      if (!f || !BASE58_RE.test(f.addr || "")) continue;
      if (have.has(key(f))) { skipped++; continue; }     // adds only — never overwrites
      d.feedback.push({ ...f, imported: true });
      have.add(key(f)); added++;
    }
    await store.set({ feedback: d.feedback });
    if (lastSettings) lastSettings.feedback = d.feedback;
    renderFeedbackList();
    setShareStatus(`Imported ${added} flagged result(s); ${skipped} duplicate(s) skipped. Certainty calibration updated.`, true);
  } else if (importMode === "connectors") {
    const incoming = Array.isArray(data) ? data : (data.connectors || []);
    if (!Array.isArray(incoming) || (data.type && data.type !== "atlas-connectors" && data.type !== "arrayfind-connectors")) { setShareStatus("Not a connector-flags export.", false); return; }
    d.connectors = d.connectors || [];
    const have = new Set(d.connectors);
    let added = 0, skipped = 0;
    for (const a of incoming) {
      const addr = typeof a === "string" ? a : (a && a.address);
      if (!addr || !BASE58_RE.test(addr)) continue;
      if (have.has(addr)) { skipped++; continue; }
      d.connectors.push(addr); have.add(addr); added++;
    }
    await store.set({ connectors: d.connectors });
    if (lastSettings) lastSettings.connectors = d.connectors;
    renderConnectorList();
    setShareStatus(`Imported ${added} connector flag(s); ${skipped} already present.`, true);
  } else if (importMode === "ansem") {
    const incoming = Array.isArray(data) ? data : (data.ansemWallets || []);
    if (!Array.isArray(incoming) || (data.type && data.type !== "atlas-ansem" && data.type !== "arrayfind-ansem")) { setShareStatus("Not an Ansem-wallets export.", false); return; }
    d.ansemWallets = d.ansemWallets || [];
    const have = new Set(d.ansemWallets);
    let added = 0, skipped = 0;
    for (const a of incoming) {
      const addr = typeof a === "string" ? a : (a && a.address);
      if (!addr || !BASE58_RE.test(addr)) continue;
      if (have.has(addr)) { skipped++; continue; }
      d.ansemWallets.push(addr); have.add(addr); added++;
    }
    await store.set({ ansemWallets: d.ansemWallets });
    if (lastSettings) lastSettings.ansemWallets = d.ansemWallets;
    renderAnsemList();
    setShareStatus(`Imported ${added} Ansem wallet(s); ${skipped} already present.`, true);
  }
}

// ---------- funding sources library ----------
async function renderFundingLib() {
  const { userFunding } = await store.get();
  const q = ($("fundSearch").value || "").toLowerCase();
  const seed = FUNDING_DB.map(f => ({ ...f, seed: true }));
  const user = (userFunding || []).map(f => ({ ...f, seed: false }));
  const all = [...user, ...seed].filter(f =>
    !q || f.address.toLowerCase().includes(q) || (f.label || "").toLowerCase().includes(q) || (f.category || "").toLowerCase().includes(q));
  $("fundCount").textContent = `${seed.length} built-in · ${user.length} added`;
  const ul = $("fundingLibList");
  ul.innerHTML = "";
  if (all.length === 0) { ul.innerHTML = `<li><span class="hint">No matches.</span></li>`; return; }
  for (const f of all) {
    const li = document.createElement("li");
    li.innerHTML = `<div class="row-main">
        <span class="row-title"></span>
        <span class="row-sub mono"></span></div>
      <div class="row-right">
        <span class="badge"></span>
        <button class="copy-btn" title="Copy address">⧉</button>
        <button class="rm-fund icon-btn small hidden" title="Remove">✕</button></div>`;
    li.querySelector(".row-title").textContent = f.label || "Funding source";
    li.querySelector(".row-sub").textContent = f.address;
    li.querySelector(".row-sub").title = f.address;
    li.querySelector(".badge").textContent = f.seed ? (f.category || "built-in") : "added";
    li.querySelector(".copy-btn").addEventListener("click", () => {
      navigator.clipboard.writeText(f.address);
      $("statusLine").textContent = "Address copied.";
      setTimeout(() => ($("statusLine").textContent = ""), 1500);
    });
    if (!f.seed) {
      const rm = li.querySelector(".rm-fund");
      rm.classList.remove("hidden");
      rm.addEventListener("click", async () => {
        const d = await store.get();
        d.userFunding = (d.userFunding || []).filter(x => x.address !== f.address);
        await store.set({ userFunding: d.userFunding });
        rebuildExtraLabels(d.userFunding);
        renderFundingLib();
      });
    }
    ul.appendChild(li);
  }
}

async function addFundingSource() {
  const addr = $("fundAddr").value.trim();
  const label = $("fundLabel").value.trim();
  $("fundErr").classList.add("hidden");
  const err = (m) => { const e = $("fundErr"); e.textContent = m; e.classList.remove("hidden"); };
  if (!BASE58_RE.test(addr)) return err("That doesn't look like a valid Solana address.");
  if (!label) return err("Add a label so you recognize this source.");
  const d = await store.get();
  if ((d.userFunding || []).some(f => f.address === addr) || KNOWN_ADDRESSES[addr]) return err("That address is already in the library.");
  d.userFunding = [...(d.userFunding || []), { address: addr, label, category: "user" }];
  await store.set({ userFunding: d.userFunding });
  rebuildExtraLabels(d.userFunding);
  $("fundAddr").value = ""; $("fundLabel").value = "";
  $("statusLine").textContent = "Funding source added.";
  setTimeout(() => ($("statusLine").textContent = ""), 1500);
  renderFundingLib();
}

async function renderIgnoredList() {
  const d = await store.get();
  const labels = Object.fromEntries((d.wallets || []).filter(w => w.name).map(w => [w.address, w.name]));
  const nameOf = (a) => labels[a] ? `[${labels[a]}]` : shortAddr(a);
  const scoped = d.ignoredScoped || {};
  // Flatten scoped ignores into {on, addr} pairs, plus any legacy global ignores.
  const pairs = [];
  for (const on of Object.keys(scoped)) for (const addr of (scoped[on] || [])) pairs.push({ on, addr });
  for (const addr of (d.ignored || [])) pairs.push({ on: null, addr });   // legacy global
  $("ignoredSection").classList.toggle("hidden", pairs.length === 0);
  const ul = $("ignoredList");
  ul.innerHTML = "";
  for (const { on, addr } of pairs) {
    const li = document.createElement("li");
    li.innerHTML = `<div class="row-main"><span class="row-title mono"></span><span class="row-sub"></span></div><div class="row-right"><button class="copy-btn" title="Stop ignoring">↺ unignore</button></div>`;
    li.querySelector(".row-title").textContent = shortAddr(addr);
    li.querySelector(".row-title").title = addr;
    li.querySelector(".row-sub").textContent = on ? `not a side wallet for ${nameOf(on)}` : "legacy (global)";
    li.querySelector(".copy-btn").addEventListener("click", async () => {
      const dd = await store.get();
      if (on) { dd.ignoredScoped = dd.ignoredScoped || {}; dd.ignoredScoped[on] = (dd.ignoredScoped[on] || []).filter(a => a !== addr); }
      else dd.ignored = (dd.ignored || []).filter(a => a !== addr);
      await store.set({ ignoredScoped: dd.ignoredScoped, ignored: dd.ignored });
      renderIgnoredList();
    });
    ul.appendChild(li);
  }
}

async function renderAnsemList() {
  const d = await store.get();
  const list = d.ansemWallets || [];
  const ul = $("ansemList");
  ul.innerHTML = "";
  if (!list.length) {
    ul.innerHTML = `<li><span class="hint">No Ansem wallets added yet.</span></li>`;
    return;
  }
  for (const addr of list) {
    const li = document.createElement("li");
    li.innerHTML = `<span class="ref-addr mono"></span><button class="copy-btn" title="Remove from Ansem wallets">↺ remove</button>`;
    li.querySelector(".ref-addr").textContent = addr;
    li.querySelector(".ref-addr").title = addr;
    li.querySelector(".copy-btn").addEventListener("click", async () => {
      const dd = await store.get();
      dd.ansemWallets = (dd.ansemWallets || []).filter(a => a !== addr);
      await store.set({ ansemWallets: dd.ansemWallets });
      if (lastSettings) lastSettings.ansemWallets = dd.ansemWallets;
      renderAnsemList();
    });
    ul.appendChild(li);
  }
}

async function renderConnectorList() {
  const d = await store.get();
  const list = d.connectors || [];
  $("connectorSection").classList.toggle("hidden", list.length === 0);
  const ul = $("connectorList");
  ul.innerHTML = "";
  for (const addr of list) {
    const li = document.createElement("li");
    li.innerHTML = `<span class="ref-addr mono"></span><button class="copy-btn" title="Stop treating as a connector">↺ remove</button>`;
    li.querySelector(".ref-addr").textContent = addr;
    li.querySelector(".ref-addr").title = addr;
    li.querySelector(".copy-btn").addEventListener("click", async () => {
      const dd = await store.get();
      dd.connectors = (dd.connectors || []).filter(a => a !== addr);
      await store.set({ connectors: dd.connectors });
      renderConnectorList();
    });
    ul.appendChild(li);
  }
}

async function renderFeedbackList() {
  const { feedback } = await store.get();
  const list = feedback || [];
  $("feedbackSection").classList.toggle("hidden", list.length === 0);
  const ul = $("feedbackList");
  ul.innerHTML = "";
  for (const f of [...list].sort((a, b) => (b.ts || 0) - (a.ts || 0))) {
    const li = document.createElement("li");
    li.innerHTML = `<div class="row-main">
        <span class="row-title mono"></span>
        <span class="row-sub"></span></div>
      <div class="row-right"><button class="copy-btn" title="Remove this flag">↺ undo</button></div>`;
    li.querySelector(".row-title").textContent = shortAddr(f.addr);
    li.querySelector(".row-title").title = f.addr;
    const when = f.ts ? new Date(f.ts).toLocaleDateString() : "";
    const kindTxt = f.kind === "supply-ok" ? "non-suspicious transfer" : f.kind === "connector" ? "connector wallet" : "incorrect result";
    const certWord = { low: "not sure", med: "fairly sure", high: "certain" }[f.userCertainty];
    const youSaid = f.actualLabel ? ` · you: “${f.actualLabel}”${certWord ? ` (${certWord})` : ""}` : (certWord ? ` · you: ${certWord}` : "");
    li.querySelector(".row-sub").textContent =
      `${kindTxt}${youSaid} · ${when} · was ${f.certBand || "?"} ${f.certainty ?? "?"}%`;
    li.querySelector(".copy-btn").addEventListener("click", async () => {
      const d = await store.get();
      d.feedback = (d.feedback || []).filter(x => !(x.addr === f.addr && x.on === f.on));
      await store.set({ feedback: d.feedback });
      renderFeedbackList();
    });
    ul.appendChild(li);
  }
}

function showError(id, msg) {
  const el = $(id);
  el.textContent = msg;
  el.classList.remove("hidden");
}

// ---------- events ----------
document.addEventListener("DOMContentLoaded", async () => {
  const d = await store.get();
  $("apiKeyInput").value = d.apiKey;
  $("txDepthInput").value = String(d.txDepth);
  $("txDepthWarn").classList.toggle("hidden", !(Number(d.txDepth) > 10000));
  $("dustCheck").checked = !!d.dust;
  $("dustUsdSelect").value = String(d.dustUsd);
  $("supplyPctSelect").value = String(d.supplyPct);
  applyMapPalette(d.mapPalette || "arctic");
  // Splash: 3-second welcome (click to skip). Toggle lives in Settings.
  $("splashToggle").checked = d.splash !== false;
  if (d.splash !== false) {
    const sp = $("splash");
    try { const mf = chrome.runtime.getManifest(); $("splashVer").textContent = "v" + (mf.version_name || mf.version); } catch {}
    sp.classList.remove("hidden");
    const hideSplash = () => { sp.classList.add("splash-out"); setTimeout(() => sp.classList.add("hidden"), 480); };
    setTimeout(hideSplash, 3000);
    sp.addEventListener("click", hideSplash, { once: true });
  }
  rebuildExtraLabels(d.userFunding);
  renderWalletList();
  if (!d.apiKey) show("settings");

  $("ansemAddBtn").addEventListener("click", async () => {
    const addr = $("ansemAddr").value.trim();
    const err = $("ansemErr");
    if (!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(addr)) {
      err.textContent = "That doesn't look like a Solana address.";
      err.classList.remove("hidden");
      return;
    }
    err.classList.add("hidden");
    const d = await store.get();
    d.ansemWallets = d.ansemWallets || [];
    if (!d.ansemWallets.includes(addr)) d.ansemWallets.push(addr);
    await store.set({ ansemWallets: d.ansemWallets });
    if (lastSettings) lastSettings.ansemWallets = d.ansemWallets;
    $("ansemAddr").value = "";
    renderAnsemList();
  });

  $("copyAddrBtn").addEventListener("click", () => {
    if (!currentAddress) return;
    navigator.clipboard.writeText(currentAddress);
    $("copyAddrBtn").textContent = "✓";
    setTimeout(() => ($("copyAddrBtn").textContent = "⧉"), 1200);
  });

  $("navUp").addEventListener("click", () => navJump(-1));
  $("navDown").addEventListener("click", () => navJump(1));
  $("navHome").addEventListener("click", () => { show("list"); window.scrollTo({ top: 0 }); });
  $("interBackBtn").addEventListener("click", () => $("interPanel").classList.add("hidden"));
  $("bubbleMapBtn").addEventListener("click", () => { mapLayoutSalt = 0; openBubbleMap(); });
  $("mapBackBtn").addEventListener("click", () => $("mapPanel").classList.add("hidden"));

  // ---- CA launch scan panel ----
  $("caBackBtn").addEventListener("click", () => show("list"));
  $("caCopyBtn").addEventListener("click", () => {
    if (!caState) return;
    navigator.clipboard.writeText(caState.mint);
    $("statusLine").textContent = "CA copied.";
    setTimeout(() => ($("statusLine").textContent = ""), 1500);
  });
  $("caRescanBtn").addEventListener("click", () => { if (caState) openCaScan(caState.mint, true); });
  $("caMapBtn").addEventListener("click", () => { mapLayoutSalt = 0; openCaMap(); });
  $("caCurBtn").addEventListener("click", () => runCurrentState());
  $("caChainAllBtn").addEventListener("click", async () => {
    if (!caState) return;
    const flagged = caState.buyers.filter(b => b.qualifies);
    const pl = (caState.symbol ? "$" + caState.symbol : shortAddr(caState.mint)) + " CA";
    for (const b of flagged) await addToChain(b.addr, "", caState.mint, pl);
    $("statusLine").textContent = `${flagged.length} flagged wallet(s) in the ${pl} chain.`;
    setTimeout(() => ($("statusLine").textContent = ""), 2200);
    renderCaResults(await store.get());                       // refresh the ⛓ buttons
  });
  $("mapSaveBtn").addEventListener("click", saveMapSVG);
  $("infraToggle").addEventListener("click", () => {
    // Non-destructive: clusters are already laid out in their gaps, so just re-render
    // — the analysed wallet and every connection keep their exact positions.
    mapShowInfra = !mapShowInfra;
    $("infraToggle").textContent = mapShowInfra ? "Hide infrastructure" : "Show infrastructure";
    $("infraToggle").classList.toggle("active", mapShowInfra);
    rerenderMap();
  });
  $("lowConfInput").addEventListener("change", () => {
    const v = parseInt($("lowConfInput").value, 10);
    mapLowConfThresh = (isNaN(v) || v <= 0) ? 0 : Math.min(100, v);
    rerenderMap();   // filter at render — keeps the existing arrangement
  });
  // Reset → the original CANONICAL layout (salt 0), ignoring any saved arrangement.
  $("mapResetBtn").addEventListener("click", () => { mapLowConfThresh = 0; mapLayoutSalt = 0; mapMode === "ca" ? openCaMap(false) : openBubbleMap(false); });
  // Set display → persist the current arrangement (incl. any drags) for next time.
  $("mapSetBtn").addEventListener("click", () => { saveCurrentLayout(); });
  // Redraw display → a fresh layout VARIATION to shake out awkwardly-placed nodes.
  $("mapRedrawBtn").addEventListener("click", () => { mapLayoutSalt = (mapLayoutSalt + 1) % 1000; mapMode === "ca" ? openCaMap(false) : openBubbleMap(false); $("statusLine").textContent = "Redrawn — click again for another variation, Set display to keep one."; setTimeout(() => ($("statusLine").textContent = ""), 2600); });
  $("labelsToggle").addEventListener("click", () => {
    mapLabelMode = mapLabelMode === "all" ? "funding" : "all";
    $("labelsToggle").textContent = mapLabelMode === "all" ? "Labels: all" : "Labels: funding";
    $("labelsToggle").classList.toggle("active", mapLabelMode === "funding");
    rerenderMap();
  });
  const setMapSelectMode = (on) => {
    mapSelectMode = on;
    if (!on) mapSelection.clear();
    $("mapSelectBtn").textContent = on ? "Done (Enter)" : "Select group";
    $("mapSelectBtn").classList.toggle("active", on);
    rerenderMap();
  };
  $("mapSelectBtn").addEventListener("click", () => setMapSelectMode(!mapSelectMode));
  const zoomStep = (dir) => {
    const sx = mapPanX + 0.5 * (MAP_W / mapZoom), sy = mapPanY + 0.5 * (MAP_H / mapZoom);
    mapZoom = Math.max(1, Math.min(4, mapZoom * (dir > 0 ? 1.3 : 1 / 1.3)));
    if (mapZoom <= 1.001) { mapZoom = 1; mapPanX = 0; mapPanY = 0; }
    else { mapPanX = sx - 0.5 * (MAP_W / mapZoom); mapPanY = sy - 0.5 * (MAP_H / mapZoom); }
    applyMapView();
  };
  $("zoomInBtn").addEventListener("click", () => zoomStep(1));
  $("zoomOutBtn").addEventListener("click", () => zoomStep(-1));
  document.addEventListener("keydown", (ev) => {
    if (!mapSelectMode) return;
    if (ev.key === "Enter" || ev.key === "Escape") { ev.preventDefault(); setMapSelectMode(false); }
  });
  $("mapPaletteSel").addEventListener("change", async () => {
    applyMapPalette($("mapPaletteSel").value);
    await store.set({ mapPalette: mapPaletteName });
    if (lastSettings) lastSettings.mapPalette = mapPaletteName;
    // Recolour only — positions untouched (same non-destructive path as the filters).
    if (!$("mapPanel").classList.contains("hidden")) rerenderMap();
  });

  $("settingsBtn").addEventListener("click", () => {
    if (currentView === "settings") { closeSettings(); return; }   // gear toggles settings closed
    settingsReturnView = currentView; // remember where we came from
    renderIgnoredList();
    renderConnectorList();
    renderAnsemList();
    renderFeedbackList();
    renderFundingLib();
    try { $("verNow").textContent = "v" + chrome.runtime.getManifest().version; } catch {}
    refreshLinkLabel();
    setUpStatus(""); setShareStatus("");
    show("settings");
  });
  $("updateFolderBtn").addEventListener("click", updateFromFolder);
  $("linkFolderBtn").addEventListener("click", () => linkInstallFolder().catch(e => { if (e?.name !== "AbortError") setUpStatus("Link failed: " + (e?.message || e), false); }));
  $("reloadExtBtn").addEventListener("click", reloadExtension);
  $("exportWalletsBtn").addEventListener("click", exportWallets);
  $("exportFundingBtn").addEventListener("click", exportFunding);
  $("exportFeedbackBtn").addEventListener("click", exportFeedback);
  $("exportFeedbackBtn2").addEventListener("click", exportFeedback);
  $("importFeedbackBtn").addEventListener("click", () => triggerImport("feedback"));
  $("importFeedbackBtn2").addEventListener("click", () => triggerImport("feedback"));
  $("exportConnectorsBtn").addEventListener("click", exportConnectors);
  $("importConnectorsBtn").addEventListener("click", () => triggerImport("connectors"));
  $("exportConnectorsBtn2").addEventListener("click", exportConnectors);
  $("importConnectorsBtn2").addEventListener("click", () => triggerImport("connectors"));
  $("exportAnsemBtn").addEventListener("click", exportAnsem);
  $("importAnsemBtn").addEventListener("click", () => triggerImport("ansem"));
  $("splashToggle").addEventListener("change", async () => {
    await store.set({ splash: $("splashToggle").checked });
  });
  $("importWalletsBtn").addEventListener("click", () => triggerImport("wallets"));
  $("importFundingBtn").addEventListener("click", () => triggerImport("funding"));
  $("importFile").addEventListener("change", (e) => handleImportFile(e.target.files[0]));
  $("fundAddBtn").addEventListener("click", addFundingSource);
  $("fundLabel").addEventListener("keydown", (e) => { if (e.key === "Enter") addFundingSource(); });
  $("fundSearch").addEventListener("input", renderFundingLib);
  $("backBtn").addEventListener("click", () => show("list"));

  // Close settings → return to whatever screen was open before (list or the open
  // detail), never a forced reload. The API key is saved only if it changed.
  const closeSettings = async () => {
    const d = await store.get();
    const typed = $("apiKeyInput").value.trim();
    if (typed !== (d.apiKey || "")) await store.set({ apiKey: typed });
    if (settingsReturnView === "detail" && currentAddress) show("detail");
    else show("list");
  };
  $("saveSettingsBtn").addEventListener("click", closeSettings);
  $("closeSettingsBtn").addEventListener("click", closeSettings);

  // Per-analysis filters live on the search page and persist as they change;
  // changing any of them clears cached analyses so the next open recomputes.
  $("filterToggle").addEventListener("click", () => {
    const body = $("filterBody");
    const open = body.classList.toggle("hidden");
    $("filterCaret").textContent = open ? "▾" : "▴";
  });
  const persistFilters = async () => {
    // parseFloat("0") is 0 (a valid "Any %" choice) — don't let `|| 0.5` clobber it.
    const spRaw = parseFloat($("supplyPctSelect").value);
    // Transaction depth: free type-in, clamped to 100–50,000.
    const txRaw = parseInt($("txDepthInput").value, 10);
    const txDepth = Number.isNaN(txRaw) ? 300 : Math.max(100, Math.min(50000, txRaw));
    await store.set({
      txDepth,
      dust: $("dustCheck").checked,
      dustUsd: parseFloat($("dustUsdSelect").value),
      supplyPct: Number.isNaN(spRaw) ? 0.5 : Math.max(0, spRaw),
      cache: {},
    });
  };
  for (const id of ["txDepthInput", "dustCheck", "dustUsdSelect", "supplyPctSelect"]) {
    $(id).addEventListener("change", persistFilters);
  }
  // Live warning while typing a large transaction count.
  $("txDepthInput").addEventListener("input", () => {
    $("txDepthWarn").classList.toggle("hidden", !(Number($("txDepthInput").value) > 10000));
  });

  $("addWalletBtn").addEventListener("click", addWallet);
  $("addressInput").addEventListener("keydown", (e) => { if (e.key === "Enter") addWallet(); });

  $("refreshBtn").addEventListener("click", () => { if (currentAddress) openDetail(currentAddress, true); });

  $("sortSelect").addEventListener("change", () => {
    resultSort = $("sortSelect").value;
    if (lastData) renderDetail(lastData, lastSettings || {});
  });
  // Generic collapsible section headers (all detail sections use this).
  document.querySelectorAll(".h3-toggle[data-target]").forEach(btn => {
    btn.addEventListener("click", () => {
      const target = $(btn.dataset.target);
      if (!target) return;
      const collapsed = target.classList.toggle("hidden");
      const caret = btn.querySelector(".caret");
      if (caret) caret.textContent = collapsed ? "▸" : "▾";
    });
  });

  // Compact/full toggle for the side-wallet results: compact = address + flags
  // only, full = the current cards with all functions. Expanding any single
  // card (click) also lifts compact mode.
  $("suspectCompactBtn")?.addEventListener("click", () => {
    const list = $("sideWalletList");
    const compact = list.classList.toggle("compact-mode");
    const btn = $("suspectCompactBtn");
    btn.textContent = compact ? "Show full" : "Compact";
    btn.classList.toggle("active", compact);
    if (compact) list.querySelectorAll(".suspect .expander").forEach(e => (e.textContent = "▸"));
  });

  // Per-section sorting for Interacted addresses and Programs & PDAs.
  $("cpSortSelect").addEventListener("change", () => { cpSort = $("cpSortSelect").value; if (lastStats) renderCounterparties(lastStats, lastSettings || {}); });
  $("progSortSelect").addEventListener("change", () => { progSort = $("progSortSelect").value; if (lastStats) renderCounterparties(lastStats, lastSettings || {}); });

  // ---- recent sells ----
  $("loadMoreSellsBtn").addEventListener("click", () => openSellsPanel());
  $("sellsBackBtn").addEventListener("click", () => $("sellsPanel").classList.add("hidden"));
  $("loadOlderSellsBtn").addEventListener("click", loadOlderSells);

  // ---- multi-wallet refresh ----
  $("selectModeBtn").addEventListener("click", () => {
    selectMode = !selectMode;
    if (!selectMode) selectedWallets.clear();
    $("selectModeBtn").textContent = selectMode ? "Done" : "Select";
    $("selectModeBtn").classList.toggle("active", selectMode);
    document.querySelector(".sel-all").classList.toggle("hidden", !selectMode);
    $("refreshSelectedBtn").classList.toggle("hidden", !selectMode);
    $("selectAllChk").checked = false;
    renderWalletList();
  });
  $("selectAllChk").addEventListener("change", async () => {
    const { wallets } = await store.get();
    selectedWallets.clear();
    if ($("selectAllChk").checked) wallets.forEach(w => selectedWallets.add(w.address));
    renderWalletList();
  });
  $("refreshAllBtn").addEventListener("click", async () => {
    const { wallets } = await store.get();
    confirmBatch(wallets.map(w => w.address));
  });
  $("refreshSelectedBtn").addEventListener("click", () => {
    if (selectedWallets.size) confirmBatch([...selectedWallets]);
  });
  $("batchCancelBtn").addEventListener("click", () => $("batchWarn").classList.add("hidden"));
  $("batchGoBtn").addEventListener("click", runBatch);
  $("batchStopBtn").addEventListener("click", () => { batchStop = true; $("batchStopBtn").textContent = "Stopping…"; });


  async function addWallet() {
    const addr = $("addressInput").value.trim();
    const name = $("nameInput").value.trim();
    $("addError").classList.add("hidden");
    if (!BASE58_RE.test(addr)) {
      showError("addError", "That doesn't look like a valid Solana address (base58, 32–44 chars).");
      return;
    }
    const d2 = await store.get();
    if (d2.wallets.some(w => w.address === addr)) {
      showError("addError", "Wallet already added.");
      return;
    }
    // A pasted TOKEN MINT routes to the CA launch scan instead of wallet
    // analysis — same search box, auto-detected (one RPC call). The label (if
    // typed) is saved with it, and the CA lands in the "CA launch scans"
    // section on this page just like wallets land in Saved wallets.
    if (await isTokenMint(addr, d2.apiKey)) {
      $("addressInput").value = "";
      $("nameInput").value = "";
      openCaScan(addr, false, name);
      return;
    }
    d2.wallets.push({ address: addr, added: Date.now(), name });
    await store.set({ wallets: d2.wallets });
    $("addressInput").value = "";
    $("nameInput").value = "";
    renderWalletList();
    openDetail(addr); // the program does the rest
  }
});
